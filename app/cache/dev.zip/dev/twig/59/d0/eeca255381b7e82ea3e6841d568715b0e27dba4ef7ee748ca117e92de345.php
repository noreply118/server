<?php

/* MainRatetradeBundle:Default:brokerlogininfo.html.twig */
class __TwigTemplate_59d0eeca255381b7e82ea3e6841d568715b0e27dba4ef7ee748ca117e92de345 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<style type=\"text/css\">
    body {
        padding-top: 0 !important;
        padding-bottom: 0 !important;
        padding-top: 0 !important;
        padding-bottom: 0 !important;
        margin:0 !important;
        width: 100% !important;
        -webkit-text-size-adjust: 100% !important;
        -ms-text-size-adjust: 100% !important;
        -webkit-font-smoothing: antialiased !important;
    }
    .tableContent img {
        border: 0 !important;
        display: block !important;
        outline: none !important;
    }
    ul{
        margin:0;
    }
    p{
        color:#777070;
        font-size:15px;
        line-height:19px;
        margin:0;
    }
    h2,h1{
        color:#555555;
        font-size:21px;
        font-weight:normal;
        margin: 0;
    }

    h2.white{
        color:#ffffff;
    }

    a{
        color:#000000;
    }

    a.link1{
        font-size:13px;
        color:#3892E3;
    }
    a.link2{
        padding:8px;
        background:#52619E;
        font-size:13px;
        color:#ffffff;
        text-decoration:none;
        font-weight:bold;
    }
    a.link3{
        color:#52619E;
        font-size:13px;
        font-weight:bold;
        text-decoration:none;
    }

    .bgBody{
        background: #F6F6F6;
    }
    .bgItem{
        background: #ffffff;
    }


</style>

<script type=\"colorScheme\" class=\"swatch active\">
    {
    \"name\":\"Default\",
    \"bgBody\":\"F6F6F6\",
    \"link\":\"ffffff\",
    \"color\":\"999999\",
    \"bgItem\":\"ffffff\",
    \"title\":\"555555\"
    }
</script>
<body class='bgBody' leftpadding=\"0\" offset=\"0\" paddingheight=\"0\" paddingwidth=\"0\" style=\"padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;\" toppadding=\"0\">
    <table align=\"center\" class='bgBody' border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"tableContent\" width=\"100%\">
        <tbody>
            <tr>
                <td valign=\"top\">
                    <table align=\"center\" class='bgBody' border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"font-family:helvetica, sans-serif;\" width=\"600\">
                        <tbody>
                            <tr>
                                <td width=\"20\">
                                </td>
                                <td>
                                    <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                        <!--  =========================== The header ===========================  -->
                                        <tbody>



                                            <!--  =========================== The body ===========================  -->
                                            <tr>
                                                <td class=\"movableContentContainer\">
                                                    <!--  ==== movable content in the body ===  -->

                                                    <div class=\"movableContent\">
                                                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                            <tr>
                                                                <td height=\"25\">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align=\"left\" valign=\"middle\">
                                                                                    <div class=\"contentEditableContainer contentImageEditable\">
                                                                                        <div class=\"contentEditable\">
                                                                                            <a href=\"http://www.ratetrade.ca\" target=\"_blank\">
                                                                                                <img alt=\"Company logo\" data-default=\"placeholder\" data-max-width=\"300\" height=\"38\" src=\"http://www.ratetrade.ca/symfonyratetrade/web/bundles/mainratetrade/images/ratetrade.png\" width=\"180\" style=\"padding-bottom:20px;\"/>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </td>
                                                                                <td align=\"right\" valign=\"top\">
                                                                                    <div class=\"contentEditableContainer contentImageEditable\" style=\"display:inline-block;\">
                                                                                        <div class=\"contentEditable\">&nbsp;</div>
                                                                                    </div>
                                                                                </td>
                                                                                <td align=\"right\" valign=\"top\" width=\"18\">
                                                                                    <div class=\"contentEditableContainer contentImageEditable\" style=\"display:inline-block;\">
                                                                                        <div class=\"contentEditable\">&nbsp;</div>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div class=\"movableContent\">
                                                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                            <tr>
                                                                <td align=\"right\" bgcolor=\"#2D3867\" style=\"padding:20px;\">
                                                                    <div class=\"contentEditableContainer contentTextEditable\">
                                                                        <div class=\"contentEditable\">
                                                                            <p style=\"color:#ffffff;font-size:16px;line-height:19px;\">
                                                                                Compare Rates and Services.</p>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>


                                                    <div class=\"movableContent\">
                                                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                            <tbody>
                                                                <tr>
                                                                    <td height=\"25\">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <table align=\"center\" class='bgItem' border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border:1px solid #dddddd\" valign=\"top\" width=\"558\">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td colspan=\"3\" height=\"16\">
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width=\"16\">
                                                                                    </td>
                                                                                    <td>
                                                                                        <table align=\"center\" class='bgItem' border=\"0\" cellpadding=\"0\" cellspacing=\"0\" valign=\"top\" width=\"526\">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <td align=\"left\" valign=\"top\">
                                                                                                        <div class=\"contentEditableContainer contentTextEditable\">
                                                                                                            <div class=\"contentEditable\">
                                                                                                                <h2>Thank You</h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td height=\"13\">
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td align=\"left\" valign=\"top\">
                                                                                                        <div class=\"contentEditableContainer contentTextEditable\">
                                                                                                            <div class=\"contentEditable\">
                                                                                                                <p style=\"text-align:justify;\">
                                                                                                                    We have received your details and would like to thank you for being a part of Ratetrade.  If any queries please feel to contact Ratetrade at contact@ratetrade.ca.
                                                                                                                    <br/><br/>
                                                                                                                    Ratetrade.ca.
                                                                                                                </p>
                                                                                                                <br/><br/>
                                                                                                                <table>
                                                                                                                    <tr>
                                                                                                                        <td>Username</td>
                                                                                                                        <td>&nbsp;&nbsp;</td>
                                                                                                                        <td>";
        // line 204
        echo twig_escape_filter($this->env, (isset($context["username"]) ? $context["username"] : $this->getContext($context, "username")), "html", null, true);
        echo "</td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td>Password</td>
                                                                                                                        <td>&nbsp;&nbsp;</td>
                                                                                                                        <td>";
        // line 209
        echo twig_escape_filter($this->env, (isset($context["password"]) ? $context["password"] : $this->getContext($context, "password")), "html", null, true);
        echo "</td>
                                                                                                                    </tr>
                                                                                                                </table>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td height=\"20\">
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td align=\"left\" style=\"padding-bottom:8px;\" valign=\"top\">
                                                                                                        <div class=\"contentEditableContainer contentTextEditable\">
                                                                                                            <div class=\"contentEditable\">
                                                                                                                <a target='_blank' href=\"http://www.ratetrade.ca/mortgage-broker-login\" class='link2' style='padding: 8px;
                                                                                                                   background: #52619E;
                                                                                                                   font-size: 13px;
                                                                                                                   color: #ffffff;
                                                                                                                   text-decoration: none;
                                                                                                                   font-weight: bold;'>Login</a>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                    <td width=\"16\">
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td colspan=\"3\" height=\"16\">
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>


                                                    <div class='movableContent'>
                                                        <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                            <tr>
                                                                <td height=\"30\">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td bgcolor=\"#52619E\">
                                                                    <table align=\"center\" bgcolor=\"#52619E\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align=\"left\" bgcolor=\"#52619E\" valign=\"top\" width=\"416\">
                                                                                    <table align=\"center\" bgcolor=\"#52619E\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"416\">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td colspan=\"3\" height=\"28\">
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td width=\"30\">
                                                                                                </td>
                                                                                                <td valign=\"middle\">
                                                                                                    <div class=\"contentEditableContainer contentTextEditable\">
                                                                                                        <div class=\"contentEditable\">
                                                                                                            <p style=\"color:#ffffff;font-size:14px;line-height:19px;\">
                                                                                                                Stay in Touch!</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </td>
                                                                                                <td width=\"10\">
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td colspan=\"3\" height=\"28\">
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                                <td align=\"center\" bgcolor=\"#3E4A7F\" valign=\"top\" width=\"72\">
                                                                                    <table align=\"center\" bgcolor=\"#3E4A7F\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"72\">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align=\"center\" bgcolor=\"#3E4A7F\" height=\"72\" valign=\"middle\" width=\"72\">
                                                                                                    <div class=\"contentEditableContainer contentFacebookEditable\">
                                                                                                        <div class=\"contentEditable\" valign=\"middle\">
                                                                                                            <a target='_blank' href=\"https://www.facebook.com/RateTradeBestMortgageRate/\"><img alt=\"facebook link\" data-default=\"placeholder\" data-max-width=\"37\" height=\"37\" src=\"http://www.ratetrade.ca/symfonyratetrade/web/bundles/mainratetrade/images/facebook.png\" width=\"37\" data-customIcon=\"true\"/></a></div>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                                <td align=\"center\" bgcolor=\"#2D3867\" valign=\"top\" width=\"72\">
                                                                                    <table align=\"center\" bgcolor=\"#2D3867\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"72\" width=\"72\">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align=\"center\" bgcolor=\"#2D3867\" height=\"72\" valign=\"middle\" width=\"72\">
                                                                                                    <div class=\"contentEditableContainer contentTwitterEditable\">
                                                                                                        <div class=\"contentEditable\" valign=\"middle\">
                                                                                                            <a target='_blank' href=\"https://twitter.com/RatetradeCanada\"><img alt=\"twitter link\" data-default=\"placeholder\" data-max-width=\"37\" height=\"37\" src=\"http://www.ratetrade.ca/symfonyratetrade/web/bundles/mainratetrade/images/twitter.png\" data-customIcon=\"true\" width=\"37\" /></a></div>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div class='movableContent'>
                                                        <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                            <tr>
                                                                <td height=\"28\">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td align=\"center\" valign=\"top\">
                                                                    <div class=\"contentEditableContainer contentTextEditable\">
                                                                        <div class=\"contentEditable\">
                                                                            <p style=\"color:#A8B0B6; font-size:13px;line-height: 16px;\">
                                                                                &nbsp;</p>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>

                                                    <div class='movableContent'>
                                                        <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"560\">
                                                            <tr>
                                                                <td height=\"28\">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td align=\"center\" valign=\"top\">
                                                                    <div class=\"contentEditableContainer contentTextEditable\">
                                                                        <div class=\"contentEditable\">
                                                                            <p style=\"color:#A8B0B6; font-weight:bold;font-size:13px;line-height: 30px;\">
                                                                                Ratetrade.ca</p>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>


                                                </td>
                                            </tr>
                                            <!--  =========================== The footer ===========================  -->



                                            <tr>
                                                <td height=\"28\">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width=\"20\">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    <!--Default Zone End-->
</body>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:brokerlogininfo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  510 => 235,  506 => 234,  502 => 233,  498 => 232,  425 => 197,  419 => 196,  411 => 194,  389 => 184,  378 => 181,  311 => 147,  708 => 448,  619 => 362,  580 => 326,  558 => 306,  552 => 305,  544 => 303,  537 => 301,  523 => 294,  512 => 291,  483 => 226,  452 => 267,  448 => 207,  436 => 257,  408 => 193,  404 => 192,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 658,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 263,  100 => 41,  277 => 125,  521 => 255,  513 => 253,  508 => 290,  499 => 248,  495 => 247,  489 => 229,  472 => 229,  396 => 202,  392 => 201,  377 => 192,  356 => 186,  352 => 185,  348 => 184,  192 => 118,  883 => 685,  699 => 504,  449 => 259,  432 => 256,  428 => 255,  414 => 262,  406 => 245,  403 => 244,  399 => 203,  390 => 236,  376 => 233,  373 => 191,  369 => 190,  265 => 159,  261 => 157,  253 => 161,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 428,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 385,  635 => 384,  631 => 383,  570 => 327,  564 => 326,  556 => 324,  549 => 322,  541 => 302,  535 => 315,  527 => 313,  524 => 312,  520 => 311,  505 => 303,  497 => 301,  494 => 231,  479 => 225,  475 => 224,  467 => 288,  458 => 226,  454 => 208,  450 => 283,  446 => 282,  184 => 38,  180 => 37,  172 => 35,  160 => 32,  152 => 30,  937 => 621,  809 => 496,  759 => 448,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 395,  670 => 394,  666 => 393,  629 => 358,  623 => 357,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 293,  530 => 292,  522 => 290,  519 => 289,  515 => 292,  507 => 282,  501 => 281,  493 => 279,  490 => 299,  486 => 281,  477 => 270,  471 => 289,  463 => 270,  460 => 266,  456 => 265,  445 => 257,  441 => 256,  433 => 203,  429 => 215,  424 => 254,  420 => 253,  416 => 252,  412 => 251,  385 => 224,  382 => 277,  118 => 50,  597 => 325,  593 => 324,  589 => 323,  585 => 340,  581 => 321,  576 => 319,  572 => 318,  568 => 317,  561 => 313,  546 => 300,  540 => 299,  532 => 297,  529 => 295,  525 => 256,  517 => 254,  511 => 304,  503 => 249,  500 => 284,  496 => 284,  487 => 277,  481 => 276,  473 => 274,  470 => 273,  466 => 228,  455 => 268,  451 => 224,  447 => 262,  443 => 218,  439 => 260,  434 => 258,  426 => 214,  422 => 264,  400 => 248,  395 => 185,  114 => 19,  260 => 189,  256 => 188,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 135,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 155,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 41,  186 => 131,  178 => 35,  150 => 28,  146 => 27,  134 => 24,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 172,  359 => 171,  351 => 169,  347 => 168,  188 => 36,  301 => 305,  293 => 299,  113 => 90,  174 => 34,  170 => 33,  148 => 29,  77 => 30,  231 => 183,  165 => 106,  161 => 105,  153 => 92,  195 => 113,  191 => 36,  34 => 8,  155 => 27,  310 => 239,  306 => 145,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 230,  270 => 194,  251 => 188,  237 => 140,  233 => 138,  225 => 135,  213 => 152,  205 => 116,  175 => 32,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 137,  215 => 151,  211 => 124,  207 => 149,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 38,  358 => 223,  354 => 222,  350 => 221,  346 => 220,  342 => 166,  338 => 165,  334 => 164,  330 => 163,  326 => 165,  318 => 277,  206 => 126,  244 => 174,  236 => 172,  232 => 209,  228 => 170,  216 => 167,  212 => 166,  200 => 42,  110 => 63,  90 => 52,  84 => 25,  53 => 11,  127 => 20,  97 => 62,  76 => 23,  58 => 11,  480 => 162,  474 => 161,  469 => 221,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 205,  437 => 204,  435 => 256,  430 => 257,  427 => 143,  423 => 142,  413 => 206,  409 => 132,  407 => 205,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 235,  381 => 182,  379 => 314,  374 => 180,  368 => 112,  365 => 189,  362 => 288,  360 => 187,  355 => 170,  341 => 105,  337 => 103,  322 => 214,  314 => 240,  312 => 98,  309 => 207,  305 => 306,  298 => 236,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 27,  132 => 25,  128 => 85,  107 => 60,  61 => 12,  273 => 193,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 138,  224 => 204,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 24,  135 => 77,  119 => 42,  102 => 37,  71 => 12,  67 => 29,  63 => 28,  59 => 27,  201 => 115,  196 => 90,  183 => 34,  171 => 31,  166 => 32,  163 => 29,  158 => 30,  156 => 31,  151 => 26,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 68,  91 => 50,  62 => 24,  49 => 10,  87 => 16,  28 => 3,  94 => 41,  89 => 20,  85 => 14,  75 => 31,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 45,  88 => 26,  78 => 28,  46 => 8,  44 => 15,  27 => 7,  79 => 32,  72 => 13,  69 => 28,  47 => 24,  40 => 8,  37 => 5,  22 => 2,  246 => 188,  157 => 98,  145 => 98,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 18,  98 => 15,  96 => 37,  83 => 33,  74 => 15,  66 => 25,  55 => 26,  52 => 17,  50 => 21,  43 => 23,  41 => 10,  35 => 12,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 44,  189 => 103,  187 => 35,  182 => 36,  176 => 36,  173 => 65,  168 => 34,  164 => 33,  162 => 31,  154 => 29,  149 => 99,  147 => 25,  144 => 28,  141 => 97,  133 => 95,  130 => 23,  125 => 93,  122 => 48,  116 => 21,  112 => 69,  109 => 89,  106 => 45,  103 => 20,  99 => 31,  95 => 28,  92 => 36,  86 => 51,  82 => 50,  80 => 24,  73 => 29,  64 => 20,  60 => 19,  57 => 93,  54 => 92,  51 => 25,  48 => 16,  45 => 10,  42 => 22,  39 => 10,  36 => 13,  33 => 4,  30 => 10,);
    }
}
