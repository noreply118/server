<?php

/* MainRatetradeBundle:Default:penalty.html.twig */
class __TwigTemplate_5f5d3e2746fc784671af9450f1acd37237294903d76ee791cea113bee06b0695 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title> ";
        // line 4
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"description\" content=\"";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mdescription"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\"> 
        <meta name=\"keywords\" content=\"";
        // line 12
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mkeywords"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\"> 
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"";
        // line 14
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"og:description\" content=\"";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mdescription"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mdescription"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"twitter:title\" content=\"";
        // line 20
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "33")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" />
           <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
\t    <script src=\"/./bundles/assets/plugins/modernizr.custom.js\"></script>
     <link rel=\"stylesheet\" type=\"text/css\" href=\"/./bundles/acmedemo/css/emicalculator.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/./bundles/acmedemo/css/jquery-ui.css\">  
   
           ";
        // line 41
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
 <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Mortgage Refinance Penalty Calculator Canada</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li>Calculator</li>
                                <li class=\"active\">Refinance Penalty Calculator</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS --
        <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                   

                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes framecontent\">
 \t   
\t\t\t\t\t\t<form><div class=\"pboxheading\">MORTGAGE REFINANCE PENALTY</div>
                                <div class=\"pbox\">
                                    <div class=\"lamount\">
                                        <label for=\"loanamount\" class=\"orange\"><strong>Remaining Balance on Mortgage (\$)</strong> </label>
                                        <span></span></div><div class=\"datafeild\">
                                        <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                        <span class=\"prc-addon\">\$</span>
                                    <div id=\"loanamountslider\"></div>
                                    <div id=\"loanamountsteps\" class=\"steps\">
                                        <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">\$500,000</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left:  50%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">\$2M</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">\$2.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$3</span></span>
                                    </div>
                                 </div>
                            </div>
                           
                            <div class=\"refdetail1\">
                             <div class=\"pbox\"><div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Mortgage Start Date</strong>
                            </label></div>
                            <div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"date\" style=\"width:30%;\"><option value=\"1\">1</option><option value=\"2\">2</option><option value=\"3\">3</option><option value=\"4\">4</option><option value=\"5\">5</option><option value=\"6\">6</option><option value=\"7\">7</option><option value=\"8\">8</option><option value=\"9\">9</option><option value=\"10\">10</option><option value=\"11\">11</option><option value=\"12\">12</option><option value=\"13\">13</option><option value=\"14\">14</option><option value=\"15\">15</option><option value=\"16\">16</option><option value=\"17\">17</option><option value=\"18\">18</option><option value=\"19\">19</option><option value=\"20\">20</option><option value=\"21\">21</option><option value=\"22\">22</option><option value=\"23\">23</option><option value=\"24\">24</option><option value=\"25\">25</option><option value=\"26\">26</option><option value=\"27\">27</option><option value=\"28\">28</option><option value=\"29\">29</option><option value=\"30\">30</option></select>
                                &nbsp;
                                <select id=\"month\" style=\"width:30%;\">
                                    <option value=\"1\">January</option>
                                    <option value=\"2\">February</option>
                                    <option value=\"3\">March</option>
                                    <option value=\"4\">April</option>
                                    <option value=\"5\">May</option>
                                    <option value=\"6\">June</option>
                                    <option value=\"7\">July</option>
                                    <option value=\"8\">August</option>
                                    <option value=\"9\">September</option>
                                    <option value=\"10\">October</option>
                                    <option value=\"11\">November</option>
                                    <option value=\"12\">December</option>
                                </select>
                                &nbsp;
                                <select id=\"year\" style=\"width:30%;\"><option value=\"2000\">2000</option><option value=\"2001\">2001</option><option value=\"2002\">2002</option><option value=\"2003\">2003</option><option value=\"2004\">2004</option><option value=\"2005\">2005</option><option value=\"2006\">2006</option><option value=\"2007\">2007</option><option value=\"2008\">2008</option><option value=\"2009\">2009</option><option value=\"2010\">2010</option><option value=\"2011\">2011</option><option value=\"2012\">2012</option><option value=\"2013\">2013</option><option value=\"2014\">2014</option><option value=\"2015\">2015</option><option value=\"2016\" selected>2016</option></select>
                            </div></div></div>
                        
                            <div class=\"pbox\">
                              <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Mortgage Original Term</strong>
                            </label></div><div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"mort-term\">
                                    <option>Select Term</option>
                                    <option>1</option>
                                    <option selected>3</option>
                                    <option>5</option>
                                    <option>10</option>
                                </select></div></div></div>
                     
                               <div class=\"pbox\">
                               <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Type of Existing Mortgage</strong>
                            </label></div><div class=\"datafeild\">
                            <div class=\"fields\" style=\"margin-top: 18px;\">
                                <input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"variable\" checked=\"checked\"/> Variable
                                &nbsp;&nbsp;<input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"fixed\" /> Fixed   
                            </div>
</div></div>
</div>
                         
                            <div class=\"pbox\">
                             <div class=\"sep lint\">
                                    <label for=\"loaninterest\" class=\"orange\"><strong>Existing Mortgage Rate (%)</strong> </label>
                                    <span></span></div><div class=\"datafeild\">
                                    <input id=\"loaninterest\" name=\"loaninterest\" value=\"2.99\" type=\"text\" />
                        <span class=\"prc-addon\">%</span>
                                <div id=\"loaninterestslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                                </div></div></div>
                                                          <div class=\"pbox\">
                               <div class=\"sep lint\">
                                    <label for=\"newloaninterest\" class=\"orange\"><strong>New Mortgage Rate (%)</strong> </label>
                                    <span></span></div><div class=\"datafeild\">
                                    <input id=\"newloaninterest\" name=\"newloaninterest\" value=\"1.99\" type=\"text\" />
                        <span class=\"prc-addon\">%</span>
                                <div id=\"newloaninterestslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                                </div></div></div>
                             <div class=\"refdetail1\">
                            <div class=\"pbox\">
                               <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Province</strong>
                            </label></div><div class=\"datafeild\">
                            <div class=\"fields\">
                            <select id=\"province\" name=\"province\" >
\t\t                <option value=\"AL\">Alberta</option>
\t\t                <option value=\"BC\">British Columbia</option>
                                <option value=\"MA\">Manitoba</option>
                                <option value=\"NB\">New Brunswick</option>
                                <option value=\"NE\">Newfoundland</option>
\t\t\t\t<option value=\"NS\">Nova Scotia</option>
                                <option value=\"NT\">Northwest Territories</option>
\t\t\t\t<option value=\"NU\">Nunavut</option>
                                <option value=\"ON\" selected=\"selected\">Ontario</option>
                                <option value=\"PE\">Prince Edward Island</option>
                                <option value=\"QU\">Quebec</option>
\t\t\t\t<option value=\"SK\">Saskatchewan</option>
\t\t\t\t<option value=\"YU\">Yukon</option>\t\t\t\t
\t\t\t    </select>    
                            </div></div></div>
                         
                            <div class=\"pbox\">
                               <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Mortgage Provider</strong>
                            </label></div><div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"provider\" name=\"provider\" >
\t\t                <option value=\"hsbc\">HSBC</option>
                                <option value=\"rbc\">RBC</option>
                                <option value=\"bmo\">BMO</option>
\t\t\t    </select>
                            </div></div></div></div>                              
                                </div></div></form>
                 <div class=\"box-7 resultam1\">
                    <strong class=\"orange\">Provider Dishcharge Fee</strong>
                    <input id=\"discharge-fee\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"text-align:center;color:rgb(35, 98, 2);\"/>
                </div>
                <div class=\"box-7 resultam1\">
                    <strong class=\"orange\">Mortgage Penalty</strong>
                    <input id=\"mortgage-penalty\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"text-align:center;color:rgb(35, 98, 2);\"/>
                </div>
       \t\t\t\t\t\t   
\t\t\t\t\t\t\t\t   
\t\t\t\t\t\t\t\t   
\t\t\t\t\t\t\t\t   
\t\t\t\t\t\t\t\t   
\t\t\t\t\t\t\t\t   
                        
                                    <div class=\"mortapb\" style=\"margin-top: 35px;\">  
                                        <a href=\"";
        // line 234
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\" class=\"an-button\">Calculate New Mortgage</a>
                                        &nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;
                                        <a href=\"";
        // line 236
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "fixed")), "html", null, true);
        echo "\" class=\"an-button\">Best Available Rates</a>
                                    </div>
                               
                            </article>
                        </div>   


 <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children active\">
                                                <li><a href=\"";
        // line 255
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 256
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 257
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 258
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                               
                                                <li><a href=\"";
        // line 260
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 261
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 262
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 263
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 264
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                     </ul>
                                </li>
                                <li> 
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                    <ul class=\"children\">
                                        
                                                ";
        // line 272
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 273
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 274
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 276
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 277
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    <ul class=\"children\">
                                       ";
        // line 284
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 285
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 286
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 288
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 289
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    <ul class=\"children\">
                                      ";
        // line 295
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 296
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 297
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 299
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 300
        echo "                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
                   
                                 </aside>
                    <!-- /SIDEBAR -->

                       </div></div>
        </section>
        ";
        // line 313
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "



        <script type=\"text/javascript\" src=\"";
        // line 317
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 318
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 319
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>

        <script type=\"text/javascript\" src=\"";
        // line 321
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 322
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 323
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/penalty.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 324
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 325
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
     
      
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:penalty.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  597 => 325,  593 => 324,  589 => 323,  585 => 322,  581 => 321,  576 => 319,  572 => 318,  568 => 317,  561 => 313,  546 => 300,  540 => 299,  532 => 297,  529 => 296,  525 => 295,  517 => 289,  511 => 288,  503 => 286,  500 => 285,  496 => 284,  487 => 277,  481 => 276,  473 => 274,  470 => 273,  466 => 272,  455 => 264,  451 => 263,  447 => 262,  443 => 261,  439 => 260,  434 => 258,  426 => 256,  422 => 255,  400 => 236,  395 => 234,  114 => 19,  260 => 189,  256 => 188,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 181,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 189,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 155,  150 => 80,  146 => 79,  134 => 76,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 128,  170 => 127,  148 => 90,  77 => 30,  231 => 183,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 36,  34 => 8,  155 => 27,  310 => 239,  306 => 238,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 230,  270 => 194,  251 => 188,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 32,  167 => 30,  137 => 94,  129 => 74,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 135,  197 => 114,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 20,  97 => 62,  76 => 17,  58 => 11,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 257,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 193,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 154,  224 => 178,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 33,  159 => 28,  143 => 24,  135 => 77,  119 => 42,  102 => 17,  71 => 12,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 34,  171 => 31,  166 => 126,  163 => 29,  158 => 94,  156 => 100,  151 => 26,  142 => 78,  138 => 77,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 41,  89 => 20,  85 => 14,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 29,  72 => 38,  69 => 28,  47 => 12,  40 => 8,  37 => 5,  22 => 2,  246 => 188,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 63,  98 => 15,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 20,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 113,  189 => 103,  187 => 35,  182 => 130,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 125,  154 => 107,  149 => 87,  147 => 25,  144 => 89,  141 => 95,  133 => 93,  130 => 71,  125 => 73,  122 => 48,  116 => 70,  112 => 69,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 50,  80 => 30,  73 => 29,  64 => 13,  60 => 6,  57 => 93,  54 => 92,  51 => 14,  48 => 10,  45 => 10,  42 => 22,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
