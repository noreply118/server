<?php

/* MainRatetradeBundle:Default:broker-login.html_1.twig */
class __TwigTemplate_1c70f3d1b38b350f6f6803e438dcf50529ef45f1a47984038b0dc8a6ccae1dfb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <title>Ratetrade.ca | Broker Login</title>
        <link rel=\"shortcut icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/styles.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,400italic,600,600italic,700,300italic,300,900|Roboto+Condensed:400,700,700italic,400italic,300italic,300' rel='stylesheet' type='text/css'>
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-77426284-3', 'auto');
            ga('send', 'pageview');

        </script>
    </head>
    <body>
        <header>
            <div class=\"top-area\" style=\"text-align: right;\">
                <a href=\"";
        // line 34
        echo $this->env->getExtension('routing')->getPath("broker_signup");
        echo "\" class=\"sup\">
                    <i class=\"fa fa-user-plus\" aria-hidden=\"true\"></i>
                    Broker Signup
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href=\"";
        // line 39
        echo $this->env->getExtension('routing')->getPath("broker_login");
        echo "\">
                    <i class=\"fa fa-key\" aria-hidden=\"true\"></i>
                    Login
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
            </div>
            <nav class=\"navbar navbar-default\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <div class=\"logo mobi-menu\">
                            <a href=\"";
        // line 56
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                <img src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                            </a>
                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <!-- Desktop / tab -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <div class=\"col-xs-12 col-sm-12 col-md-4 col-lg-4\">
                            <div class=\"logo\">
                                <a href=\"";
        // line 67
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                    <img src=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                                </a>
                            </div>
                        </div>
                        <div class=\"col-xs-12 col-sm-12 col-md-8 col-lg-8 text-center\">
                            <ul class=\"nav navbar-nav navbar-right\">
                                <li class=\"dropdown\">
                                    <a href=\"";
        // line 75
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\" class=\"visible-lg visible-md hidden\">
                                        <span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Home 
                                        <i class=\"fa fa-caret-down hidden\"></i>
                                    </a>
                                    <a href=\"";
        // line 79
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\" class=\" visible-xs visible-sm hidden\" id=\"mob-menu\">
                                        <span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Home 
                                        <i class=\"fa fa-caret-down\"></i>
                                    </a>
                                </li>
                                <li class=\"dropdown\">
                                    <a href=\"javascript:\" class=\"visible-lg visible-md hidden\"><span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Mortgages <i class=\"fa fa-caret-down hidden\"></i></a>
                                    <a href=\"javascript:\" class=\" visible-xs visible-sm hidden\" id=\"mob-menu\"><span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Mortgages <i class=\"fa fa-caret-down\"></i></a>

                                    <ul class=\"sub-menu-div\">
                                        <li><a href=\"#\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-percent\"></i> Rates <i class=\"fa fa-chevron-circle-right f-r\"></i></a> <a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-rates\"><i class=\"fa fa-percent\" ></i> Rates <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob\">
                                                <li><a href=\"";
        // line 91
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "\">Fixed Mortgage Rates</a></li>
                                                <li><a href=\"";
        // line 92
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "variable"));
        echo "\">Variable Mortgage Rates</a></li>

                                            </ul>

                                        </li>
                                        <li><a href=\"#\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-calculator\"></i> Calculators <i class=\"fa fa-chevron-circle-right f-r\"></i></a>
                                            <a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-calc\"><i class=\"fa fa-calculator\"></i> Calculator <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob2\">
                                                <li><a href=\"";
        // line 100
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 101
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 102
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 103
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 104
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 105
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 106
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                            </ul>

                                        </li>
                                        <li><a href=\"";
        // line 110
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-book\"></i> Home Buying Process <i class=\"fa fa-chevron-circle-right f-r\"></i></a><a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-mortgage\"><i class=\"fa fa-book\"></i> Home Buying Process <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob3\">
                                                <li><a href=\"";
        // line 112
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\">Buying Home in Canada</a></li>
                                                <li><a href=\"";
        // line 113
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "renewing-guide"));
        echo "\">Renewing Your Mortgage</a></li>
                                                <li><a href=\"";
        // line 114
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "mortgage-refinancing-guide"));
        echo "\">Mortgage Refinancing Guide</a></li>
                                            </ul>

                                        </li>     
                                    </ul>
                                </li>
                                <li class=\"right-end active\">
                                    <a href=\"";
        // line 121
        echo $this->env->getExtension('routing')->getPath("broker_list");
        echo "\">
                                        <span class=\"fa fa-users\" style=\"font-size:24px; \">                                            
                                        </span> Brokers </a>
                                </li>
                                <li class=\"right-end\"><a href=\"";
        // line 125
        echo $this->env->getExtension('routing')->getPath("contact_us");
        echo "\"> <span class=\"fa fa-paper-plane\" style=\"font-size:24px; \"></span> Contact</a></li>

                            </ul>

                        </div>
                    </div><!-- /.navbar-collapse -->

                    <!-- Mobile -->


                </div><!-- /.container-fluid -->
            </nav>


        </header>
        <section>
            <div class=\"middle-content-contact\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-xs-12 col-sm-7\">
                            <div class=\"col-xs-12\">
                                <h1 style=\"color: rgba(121,134,209,1.00); margin-left: 10px;\">Broker Login</h1>
                            </div>
                            <div id=\"error\" style=\"text-align: center;color: red;\">";
        // line 148
        echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "html", null, true);
        echo "</div>
                            <form class=\"form-class\" id=\"loginform\" action=\"";
        // line 149
        echo $this->env->getExtension('routing')->getPath("broker_logincheck");
        echo "\" method=\"post\" onsubmit=\"return validate()\">
                                <div class=\"form-group\">
                                    <label for=\"username\">Username or Email</label>
                                    <input type=\"text\" class=\"form-control required\" name=\"username\" id=\"username\" placeholder=\"Username\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"password\">Password</label>
                                    <input type=\"password\" class=\"form-control required\" name=\"password\" id=\"password\" placeholder=\"Password\">
                                </div>
                                <button type=\"submit\" class=\"btn btn-default\" id=\"submit\">Submit</button>
                            </form>
                        </div>
                        <div class=\"col-xs-12 col-sm-5 col-md-3\">
                            <div class=\"right-sidebar\">
                                <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
                                    <div class=\"panel panel-default\">
                                        <div class=\"panel-heading\" role=\"tab\" id=\"headingRates\">
                                            <h4 class=\"panel-title\">
                                                <i class=\"fa fa-percent\"></i> &nbsp; Rates
                                                <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseRates\" aria-expanded=\"true\" aria-controls=\"collapseRates\" class=\"right-btn\">
                                                    <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id=\"collapseRates\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingRates\">
                                            <div class=\"panel-body\">
                                                <ul>
                                                    <li><a href=\"";
        // line 176
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "\">Fixed Mortgage Rates</a></li>
                                                    <li><a href=\"";
        // line 177
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "variable"));
        echo "\">Variable Mortgage Rates</a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"panel panel-default\">
                                        <div class=\"panel-heading\" role=\"tab\" id=\"headingCalc\">
                                            <h4 class=\"panel-title\">
                                                <i class=\"fa fa-calculator\"></i> &nbsp; Calculators
                                                <a class=\"collapsed right-btn\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseCalc\" aria-expanded=\"false\" aria-controls=\"collapseCalc\">
                                                    <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id=\"collapseCalc\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingCalc\">
                                            <div class=\"panel-body\">
                                                <ul>
                                                    <li><a href=\"";
        // line 195
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                    <li><a href=\"";
        // line 196
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                    <li><a href=\"";
        // line 197
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                    <li><a href=\"";
        // line 198
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                    <li><a href=\"";
        // line 199
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                    <li><a href=\"";
        // line 200
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                    <li><a href=\"";
        // line 201
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"panel panel-default\">
                                        <div class=\"panel-heading\" role=\"tab\" id=\"headingMg\">
                                            <h4 class=\"panel-title\">
                                                <i class=\"fa fa-book\"></i> &nbsp; Home Buying Process
                                                <a class=\"collapsed right-btn\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseMg\" aria-expanded=\"false\" aria-controls=\"collapseMg\">
                                                    <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id=\"collapseMg\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingMg\">
                                            <div class=\"panel-body\">
                                                <ul class=\"levels\">
                                                    <li class=\"level1\">
                                                        ";
        // line 219
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 220
            echo "                                                            ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "6")) {
                // line 221
                echo "                                                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\" class=\"level1Btn\">Buying Home in Canada<span>
                                                                    ";
            }
            // line 223
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 224
        echo "                                                                <i class=\"fa fa-angle-down\"></i></span></a> 
                                                        <ul> 
                                                            ";
        // line 226
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 227
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 228
                echo "                                                                    <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                    ";
            }
            // line 230
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 231
        echo "                                                        </ul>
                                                    </li>
                                                    <li class=\"level2\">
                                                        ";
        // line 234
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 235
            echo "                                                            ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "18")) {
                // line 236
                echo "                                                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\" class=\"level2Btn\">Renewing Your Mortgage<span>
                                                                    ";
            }
            // line 238
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "       
                                                                <i class=\"fa fa-angle-down\"></i></span></a>
                                                        <ul>
                                                            ";
        // line 241
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 242
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 243
                echo "                                                                    <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                    ";
            }
            // line 245
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 246
        echo "                                                        </ul>
                                                    </li>
                                                    <li class=\"level3\">
                                                        ";
        // line 249
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 250
            echo "                                                            ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "1")) {
                // line 251
                echo "                                                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\" class=\"level3Btn\">Mortgage Refinancing Guide<span>
                                                                    ";
            }
            // line 253
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "        
                                                                <i class=\"fa fa-angle-down\"></i></span></a>
                                                        <ul>
                                                            ";
        // line 256
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 257
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 258
                echo "                                                                    <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                    ";
            }
            // line 260
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 261
        echo "                                                        </ul>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"panel panel-default\">
                                        <div class=\"panel-heading\" role=\"tab\" id=\"headingBroker\">
                                            <h4 class=\"panel-title\">
                                                &nbsp; Brokers
                                                <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseBroker\" aria-expanded=\"true\" aria-controls=\"collapseBroker\" class=\"right-btn\">
                                                    <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id=\"collapseBroker\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingBroker\">
                                            <div class=\"panel-body\">
                                                <ul>
                                                    <li><a href=\"";
        // line 280
        echo $this->env->getExtension('routing')->getPath("broker_list");
        echo "\">Brokers List</a></li>
                                                    <li><a href=\"";
        // line 281
        echo $this->env->getExtension('routing')->getPath("broker_signup");
        echo "\">Broker Registration</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>  
                </div>
            </div>
        </section>
        ";
        // line 294
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 296
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/bootstrap.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 297
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/menu-js.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script>
                                function validateEmail(email) {
                                    var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                    return re.test(email);
                                }

                                \$(document).on(\"click\", \".subsc\", function(e) {
                                    e.preventDefault();
                                    \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                    if (\$(\"#exampleInputEmail2\") == '')
                                    {
                                        \$(\"#exampleInputEmail2\").focus();
                                        \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                    }
                                    else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                    {
                                        \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                        \$(\"#exampleInputEmail2\").focus();
                                    }
                                    else {
                                        \$.ajax({
                                            url: '";
        // line 320
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                            type: \"post\",
                                            async: true,
                                            data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                'name': \"testname\"},
                                            success: function(response) {
                                                \$(\"#exampleInputEmail2\").val('');
                                                alert(response);
                                            },
                                            error: function(request, error) {
                                                // alert('No data found');
                                            }
                                        });
                                    }
                                });

                                \$(document).on(\"change\", \".required\", function() {
                                    \$(this).css('border', '1px solid green');

                                    if (\$(this).val() == '')
                                    {
                                        \$(this).focus();
                                        \$(this).css('border', '1px solid red');
                                    }

                                    var id = \$(this).attr('id');
                                    if (id == 'username' && !validateEmail(\$(\"#username\").val()))
                                    {
                                        \$(\"#username\").focus();
                                        \$(\"#username\").css('border', '1px solid red');
                                    }
                                });

                                function validate() {

                                    if (\$(\"#username\").val() == '')
                                    {
                                        \$(\"#username\").focus();
                                        \$(\"#username\").css('border', '1px solid red');
                                        return false;
                                    }
                                    else if (!validateEmail(\$(\"#username\").val()))
                                    {
                                        \$(\"#username\").css('border', '1px solid red');
                                        \$(\"#username\").focus();
                                        return false;
                                    }
                                    else if (\$(\"#password\").val() == '')
                                    {
                                        \$(\"#password\").focus();
                                        \$(\"#password\").css('border', '1px solid red');
                                        return false;
                                    }
                                }
        </script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:broker-login.html_1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  565 => 320,  468 => 256,  281 => 177,  465 => 216,  361 => 157,  332 => 149,  328 => 147,  320 => 143,  276 => 128,  272 => 126,  245 => 113,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 231,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 281,  492 => 203,  484 => 201,  410 => 173,  397 => 165,  388 => 170,  380 => 166,  366 => 224,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 199,  442 => 237,  417 => 178,  372 => 159,  336 => 150,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 255,  509 => 207,  482 => 240,  386 => 195,  357 => 182,  353 => 180,  344 => 199,  339 => 151,  335 => 175,  329 => 174,  321 => 171,  610 => 410,  462 => 192,  394 => 239,  370 => 226,  364 => 204,  349 => 212,  340 => 143,  325 => 172,  319 => 194,  304 => 185,  295 => 179,  289 => 176,  280 => 129,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 297,  531 => 226,  516 => 319,  476 => 204,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 128,  303 => 123,  292 => 127,  288 => 114,  510 => 280,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 241,  411 => 194,  389 => 184,  378 => 181,  311 => 137,  708 => 448,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 252,  483 => 260,  452 => 251,  448 => 226,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 41,  277 => 176,  521 => 214,  513 => 253,  508 => 216,  499 => 248,  495 => 247,  489 => 261,  472 => 257,  396 => 234,  392 => 171,  377 => 228,  356 => 202,  352 => 201,  348 => 149,  192 => 112,  883 => 685,  699 => 504,  449 => 250,  432 => 222,  428 => 180,  414 => 177,  406 => 175,  403 => 236,  399 => 203,  390 => 216,  376 => 164,  373 => 191,  369 => 158,  265 => 161,  261 => 104,  253 => 161,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 263,  535 => 296,  527 => 313,  524 => 298,  520 => 254,  505 => 250,  497 => 301,  494 => 231,  479 => 239,  475 => 258,  467 => 288,  458 => 253,  454 => 208,  450 => 194,  446 => 238,  184 => 82,  180 => 106,  172 => 104,  160 => 101,  152 => 30,  937 => 621,  809 => 496,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 218,  530 => 294,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 295,  477 => 270,  471 => 289,  463 => 242,  460 => 191,  456 => 228,  445 => 249,  441 => 268,  433 => 203,  429 => 185,  424 => 254,  420 => 228,  416 => 252,  412 => 251,  385 => 230,  382 => 277,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 297,  529 => 295,  525 => 215,  517 => 254,  511 => 304,  503 => 206,  500 => 205,  496 => 243,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 276,  451 => 224,  447 => 185,  443 => 192,  439 => 260,  434 => 245,  426 => 243,  422 => 178,  400 => 235,  395 => 172,  114 => 37,  260 => 189,  256 => 103,  248 => 114,  266 => 193,  262 => 121,  250 => 189,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 111,  275 => 194,  271 => 193,  267 => 137,  263 => 191,  259 => 158,  255 => 155,  239 => 185,  81 => 22,  65 => 18,  1085 => 1059,  210 => 121,  198 => 103,  194 => 133,  190 => 41,  186 => 131,  178 => 35,  150 => 41,  146 => 79,  134 => 24,  124 => 72,  104 => 67,  391 => 231,  383 => 214,  375 => 313,  371 => 159,  367 => 158,  363 => 157,  359 => 156,  351 => 220,  347 => 219,  188 => 36,  301 => 173,  293 => 151,  113 => 90,  174 => 34,  170 => 78,  148 => 29,  77 => 21,  231 => 130,  165 => 106,  161 => 105,  153 => 92,  195 => 96,  191 => 95,  34 => 8,  155 => 27,  310 => 197,  306 => 196,  302 => 195,  290 => 126,  286 => 131,  282 => 143,  274 => 153,  270 => 194,  251 => 139,  237 => 111,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 79,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 107,  215 => 151,  211 => 124,  207 => 58,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 221,  350 => 154,  346 => 220,  342 => 152,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 199,  206 => 99,  244 => 174,  236 => 133,  232 => 85,  228 => 84,  216 => 79,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 25,  53 => 15,  127 => 33,  97 => 62,  76 => 19,  58 => 26,  480 => 162,  474 => 198,  469 => 284,  461 => 155,  457 => 241,  453 => 186,  444 => 184,  440 => 246,  437 => 191,  435 => 186,  430 => 257,  427 => 260,  423 => 242,  413 => 226,  409 => 238,  407 => 205,  402 => 130,  398 => 173,  393 => 197,  387 => 215,  384 => 168,  381 => 182,  379 => 230,  374 => 227,  368 => 205,  365 => 189,  362 => 156,  360 => 223,  355 => 215,  341 => 105,  337 => 103,  322 => 200,  314 => 198,  312 => 136,  309 => 135,  305 => 136,  298 => 172,  294 => 133,  285 => 89,  283 => 130,  278 => 195,  268 => 124,  264 => 122,  258 => 97,  252 => 187,  247 => 149,  241 => 159,  229 => 109,  220 => 81,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 28,  61 => 17,  273 => 140,  269 => 94,  254 => 115,  243 => 148,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 106,  217 => 125,  208 => 165,  204 => 98,  179 => 33,  159 => 139,  143 => 37,  135 => 35,  119 => 75,  102 => 34,  71 => 12,  67 => 29,  63 => 22,  59 => 27,  201 => 77,  196 => 113,  183 => 100,  171 => 31,  166 => 77,  163 => 29,  158 => 30,  156 => 100,  151 => 26,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 67,  91 => 24,  62 => 27,  49 => 14,  87 => 16,  28 => 8,  94 => 35,  89 => 27,  85 => 14,  75 => 31,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 56,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 32,  72 => 13,  69 => 19,  47 => 24,  40 => 10,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 92,  139 => 65,  131 => 34,  123 => 32,  120 => 71,  115 => 30,  111 => 29,  108 => 40,  101 => 36,  98 => 36,  96 => 37,  83 => 33,  74 => 30,  66 => 28,  55 => 26,  52 => 12,  50 => 24,  43 => 23,  41 => 12,  35 => 8,  32 => 4,  29 => 9,  209 => 117,  203 => 148,  199 => 41,  193 => 44,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 102,  162 => 50,  154 => 71,  149 => 69,  147 => 25,  144 => 67,  141 => 91,  133 => 95,  130 => 23,  125 => 93,  122 => 39,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 27,  99 => 26,  95 => 25,  92 => 57,  86 => 33,  82 => 32,  80 => 20,  73 => 20,  64 => 20,  60 => 34,  57 => 16,  54 => 25,  51 => 25,  48 => 11,  45 => 13,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
