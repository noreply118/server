<?php

/* AcmeDemoBundle:Demo:login.html.twig */
class __TwigTemplate_9a3e753187e5dce5de4f2208b9994114d9106edf37cb99348356e5af25791451 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0;\">
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>Login</title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"/symfonyratetrade/web/bundles/acmedemo/css/common.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/symfonyratetrade/web/bundles/acmedemo/css/login.css\">
</head>
<body>
<div class=\"header\">
<div class=\"wrapper\">
<a href=\"#\" onclick=\"window.history.back();\" class=\"home-ico\"><img src=\"/symfonyratetrade/web/bundles/acmedemo/images/back.png\"></a>
  <span class=\"page-name\" style=\"width:60%;\">Login</span>
  </div>
</div>
<div class=\"headerfix\"></div>
<div class=\"wrapper bodywrapper\">
          <form  action=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("logincheck");
        echo "\" method=\"post\">
          <h3>Don't Have an Account, <div style=\"display:inline-block;\"><a id=\"login-back\" href=\"/\">Register Now</a></div></h3>
                           <label>Mobile Number</label>
                 <input type=\"text\" id=\"username\" placeholder=\"Mobile Number\" name=\"_username\" value=\"\"/>
                 <label>Password</label>
                 <input type=\"password\" id=\"password\" placeholder=\"Password\" name=\"_password\" value=\"\"/>
          <input type=\"submit\" value=\"Login\" />
          <a href=\"#\" id=\"forgotpass\">Forgot Password?</a>
          </form>
<div class=\"recoverpass\">
<a href=\"#\" class=\"closerecover\">X</a>
<div style=\"clear:both\"></div>
<form method=\"post\" name=\"recoverpass\" action=\"\" id=\"recoveryform\">
<span>Send Password to Your Registered Mobile No.</span>
<input type=\"text\" name=\"rmobile\" id=\"rmobile\" class=\"rmobile\" placeholder=\"Enter Registered Mobile No.*\" maxlength=\"10\">
<input type=\"button\" name=\"rsubmit\" id=\"rsubmit\" value=\"Send\">
</form>
<div id=\"success\"></div>
<div id=\"fail\"></div>
</div>
</div> 
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 130,  161 => 129,  153 => 127,  195 => 134,  191 => 133,  34 => 8,  155 => 93,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 134,  167 => 127,  137 => 94,  129 => 92,  23 => 3,  223 => 134,  215 => 139,  211 => 138,  207 => 137,  202 => 128,  197 => 105,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 97,  305 => 95,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 131,  140 => 55,  132 => 51,  128 => 49,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 154,  219 => 133,  217 => 153,  208 => 165,  204 => 164,  179 => 135,  159 => 109,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 13,  201 => 149,  196 => 90,  183 => 131,  171 => 128,  166 => 71,  163 => 126,  158 => 79,  156 => 66,  151 => 92,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 64,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 9,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 6,  19 => 1,  93 => 28,  88 => 31,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 6,  37 => 14,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 15,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 151,  203 => 136,  199 => 135,  193 => 104,  189 => 103,  187 => 132,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 107,  149 => 97,  147 => 58,  144 => 49,  141 => 95,  133 => 93,  130 => 41,  125 => 44,  122 => 48,  116 => 41,  112 => 42,  109 => 65,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 36,  86 => 51,  82 => 50,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 19,  36 => 5,  33 => 4,  30 => 10,);
    }
}
