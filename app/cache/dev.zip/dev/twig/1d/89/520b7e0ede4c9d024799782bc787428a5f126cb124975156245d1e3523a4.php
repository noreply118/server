<?php

/* MainRatetradeBundle:Default:mortgage-rates.html_1.twig */
class __TwigTemplate_1d89520b7e0ede4c9d024799782bc787428a5f126cb124975156245d1e3523a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <title>Best Mortgage Rates</title>
        <link rel=\"shortcut icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/styles.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,400italic,600,600italic,700,300italic,300,900|Roboto+Condensed:400,700,700italic,400italic,300italic,300' rel='stylesheet' type='text/css'>
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-77426284-3', 'auto');
            ga('send', 'pageview');

        </script>
    </head>

    <body>
        <header>
            <div class=\"top-area\" style=\"text-align: right;\">
                <a href=\"";
        // line 36
        echo $this->env->getExtension('routing')->getPath("broker_signup");
        echo "\">
                    Broker Signup
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("broker_login");
        echo "\">
                    Login
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
            </div>
            <nav class=\"navbar navbar-default\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <div class=\"logo mobi-menu\">
                            <a href=\"";
        // line 56
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                <img src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                            </a></div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <!-- Desktop / tab -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <div class=\"col-xs-12 col-sm-12 col-md-4 col-lg-4\">
                            <div class=\"logo\">
                                <a href=\"";
        // line 66
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                    <img src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                                </a></div>
                        </div>
                        <div class=\"col-xs-12 col-sm-12 col-md-8 col-lg-8 text-center\">
                            <ul class=\"nav navbar-nav navbar-right\">
                                <li class=\"dropdown\">
                                    <a href=\"";
        // line 73
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\" class=\"visible-lg visible-md hidden\">
                                        <span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Home 
                                        <i class=\"fa fa-caret-down hidden\"></i>
                                    </a>
                                    <a href=\"";
        // line 77
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\" class=\" visible-xs visible-sm hidden\" id=\"mob-menu\">
                                        <span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Home 
                                        <i class=\"fa fa-caret-down\"></i>
                                    </a>
                                </li>
                                <li class=\"dropdown active\">
                                    <a href=\"javascript:\" class=\"visible-lg visible-md hidden\"><span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Mortgages <i class=\"fa fa-caret-down hidden\"></i></a>
                                    <a href=\"javascript:\" class=\" visible-xs visible-sm hidden\" id=\"mob-menu\"><span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Mortgages <i class=\"fa fa-caret-down\"></i></a>

                                    <ul class=\"sub-menu-div\">
                                        <li><a href=\"#\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-percent\"></i> Rates <i class=\"fa fa-chevron-circle-right f-r\"></i></a> <a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-rates\"><i class=\"fa fa-percent\" ></i> Rates <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob\">
                                                <li><a href=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "fixed")), "html", null, true);
        echo "\">Fixed Mortgage Rates</a></li>
                                                <li><a href=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "variable")), "html", null, true);
        echo "\">Variable Mortgage Rates</a></li>
                                            </ul>

                                        </li>
                                        <li><a href=\"#\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-calculator\"></i> Calculators <i class=\"fa fa-chevron-circle-right f-r\"></i></a>
                                            <a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-calc\"><i class=\"fa fa-calculator\"></i> Calculator <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob2\">
                                                <li><a href=\"";
        // line 97
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 98
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 99
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 100
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 101
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 102
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 103
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                            </ul>

                                        </li>
                                        <li><a href=\"";
        // line 107
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-book\"></i> Home Buying Process <i class=\"fa fa-chevron-circle-right f-r\"></i></a><a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-mortgage\"><i class=\"fa fa-book\"></i> Home Buying Process <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob3\">
                                                <li><a href=\"";
        // line 109
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\">Buying Home in Canada</a></li>
                                                <li><a href=\"";
        // line 110
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "renewing-guide"));
        echo "\">Renewing Your Mortgage</a></li>
                                                <li><a href=\"";
        // line 111
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "mortgage-refinancing-guide"));
        echo "\">Mortgage Refinancing Guide</a></li>
                                            </ul>

                                        </li>     
                                    </ul>
                                </li>
                                <li class=\"right-end\">
                                    <a href=\"";
        // line 118
        echo $this->env->getExtension('routing')->getPath("broker_list");
        echo "\">
                                        <span class=\"fa fa-users\" style=\"font-size:24px; \">                                            
                                        </span> Brokers </a>
                                </li>
                                <li class=\"right-end\"><a href=\"";
        // line 122
        echo $this->env->getExtension('routing')->getPath("contact_us");
        echo "\"> <span class=\"fa fa-paper-plane\" style=\"font-size:24px; \"></span> Contact</a></li>

                            </ul>

                        </div>
                    </div><!-- /.navbar-collapse -->

                    <!-- Mobile -->


                </div><!-- /.container-fluid -->
            </nav>


        </header>
        <section class=\"inner-page\">

            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-xs-12\">
                        <div class=\"row\">

                            <div class=\"col-xs-12 col-sm-5 col-md-3\">
                                <div class=\"location-box\">
                                    ";
        // line 158
        echo "
                                </div>
                            </div>
                            <div class=\"col-xs-12 col-sm-7 col-md-9\">
                                <h1 class=\"best-r-heading\"><i class=\"fa fa-arrow-circle-o-right\"></i>&nbsp;Best Mortgage Rates</h1>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-xs-12\">
                        <div class=\"row\">
                            <!-- sidebar -->
                            <div class=\"col-xs-12 col-sm-5 col-md-3\">
                                <div class=\"right-sidebar\">
                                    <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
                                        <div class=\"panel panel-default\">
                                            <div class=\"panel-heading\" role=\"tab\" id=\"headingRates\">
                                                <h4 class=\"panel-title\">
                                                    <i class=\"fa fa-percent\"></i> &nbsp; Rates
                                                    <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseRates\" aria-expanded=\"true\" aria-controls=\"collapseRates\" class=\"right-btn\">
                                                        <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id=\"collapseRates\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingRates\">
                                                <div class=\"panel-body\">
                                                    <ul>
                                                        <li><a href=\"";
        // line 184
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "fixed")), "html", null, true);
        echo "\">Fixed Mortgage Rates</a></li>
                                                        <li><a href=\"";
        // line 185
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "variable")), "html", null, true);
        echo "\">Variable Mortgage Rates</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"panel panel-default\">
                                            <div class=\"panel-heading\" role=\"tab\" id=\"headingCalc\">
                                                <h4 class=\"panel-title\">
                                                    <i class=\"fa fa-calculator\"></i> &nbsp; Calculators
                                                    <a class=\"collapsed right-btn\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseCalc\" aria-expanded=\"false\" aria-controls=\"collapseCalc\">
                                                        <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id=\"collapseCalc\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingCalc\">
                                                <div class=\"panel-body\">
                                                    <ul>
                                                        <li><a href=\"";
        // line 202
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                        <li><a href=\"";
        // line 203
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                        <li><a href=\"";
        // line 204
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                        <li><a href=\"";
        // line 205
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                        <li><a href=\"";
        // line 206
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                        <li><a href=\"";
        // line 207
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                        <li><a href=\"";
        // line 208
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"panel panel-default\">
                                            <div class=\"panel-heading\" role=\"tab\" id=\"headingMg\">
                                                <h4 class=\"panel-title\">
                                                    <i class=\"fa fa-book\"></i> &nbsp; Home Buying Process
                                                    <a class=\"collapsed right-btn\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseMg\" aria-expanded=\"false\" aria-controls=\"collapseMg\">
                                                        <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id=\"collapseMg\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingMg\">
                                                <div class=\"panel-body\">
                                                    <ul class=\"levels\">
                                                        <li class=\"level1\"><a href=\"javascript:\" class=\"level1Btn\">Buying Home in Canada<span><i class=\"fa fa-angle-down\"></i></span></a> 
                                                            <ul>   
                                                                ";
        // line 227
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 228
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 229
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 231
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 232
        echo "                                                            </ul>
                                                        </li>
                                                        <li class=\"level2\"><a href=\"#\" class=\"level2Btn\">Renewing Your Mortgage<span><i class=\"fa fa-angle-down\"></i></span></a>
                                                            <ul>   
                                                                ";
        // line 236
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 237
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 238
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 240
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 241
        echo "                                                            </ul>
                                                        </li>
                                                        <li class=\"level3\"><a href=\"#\" class=\"level3Btn\">Mortgage Refinancing Guide<span><i class=\"fa fa-angle-down\"></i></span></a>
                                                            <ul>   
                                                                ";
        // line 245
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 246
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 247
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 249
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 250
        echo "                                                            </ul>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"panel panel-default\">
                                            <div class=\"panel-heading\" role=\"tab\" id=\"headingBroker\">
                                                <h4 class=\"panel-title\">
                                                    &nbsp; Brokers
                                                    <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseBroker\" aria-expanded=\"true\" aria-controls=\"collapseBroker\" class=\"right-btn\">
                                                        <i class=\"fa fa-2x fa-plus-circle\"></i>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id=\"collapseBroker\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingBroker\">
                                                <div class=\"panel-body\">
                                                    <ul>
                                                        <li><a href=\"";
        // line 269
        echo $this->env->getExtension('routing')->getPath("broker_list");
        echo "\">Brokers List</a></li>
                                                        <li><a href=\"";
        // line 270
        echo $this->env->getExtension('routing')->getPath("broker_signup");
        echo "\">Broker Registration</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=\"col-xs-12 col-sm-7 col-md-9\">
                                <div class=\"left-content\">

                                    <div class=\"content-boxes\">
                                        <h3>&nbsp;</h3>
                                    </div>
                                    <!-- Div Box -->   
                                    <div class=\"best-rate-box\">
                                        <h4>
                                            Our Mortgages Rates
                                        </h4>
                                        <table align=\"left\" cellspacing=\"0\" cellpadding=\"0\" class=\"table-rates fixed\">
                                            <tbody>
                                                <tr>
                                                    <th scope=\"col\">Rate</th>
                                                    <th scope=\"col\" align=\"center\">Term</th>
                                                    <th scope=\"col\" align=\"center\">Type</th>
                                                    <th scope=\"col\" align=\"center\">&nbsp;</th>
                                                </tr>

                                                ";
        // line 298
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rates"]) ? $context["rates"] : $this->getContext($context, "rates")));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 299
            echo "                                                    <tr>
                                                        <td>
                                                            <span class=\"rt-rate\">
                                                                ";
            // line 302
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "<sup>%</sup>
                                                            </span>
                                                        </td>  
                                                        <td class=\"terms\">";
            // line 305
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "html", null, true);
            echo "</td>
                                                        <td class=\"type\">";
            // line 306
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"), "html", null, true);
            echo "</td>
                                                        <td><span class=\"get_this-rate\">
                                                                <a rt-popup=\"\" href=\"#\" data-toggle=\"modal\" data-target=\"#agentModal1\" class=\"rate-btn ";
            // line 308
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "\">
                                                                    <span class=\"wide\">
                                                                        <button class=\"btn btn-success rh-button\">
                                                                            Choose Rate
                                                                        </button>
                                                                    </span>
                                                                </a>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 319
        echo "                                            </tbody>
                                        </table>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        ";
        // line 331
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact For Rate <span id=\"rate-r\"></span> %</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 374
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 375
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 376
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 378
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 380
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 381
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\">Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"modal-footer\">

                    </div>
                </div>
            </div>
        </div>
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 412
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/bootstrap.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 413
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/menu-js.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script>
                                                    \$(document).on(\"click\", \".rate-btn\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#rate-request\").val(\$(this).attr(\"class\").split(\" \")[1]);
                                                        \$(\"#rate-r\").html(\$(this).attr(\"class\").split(\" \")[1]);
                                                    });

                                                    \$('.locations').on('click', function() {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function() {
                                                        \$('.level1 ul').toggle(500);

                                                    });
                                                    \$('.level2Btn').on('click', function() {
                                                        \$('.level2 ul').toggle(500);

                                                    });
                                                    \$('.level3Btn').on('click', function() {
                                                        \$('.level3 ul').toggle(500);

                                                    });

                                                    \$('#agentLocationName').click(function(e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function(e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function() {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }



                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"change\", \".required\", function() {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function(e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 522
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function() {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function(response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                },
                                                                error: function(request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:mortgage-rates.html_1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  750 => 522,  634 => 412,  595 => 380,  571 => 374,  485 => 305,  297 => 203,  874 => 583,  801 => 513,  692 => 416,  688 => 415,  684 => 414,  679 => 412,  675 => 411,  671 => 410,  612 => 373,  562 => 329,  624 => 376,  545 => 371,  605 => 336,  601 => 381,  575 => 375,  488 => 209,  776 => 467,  703 => 397,  573 => 390,  557 => 276,  401 => 183,  287 => 131,  1156 => 880,  1083 => 810,  963 => 692,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 611,  830 => 605,  824 => 604,  813 => 601,  800 => 593,  794 => 592,  786 => 590,  783 => 589,  779 => 588,  768 => 580,  764 => 579,  760 => 578,  756 => 577,  752 => 576,  748 => 575,  744 => 574,  740 => 573,  732 => 571,  405 => 184,  333 => 146,  307 => 137,  299 => 186,  257 => 136,  807 => 497,  617 => 374,  611 => 311,  596 => 307,  591 => 306,  491 => 210,  431 => 187,  415 => 284,  291 => 173,  284 => 177,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 378,  582 => 396,  578 => 327,  317 => 208,  565 => 320,  468 => 306,  281 => 177,  465 => 236,  361 => 157,  332 => 173,  328 => 147,  320 => 201,  276 => 125,  272 => 124,  245 => 153,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 386,  563 => 230,  559 => 236,  550 => 290,  547 => 231,  542 => 288,  514 => 281,  492 => 252,  484 => 201,  410 => 173,  397 => 246,  388 => 169,  380 => 201,  366 => 236,  331 => 187,  323 => 139,  315 => 141,  300 => 131,  296 => 130,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 291,  548 => 304,  533 => 300,  528 => 216,  478 => 310,  442 => 226,  417 => 235,  372 => 199,  336 => 164,  924 => 587,  851 => 517,  826 => 532,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 378,  625 => 341,  620 => 323,  616 => 322,  555 => 266,  538 => 287,  534 => 308,  526 => 306,  509 => 245,  482 => 217,  386 => 222,  357 => 158,  353 => 156,  344 => 192,  339 => 227,  335 => 175,  329 => 204,  321 => 151,  610 => 337,  462 => 192,  394 => 224,  370 => 237,  364 => 197,  349 => 200,  340 => 175,  325 => 203,  319 => 194,  304 => 185,  295 => 174,  289 => 176,  280 => 126,  126 => 79,  845 => 613,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 413,  630 => 301,  618 => 298,  614 => 297,  539 => 229,  531 => 227,  516 => 319,  476 => 258,  464 => 282,  421 => 221,  343 => 228,  324 => 145,  316 => 184,  313 => 207,  303 => 154,  292 => 129,  288 => 128,  510 => 280,  506 => 258,  502 => 233,  498 => 232,  425 => 222,  419 => 198,  411 => 194,  389 => 180,  378 => 181,  311 => 139,  708 => 550,  619 => 362,  580 => 376,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 305,  512 => 246,  483 => 208,  452 => 241,  448 => 206,  436 => 225,  408 => 249,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 602,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 32,  277 => 176,  521 => 282,  513 => 280,  508 => 216,  499 => 212,  495 => 247,  489 => 306,  472 => 257,  396 => 234,  392 => 185,  377 => 219,  356 => 195,  352 => 194,  348 => 193,  192 => 112,  883 => 685,  699 => 504,  449 => 273,  432 => 222,  428 => 267,  414 => 250,  406 => 213,  403 => 175,  399 => 204,  390 => 223,  376 => 200,  373 => 238,  369 => 217,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 419,  700 => 418,  696 => 417,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 342,  570 => 279,  564 => 326,  556 => 324,  549 => 372,  541 => 262,  535 => 296,  527 => 264,  524 => 298,  520 => 248,  505 => 297,  497 => 295,  494 => 308,  479 => 302,  475 => 285,  467 => 283,  458 => 250,  454 => 233,  450 => 232,  446 => 290,  184 => 107,  180 => 106,  172 => 104,  160 => 101,  152 => 57,  937 => 686,  809 => 600,  759 => 493,  753 => 462,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 372,  603 => 275,  599 => 351,  553 => 232,  536 => 228,  530 => 294,  522 => 219,  519 => 304,  515 => 261,  507 => 282,  501 => 256,  493 => 254,  490 => 293,  486 => 251,  477 => 270,  471 => 237,  463 => 242,  460 => 281,  456 => 228,  445 => 272,  441 => 271,  433 => 269,  429 => 282,  424 => 266,  420 => 265,  416 => 264,  412 => 214,  385 => 179,  382 => 193,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 282,  576 => 319,  572 => 318,  568 => 254,  561 => 277,  546 => 289,  540 => 309,  532 => 284,  529 => 284,  525 => 331,  517 => 281,  511 => 319,  503 => 206,  500 => 205,  496 => 220,  487 => 251,  481 => 286,  473 => 308,  470 => 298,  466 => 194,  455 => 195,  451 => 224,  447 => 247,  443 => 246,  439 => 270,  434 => 239,  426 => 200,  422 => 232,  400 => 247,  395 => 246,  114 => 19,  260 => 162,  256 => 103,  248 => 114,  266 => 124,  262 => 121,  250 => 116,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 142,  275 => 171,  271 => 164,  267 => 163,  263 => 123,  259 => 122,  255 => 129,  239 => 150,  81 => 53,  65 => 21,  1085 => 1059,  210 => 121,  198 => 103,  194 => 123,  190 => 110,  186 => 109,  178 => 35,  150 => 28,  146 => 27,  134 => 84,  124 => 77,  104 => 66,  391 => 209,  383 => 214,  375 => 163,  371 => 159,  367 => 161,  363 => 177,  359 => 168,  351 => 171,  347 => 153,  188 => 42,  301 => 204,  293 => 202,  113 => 90,  174 => 34,  170 => 108,  148 => 95,  77 => 52,  231 => 110,  165 => 100,  161 => 99,  153 => 97,  195 => 106,  191 => 42,  34 => 11,  155 => 30,  310 => 197,  306 => 176,  302 => 195,  290 => 180,  286 => 146,  282 => 166,  274 => 153,  270 => 194,  251 => 128,  237 => 127,  233 => 138,  225 => 127,  213 => 87,  205 => 78,  175 => 35,  167 => 33,  137 => 84,  129 => 82,  23 => 3,  223 => 119,  215 => 135,  211 => 119,  207 => 118,  202 => 118,  197 => 111,  185 => 117,  181 => 101,  70 => 29,  358 => 156,  354 => 231,  350 => 210,  346 => 229,  342 => 165,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 142,  206 => 92,  244 => 112,  236 => 133,  232 => 131,  228 => 84,  216 => 96,  212 => 95,  200 => 126,  110 => 36,  90 => 34,  84 => 28,  53 => 24,  127 => 33,  97 => 62,  76 => 41,  58 => 11,  480 => 234,  474 => 299,  469 => 284,  461 => 302,  457 => 234,  453 => 206,  444 => 192,  440 => 246,  437 => 270,  435 => 269,  430 => 257,  427 => 211,  423 => 194,  413 => 234,  409 => 238,  407 => 192,  402 => 226,  398 => 211,  393 => 245,  387 => 241,  384 => 168,  381 => 240,  379 => 230,  374 => 227,  368 => 198,  365 => 189,  362 => 156,  360 => 232,  355 => 227,  341 => 156,  337 => 155,  322 => 173,  314 => 158,  312 => 136,  309 => 206,  305 => 205,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 195,  268 => 123,  264 => 122,  258 => 97,  252 => 117,  247 => 149,  241 => 158,  229 => 109,  220 => 113,  214 => 122,  177 => 103,  169 => 101,  140 => 27,  132 => 61,  128 => 85,  107 => 28,  61 => 14,  273 => 185,  269 => 184,  254 => 159,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 144,  227 => 129,  224 => 141,  221 => 98,  219 => 88,  217 => 125,  208 => 96,  204 => 83,  179 => 114,  159 => 31,  143 => 90,  135 => 25,  119 => 31,  102 => 19,  71 => 42,  67 => 29,  63 => 37,  59 => 27,  201 => 115,  196 => 113,  183 => 100,  171 => 34,  166 => 32,  163 => 32,  158 => 30,  156 => 47,  151 => 95,  142 => 89,  138 => 25,  136 => 26,  121 => 92,  117 => 73,  105 => 61,  91 => 59,  62 => 36,  49 => 14,  87 => 28,  28 => 8,  94 => 35,  89 => 51,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 52,  88 => 56,  78 => 31,  46 => 23,  44 => 12,  27 => 7,  79 => 26,  72 => 40,  69 => 40,  47 => 21,  40 => 8,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 53,  139 => 89,  131 => 24,  123 => 32,  120 => 37,  115 => 20,  111 => 29,  108 => 67,  101 => 18,  98 => 36,  96 => 31,  83 => 27,  74 => 30,  66 => 43,  55 => 26,  52 => 12,  50 => 15,  43 => 23,  41 => 12,  35 => 12,  32 => 12,  29 => 9,  209 => 132,  203 => 94,  199 => 93,  193 => 110,  189 => 109,  187 => 41,  182 => 108,  176 => 105,  173 => 102,  168 => 56,  164 => 105,  162 => 31,  154 => 29,  149 => 69,  147 => 28,  144 => 94,  141 => 85,  133 => 44,  130 => 23,  125 => 93,  122 => 78,  116 => 36,  112 => 65,  109 => 68,  106 => 41,  103 => 59,  99 => 26,  95 => 60,  92 => 57,  86 => 15,  82 => 32,  80 => 20,  73 => 14,  64 => 32,  60 => 40,  57 => 16,  54 => 16,  51 => 25,  48 => 11,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
