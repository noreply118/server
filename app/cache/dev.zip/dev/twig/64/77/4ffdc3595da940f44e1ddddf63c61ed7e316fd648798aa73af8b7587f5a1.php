<?php

/* MainRatetradeBundle:Default:city-rates.html.twig */
class __TwigTemplate_64774ffdc3595da940f44e1ddddf63c61ed7e316fd648798aa73af8b7587f5a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title>Ratetrade.ca : Find the best ";
        // line 4
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"Ratetrade.ca : Find the best ";
        // line 10
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\" />
        <meta name=\"description\" content=\"Find the best ";
        // line 11
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " that work perfectly for you. We make it easy to compare rates in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " big banks and top brokers for free.\" /> 
        
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"Ratetrade.ca : Find the best ";
        // line 14
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta name=\"og:description\" content=\"Find the best ";
        // line 15
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " that work perfectly for you. We make it easy to compare rates in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " big banks and top brokers for free.\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"Find the best ";
        // line 19
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " that work perfectly for you. We make it easy to compare rates in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " big banks and top brokers for free.\">
        <meta name=\"twitter:title\" content=\"Ratetrade.ca : Find the best ";
        // line 20
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo " mortgage rate in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" />
        <meta name=\"keywords\" content=\"Mortgage Rates ";
        // line 23
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo ", interest, compare mortgage rates ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo ", current mortgage rates ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo ", best mortgage rates ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo ", lowest mortgage rates ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo "\" />
         <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
         <script language=\"JavaScript\" 
                src=\"https://www.iplocationtools.com/iplocationtools.js?key=7b71786a7773756d6a207270\">
        </script>
   

    ";
        // line 44
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "

<!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Best Mortgage Rates in ";
        // line 53
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " </h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">Best Mortgage Rates in ";
        // line 57
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo " </li>
                </ul>
            </div>
        </section>

<!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
                                           <div class=\"best-rate-box\">
                                        <table align=\"left\" cellspacing=\"0\" cellpadding=\"0\" class=\"table-rates fixed\">
                                            <tbody>
                                                <tr>
                                                    <th scope=\"col\">Rate</th>
                                                    <th scope=\"col\" align=\"center\">Term</th>
                                                    <th scope=\"col\" align=\"center\">Type</th>
                                                    <th scope=\"col\" align=\"center\">&nbsp;</th>
                                                </tr>

                                                ";
        // line 86
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rates"]) ? $context["rates"] : $this->getContext($context, "rates")));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 87
            echo "                                                    <tr>
                                                        <td>
                                                            <span class=\"rt-rate\">
                                                                ";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "<sup>%</sup>
                                                            </span>
                                                        </td>  
                                                        <td class=\"terms\">";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "html", null, true);
            echo "</td>
                                                        <td class=\"type\">";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"), "html", null, true);
            echo "</td>
                                                        <td><span class=\"get_this-rate\">
                                                                <a rt-popup=\"\" href=\"#\" data-toggle=\"modal\" data-target=\"#agentModal1\" class=\"rate-btn ";
            // line 96
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "\">
                                                                    <span class=\"wide\">
                                                                        <button class=\"btn btn-success rh-button\">
                                                                            Apply Now
                                                                        </button>
                                                                    </span>
                                                                </a>
                                                            </span>
                                                            <a rt-popup=\"\" href=\"";
            // line 104
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("compare_rates", array("rate" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "term" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "type" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"))), "html", null, true);
            echo "\">
                                                                Compare
                                                            </a>
                                                        </td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "                                            </tbody>
                                        </table>
                                    </div>
                                    <br/><br/>
                                    <div>
                                        ";
        // line 115
        if (((isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype")) == "fixed")) {
            // line 116
            echo "                                            <p>A Fixed Rate Mortgage is a mortgage of any fixed term such as (1 year, 3 years, 5 years, and 10 years) in which interest rate is fixed and is not changed during the mortgage term. If you have taken variable rate mortgage, most of the lenders will allow you lock-in your variable rate mortgage into a fixed rate mortgage.</p> 
                                            <strong>Advantages</strong>
<ul>
                                            <li>Your interest rate and mortgage payment will be same throughout the mortgage term.</li>
                                            <li>It gives borrowers security and comfort of knowing that their payment won’t change with any changes in the market or the economy.</li>
                                            <li>It brings stability and consistency as loan payment will remain same throughout the term.</li>
                                            <li>Fixed-rate mortgages are very easy to understand, and comprehend as they vary very little from lender to lender.</li>
</ul>
                                            <strong>Disadvantages</strong>
                                            <ul><li>A fixed rate mortgage also means you don’t have to pay less when interest rate declines. If the interest rates are trending downwards, you will keep on paying higher rate than those who have opted for variable rate mortgage.</li>
                                            <li>Fixed rates are better option for those who are borrowing for long term. However, if one wants to leave home after a few years, one will actually have to pay more than they need to pay for early payment in case of variable rate mortgage.</li>
                                            <li>These rates lacks individual customisations usually offered to variable rate mortgage holders as fixed rate mortgages are usually identical from lender to lender.</li></ul>
                                            <strong>Why Should I Compare Fixed Mortgage Rates in ";
            // line 128
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
            echo "?</strong>
                                            <p>With our easy to use platform for comparing fixed rate mortgages in ";
            // line 129
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
            echo ", you will be able to search, compare and choose the fixed mortgage rates with best terms and lowest interest rates in ";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
            echo ". You will not repent for bearing a loss due to choosing a wrong mortgage with higher interest rates and complex terms and conditions. We do all the legwork to make mortgage payment easy, fast and simple for you.
                                            ";
        } else {
            // line 131
            echo "                                            <p>A variable-rate mortgage is also known as floating rate mortgage in which rate of interest payable changes periodically based on an index which shows the cost to the lender of borrowing on the credit markets.</p>
                                            <ul><li>Variable-rate mortgages have lower initial interest rates than fixed-rate mortgages and hence borrower has to bear lower monthly mortgage payments.</li>
                                            <li>As the payments for variable rate mortgage are affordable, it is easy to qualify for variable rate mortgage than fixed rate mortgages.</li>
                                            <li>These mortgages are more flexible than their fixed-rate counterparts, so that borrowers can choose for terms that provide lower initial payments ranging anywhere from one month to 10 years.
                                            <li>Variable-rate mortgagesis also ideal option for borrowers who don’t wish to live in a home for more than few years as well as those who don’t  expect to pay off their mortgages rapidly.</ul> 
                                                <strong>Cons</strong><ul>
                                            <li>One of the biggest disadvantages of variable rate mortgage is payment shock. A borrower may have to pay higher monthly mortgage payments if there is sudden rapid increase in the interest rate.</li>
                                            <li>Variable rate mortgages are generally more complex than their fixed-rate mortgages as they are available in a variety of loans. As interest vary from time to time, it is not easy to compare the cost of mortgage being offered by different lenders.</li>
                                            <li>The changing mortgage rate makes it difficult to predict future payments and it eventually makes difficult for borrowers to make monthly budgets.</li></ul>
                                            <strong>Why should I Compare Variable Mortgage Rates in ";
            // line 140
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
            echo "?</strong>
                                            <p>With our easy to use platform for comparing variable rate mortgages in ";
            // line 141
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
            echo ", you will be able to search, compare and choose the fixed mortgage rates with best terms and lowest interest rates in ";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
            echo ". You will not repent for bearing a loss due to choosing a wrong mortgage with higher interest rates and complex terms and conditions. We do all the legwork to make mortgage payment easy, fast and simple for you.</p>
                                        ";
        }
        // line 143
        echo "                                    </div>
                                    
                                    ";
        // line 145
        if ((twig_length_filter($this->env, (isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities"))) > 0)) {
            // line 146
            echo "                                        <strong>Find Mortgage Rates ";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
            echo " By City</strong>
                                        <br/>
                                        <ul class=\"listfrate\">
                                            ";
            // line 149
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities")));
            foreach ($context['_seq'] as $context["key"] => $context["c"]) {
                // line 150
                echo "                                               <li>
                                                    <a href=\"";
                // line 151
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("city_ratetypes", array("target" => $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "urlLink"), "ratetype" => (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype")))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo " Mortgage Rates </a>
                                               </li>
                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['c'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 154
            echo "                                        </ul>
<div class=\"clear\"></div>
                                    ";
        }
        // line 157
        echo "                                </div>
                            </div>
                        </div>
                        <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>

<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-percent\"></i> &nbsp; Fixed Mortgage Rates</a>
                                    <ul class=\"children active\">
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 173
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/1-year/fixed\">1 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 174
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/2-year/fixed\">2 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 175
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/3-year/fixed\">3 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 176
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/4-year/fixed\">4 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 177
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/5-year/fixed\">5 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 178
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/6-year/fixed\">6 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 179
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/7-year/fixed\">7 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 180
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/8-year/fixed\">8 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 181
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/9-year/fixed\">9 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 182
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/10-year/fixed\">10 Year Fixed Rate</a></li>
                                                    </li>
                                                
                                          
                                             
                                     </ul>
                                </li>
<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-percent\"></i> &nbsp; Variable Mortgage Rates</a>
                                    <ul class=\"children active\">
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 193
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/3-year/variable\">3 Year Variable Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 194
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/5-year/variable\">5 Year Variable Rate</a></li>

</ul></li>



                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children\">
                                                <li><a href=\"";
        // line 204
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 205
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 206
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 207
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                                <li><a href=\"";
        // line 208
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 209
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 210
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 211
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 212
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 213
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                     </ul>
                                </li>
                                <li> 
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                    <ul class=\"children\">
                                        
                                                ";
        // line 221
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 222
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 223
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 225
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 226
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    <ul class=\"children\">
                                       ";
        // line 233
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 234
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 235
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 237
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 238
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    <ul class=\"children\">
                                      ";
        // line 244
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 245
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 246
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 248
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 249
        echo "                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
              
                                 </aside>
                    <!-- /SIDEBAR -->
                </div>
            </div>
        </section>
        ";
        // line 262
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact For Rate <span id=\"rate-r\"></span> %</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 305
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 306
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 307
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 309
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 311
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 312
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\">Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"modal-footer\">

                    </div>
                </div>
            </div>
        </div>
      
        <script>
                                                    \$(document).on(\"click\", \".rate-btn\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#rate-request\").val(\$(this).attr(\"class\").split(\" \")[1]);
                                                        \$(\"#rate-r\").html(\$(this).attr(\"class\").split(\" \")[1]);
                                                    });
                                                    
                                                     \$(document).ready(function () {
                                                        if(ip2location_country_long() === 'Canada')
                                                        {
                                                        \$(\"#agentLocationName\").val(ip2location_city());
                                                        \$(\"#agentLocation\").find(\"option:contains('\" + ip2location_city() + \"')\").prop(\"selected\", true);
                                                        }
                                                        else
                                                        {
                                                        \$(\"#agentLocationName\").val(\"Brampton\");
                                                        \$(\"#agentLocation\").find(\"option:contains('Brampton')\").prop(\"selected\", true);
                                                        }
                                                    });

                                                    \$('.locations').on('click', function() {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function() {
                                                        \$('.level1 ul').toggle(500);

                                                    });
                                                    \$('.level2Btn').on('click', function() {
                                                        \$('.level2 ul').toggle(500);

                                                    });
                                                    \$('.level3Btn').on('click', function() {
                                                        \$('.level3 ul').toggle(500);

                                                    });

                                                    \$('#agentLocationName').click(function(e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function(e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function() {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }



                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"click\", \".subsc\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 426
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function(response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function(request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });


                                                    \$(document).on(\"change\", \".required\", function() {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function(e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 497
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function() {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function(response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                    window.location.href = '/thank-you';
                                                                },
                                                                error: function(request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:city-rates.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  664 => 312,  658 => 311,  650 => 309,  643 => 307,  588 => 262,  567 => 248,  345 => 151,  1594 => 1360,  1587 => 1356,  1583 => 1355,  1577 => 1352,  1573 => 1351,  1569 => 1350,  1507 => 1291,  1465 => 1252,  1456 => 1246,  1449 => 1242,  1428 => 1224,  1424 => 1223,  1420 => 1222,  1416 => 1221,  1412 => 1220,  1408 => 1219,  1404 => 1218,  1400 => 1217,  1396 => 1216,  1392 => 1215,  1388 => 1214,  860 => 695,  854 => 497,  823 => 665,  817 => 663,  791 => 642,  785 => 641,  773 => 639,  750 => 522,  634 => 305,  595 => 380,  571 => 374,  485 => 305,  297 => 203,  874 => 702,  801 => 513,  692 => 416,  688 => 415,  684 => 414,  679 => 412,  675 => 411,  671 => 410,  612 => 373,  562 => 329,  624 => 376,  545 => 371,  605 => 336,  601 => 381,  575 => 375,  488 => 209,  776 => 467,  703 => 397,  573 => 249,  557 => 276,  401 => 183,  287 => 131,  1156 => 880,  1083 => 810,  963 => 692,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 611,  830 => 605,  824 => 604,  813 => 601,  800 => 593,  794 => 592,  786 => 590,  783 => 589,  779 => 640,  768 => 580,  764 => 579,  760 => 578,  756 => 577,  752 => 576,  748 => 575,  744 => 574,  740 => 573,  732 => 571,  405 => 184,  333 => 146,  307 => 137,  299 => 186,  257 => 104,  807 => 497,  617 => 374,  611 => 311,  596 => 307,  591 => 306,  491 => 210,  431 => 187,  415 => 182,  291 => 173,  284 => 177,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 378,  582 => 396,  578 => 327,  317 => 208,  565 => 320,  468 => 306,  281 => 177,  465 => 236,  361 => 157,  332 => 173,  328 => 147,  320 => 201,  276 => 115,  272 => 124,  245 => 153,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 386,  563 => 230,  559 => 246,  550 => 290,  547 => 231,  542 => 288,  514 => 226,  492 => 252,  484 => 201,  410 => 173,  397 => 246,  388 => 169,  380 => 201,  366 => 236,  331 => 146,  323 => 139,  315 => 141,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 291,  548 => 304,  533 => 300,  528 => 216,  478 => 212,  442 => 226,  417 => 235,  372 => 199,  336 => 164,  924 => 587,  851 => 517,  826 => 532,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 378,  625 => 341,  620 => 323,  616 => 322,  555 => 266,  538 => 237,  534 => 308,  526 => 306,  509 => 245,  482 => 213,  386 => 222,  357 => 158,  353 => 156,  344 => 192,  339 => 227,  335 => 175,  329 => 145,  321 => 151,  610 => 337,  462 => 208,  394 => 224,  370 => 237,  364 => 197,  349 => 200,  340 => 175,  325 => 143,  319 => 194,  304 => 185,  295 => 174,  289 => 176,  280 => 126,  126 => 29,  845 => 613,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 306,  630 => 301,  618 => 298,  614 => 297,  539 => 229,  531 => 227,  516 => 319,  476 => 258,  464 => 282,  421 => 221,  343 => 228,  324 => 145,  316 => 184,  313 => 207,  303 => 131,  292 => 128,  288 => 128,  510 => 280,  506 => 258,  502 => 233,  498 => 232,  425 => 222,  419 => 198,  411 => 181,  389 => 180,  378 => 181,  311 => 139,  708 => 550,  619 => 362,  580 => 376,  558 => 306,  552 => 244,  544 => 238,  537 => 301,  523 => 233,  512 => 246,  483 => 208,  452 => 241,  448 => 206,  436 => 225,  408 => 249,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 664,  816 => 602,  812 => 642,  808 => 641,  804 => 640,  780 => 426,  418 => 177,  100 => 32,  277 => 176,  521 => 282,  513 => 280,  508 => 225,  499 => 212,  495 => 247,  489 => 306,  472 => 257,  396 => 234,  392 => 185,  377 => 219,  356 => 154,  352 => 194,  348 => 193,  192 => 112,  883 => 685,  699 => 504,  449 => 273,  432 => 222,  428 => 267,  414 => 250,  406 => 213,  403 => 179,  399 => 178,  390 => 223,  376 => 200,  373 => 238,  369 => 217,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 419,  700 => 418,  696 => 417,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 342,  570 => 279,  564 => 326,  556 => 245,  549 => 372,  541 => 262,  535 => 296,  527 => 234,  524 => 298,  520 => 248,  505 => 297,  497 => 222,  494 => 308,  479 => 302,  475 => 285,  467 => 283,  458 => 207,  454 => 206,  450 => 205,  446 => 204,  184 => 107,  180 => 106,  172 => 104,  160 => 101,  152 => 33,  937 => 686,  809 => 600,  759 => 493,  753 => 462,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 372,  603 => 275,  599 => 351,  553 => 232,  536 => 228,  530 => 235,  522 => 219,  519 => 304,  515 => 261,  507 => 282,  501 => 256,  493 => 221,  490 => 293,  486 => 251,  477 => 270,  471 => 237,  463 => 242,  460 => 281,  456 => 228,  445 => 272,  441 => 271,  433 => 194,  429 => 193,  424 => 266,  420 => 265,  416 => 264,  412 => 214,  385 => 179,  382 => 193,  118 => 27,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 282,  576 => 319,  572 => 318,  568 => 254,  561 => 277,  546 => 289,  540 => 309,  532 => 284,  529 => 284,  525 => 331,  517 => 281,  511 => 319,  503 => 206,  500 => 223,  496 => 220,  487 => 251,  481 => 286,  473 => 308,  470 => 210,  466 => 209,  455 => 195,  451 => 224,  447 => 247,  443 => 246,  439 => 270,  434 => 239,  426 => 200,  422 => 232,  400 => 247,  395 => 177,  114 => 26,  260 => 162,  256 => 103,  248 => 114,  266 => 124,  262 => 121,  250 => 116,  242 => 136,  234 => 185,  226 => 87,  222 => 86,  218 => 105,  279 => 142,  275 => 171,  271 => 164,  267 => 163,  263 => 123,  259 => 122,  255 => 129,  239 => 150,  81 => 53,  65 => 21,  1085 => 1059,  210 => 121,  198 => 103,  194 => 123,  190 => 57,  186 => 109,  178 => 35,  150 => 35,  146 => 34,  134 => 31,  124 => 77,  104 => 19,  391 => 176,  383 => 174,  375 => 163,  371 => 159,  367 => 161,  363 => 177,  359 => 168,  351 => 171,  347 => 153,  188 => 42,  301 => 204,  293 => 202,  113 => 90,  174 => 34,  170 => 39,  148 => 32,  77 => 52,  231 => 90,  165 => 37,  161 => 36,  153 => 97,  195 => 106,  191 => 42,  34 => 11,  155 => 30,  310 => 197,  306 => 176,  302 => 195,  290 => 180,  286 => 146,  282 => 166,  274 => 153,  270 => 194,  251 => 128,  237 => 93,  233 => 138,  225 => 127,  213 => 87,  205 => 78,  175 => 35,  167 => 33,  137 => 84,  129 => 82,  23 => 3,  223 => 119,  215 => 135,  211 => 119,  207 => 118,  202 => 118,  197 => 111,  185 => 117,  181 => 101,  70 => 29,  358 => 156,  354 => 231,  350 => 210,  346 => 229,  342 => 150,  338 => 149,  334 => 142,  330 => 163,  326 => 201,  318 => 141,  206 => 92,  244 => 112,  236 => 133,  232 => 131,  228 => 84,  216 => 96,  212 => 95,  200 => 126,  110 => 25,  90 => 34,  84 => 28,  53 => 24,  127 => 26,  97 => 62,  76 => 41,  58 => 11,  480 => 234,  474 => 211,  469 => 284,  461 => 302,  457 => 234,  453 => 206,  444 => 192,  440 => 246,  437 => 270,  435 => 269,  430 => 257,  427 => 211,  423 => 194,  413 => 234,  409 => 238,  407 => 180,  402 => 226,  398 => 211,  393 => 245,  387 => 175,  384 => 168,  381 => 240,  379 => 173,  374 => 227,  368 => 198,  365 => 189,  362 => 156,  360 => 232,  355 => 227,  341 => 156,  337 => 155,  322 => 173,  314 => 140,  312 => 136,  309 => 206,  305 => 205,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 116,  268 => 123,  264 => 122,  258 => 97,  252 => 117,  247 => 149,  241 => 94,  229 => 109,  220 => 113,  214 => 122,  177 => 103,  169 => 101,  140 => 30,  132 => 61,  128 => 85,  107 => 28,  61 => 14,  273 => 185,  269 => 110,  254 => 159,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 144,  227 => 129,  224 => 141,  221 => 98,  219 => 88,  217 => 125,  208 => 96,  204 => 83,  179 => 114,  159 => 31,  143 => 90,  135 => 28,  119 => 31,  102 => 19,  71 => 19,  67 => 29,  63 => 37,  59 => 27,  201 => 115,  196 => 113,  183 => 53,  171 => 44,  166 => 32,  163 => 32,  158 => 37,  156 => 34,  151 => 95,  142 => 33,  138 => 32,  136 => 26,  121 => 92,  117 => 73,  105 => 61,  91 => 59,  62 => 36,  49 => 14,  87 => 23,  28 => 8,  94 => 35,  89 => 51,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 10,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 18,  88 => 56,  78 => 31,  46 => 23,  44 => 11,  27 => 7,  79 => 20,  72 => 40,  69 => 40,  47 => 21,  40 => 8,  37 => 11,  22 => 2,  246 => 96,  157 => 98,  145 => 53,  139 => 89,  131 => 27,  123 => 25,  120 => 37,  115 => 20,  111 => 29,  108 => 67,  101 => 18,  98 => 36,  96 => 31,  83 => 27,  74 => 30,  66 => 43,  55 => 26,  52 => 12,  50 => 15,  43 => 23,  41 => 12,  35 => 12,  32 => 12,  29 => 9,  209 => 132,  203 => 94,  199 => 93,  193 => 110,  189 => 109,  187 => 41,  182 => 108,  176 => 105,  173 => 102,  168 => 56,  164 => 105,  162 => 38,  154 => 36,  149 => 69,  147 => 28,  144 => 31,  141 => 85,  133 => 44,  130 => 30,  125 => 93,  122 => 28,  116 => 36,  112 => 65,  109 => 68,  106 => 41,  103 => 59,  99 => 26,  95 => 60,  92 => 57,  86 => 15,  82 => 17,  80 => 20,  73 => 14,  64 => 12,  60 => 15,  57 => 16,  54 => 14,  51 => 11,  48 => 11,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 8,  30 => 10,);
    }
}
