<?php

/* AcmeDemoBundle:Demo:footer.html.twig */
class __TwigTemplate_dd35fa1d613b8481a9bf2f89f0179b96ea25ecdf2758e021c58783cbf8f3ec73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"navbar  navbar-inverse\">
    <div class=\"container\">
        <p style=\"color: #cccccc;margin: 0;padding: 14px 0;display: inline;\">Copyright &copy; ";
        // line 3
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " 
            &nbsp;&nbsp;RateTrade.ca</p>
           
    </div>
             <div class=\"container\">
       
     <a href=\"#\"><img style=\"height:50px;\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/fb.png"), "html", null, true);
        echo "\"></a>
            <a href=\"#\"><img style=\"height:50px;\" src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/linkedin.png"), "html", null, true);
        echo "\"></a>
            <a href=\"#\"><img style=\"height:50px;\" src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/gplus.png"), "html", null, true);
        echo "\"></a>
            <a href=\"#\"><img style=\"height:50px;\" src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/twitter.png"), "html", null, true);
        echo "\"></a>
             </div>
</div>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 3,  223 => 134,  215 => 132,  211 => 131,  207 => 130,  202 => 128,  197 => 126,  185 => 123,  181 => 122,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 32,  84 => 29,  53 => 10,  127 => 28,  97 => 41,  76 => 17,  58 => 17,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 168,  214 => 69,  177 => 121,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 77,  219 => 133,  217 => 75,  208 => 165,  204 => 164,  179 => 69,  159 => 61,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 14,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 79,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 18,  91 => 38,  62 => 24,  49 => 13,  87 => 25,  28 => 5,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 6,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 11,  19 => 1,  93 => 28,  88 => 31,  78 => 28,  46 => 8,  44 => 12,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 11,  37 => 5,  22 => 2,  246 => 90,  157 => 56,  145 => 46,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 43,  111 => 37,  108 => 19,  101 => 43,  98 => 31,  96 => 31,  83 => 25,  74 => 27,  66 => 25,  55 => 15,  52 => 14,  50 => 10,  43 => 11,  41 => 10,  35 => 9,  32 => 9,  29 => 3,  209 => 82,  203 => 78,  199 => 67,  193 => 125,  189 => 124,  187 => 84,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 45,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 10,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 10,  36 => 10,  33 => 4,  30 => 3,);
    }
}
