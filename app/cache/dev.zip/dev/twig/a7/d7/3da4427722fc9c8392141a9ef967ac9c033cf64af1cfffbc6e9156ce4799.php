<?php

/* MainRatetradeBundle:Default:GuideDesc.html.twig */
class __TwigTemplate_a7d73da4427722fc9c8392141a9ef967ac9c033cf64af1cfffbc6e9156ce4799 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
  <head>
    <title>";
        // line 4
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, (isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "html", null, true);
        }
        echo "</title>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=content-width, initial-scale=1\">
    <meta name=\"robots\" content=\"index, follow\">
    <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
    <meta name=\"geo.region\" content=\"CA\" />
    <meta name=\"title\" content=\"";
        // line 10
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, (isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "html", null, true);
        }
        echo "\">
    <meta name=\"description\" content=\"";
        // line 11
        echo (isset($context["mdesc"]) ? $context["mdesc"] : $this->getContext($context, "mdesc"));
        echo "\"> 
    <meta name=\"keyword\" content=\"";
        // line 12
        if (((isset($context["mkeywords"]) ? $context["mkeywords"] : $this->getContext($context, "mkeywords")) != "")) {
            echo (isset($context["mkeywords"]) ? $context["mkeywords"] : $this->getContext($context, "mkeywords"));
        } else {
            echo twig_escape_filter($this->env, (isset($context["mkeywords"]) ? $context["mkeywords"] : $this->getContext($context, "mkeywords")), "html", null, true);
        }
        echo "\">
    <meta property=\"og:type\" content=\"article\" />
    <meta name=\"og:title\" content=\"";
        // line 14
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, (isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "html", null, true);
        }
        echo "\">
    <meta name=\"og:description\" content=\"";
        // line 15
        echo (isset($context["mdesc"]) ? $context["mdesc"] : $this->getContext($context, "mdesc"));
        echo "\">
    <meta property=\"og:site_name\" content=\"Rate Trade\" />
    <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
    <meta name=\"twitter:card\" content=\"summary\" />
    <meta name=\"twitter:description\" content=\"";
        // line 19
        echo (isset($context["mdesc"]) ? $context["mdesc"] : $this->getContext($context, "mdesc"));
        echo "\">
    <meta name=\"twitter:title\" content=\"";
        // line 20
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, (isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "html", null, true);
        }
        echo "\">
    <meta name=\"twitter:site\" content=\"@ratetrade\" />
    <meta name=\"twitter:creator\" content=\"@ratetrade\" />   
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
    

          ";
        // line 41
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
    <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">";
        // line 50
        echo twig_escape_filter($this->env, (isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "html", null, true);
        echo "</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">";
        // line 54
        echo twig_escape_filter($this->env, (isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "html", null, true);
        echo "</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->

        <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
                                ";
        // line 74
        echo (isset($context["guidedesc"]) ? $context["guidedesc"] : $this->getContext($context, "guidedesc"));
        echo "
    ";
        // line 75
        if (((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")) == "Mortgage Renewal Process")) {
            echo "<div class=\"reproc\">
                                <h3>Mortgage Renewals By Province</h3>
                                ";
            // line 77
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["province"]) ? $context["province"] : $this->getContext($context, "province")));
            foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
                // line 78
                echo "                                    <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_renewals", array("city" => $this->getAttribute((isset($context["p"]) ? $context["p"] : $this->getContext($context, "p")), "provinceUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : $this->getContext($context, "p")), "province"), "html", null, true);
                echo "</a>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 79
            echo "</div>
                            ";
        }
        // line 81
        echo "
 ";
        // line 82
        if (((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")) == "Cost to Refinance?")) {
            echo "<div class=\"reproc\">
                                <h3>Mortgage Refinance By Province</h3>
                                ";
            // line 84
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["province"]) ? $context["province"] : $this->getContext($context, "province")));
            foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
                // line 85
                echo "                                    <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_refinance", array("city" => $this->getAttribute((isset($context["p"]) ? $context["p"] : $this->getContext($context, "p")), "provinceUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : $this->getContext($context, "p")), "province"), "html", null, true);
                echo "</a>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 86
            echo "</div>
                            ";
        }
        // line 88
        echo "

                            </div>



                            <div class=\"clear\"></div>
                            <div class=\"mortapb\"><a href=\"#\" class=\"an-button\" data-toggle=\"modal\" data-target=\"#agentModal1\">Apply Now</a>
                                &nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;
                                <a href=\"";
        // line 97
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "\" class=\"an-button\">Best Available Rates</a>
                            </div>
                            <div class=\"clear\"></div>
                        

                           





                        </div>
                    </div>


                   
                    </article>
<!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                               
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
  ";
        // line 126
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "6")) {
            // line 127
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 129
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 131
        echo "                                    
                                        
                                                         
                                                            ";
        // line 134
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 135
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 136
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 137
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 139
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 141
                echo "                                                                    ";
            }
            // line 142
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 143
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                             ";
        // line 149
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "18")) {
            // line 150
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 152
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 154
        echo "                                    
                                        
                                        ";
        // line 156
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 157
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 158
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 159
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 161
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 163
                echo "                                                                    ";
            }
            // line 164
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 165
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    ";
        // line 170
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "1")) {
            // line 171
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 173
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 175
        echo "                                    
                                        
                                       ";
        // line 177
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 178
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 179
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 180
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 182
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 184
                echo "                                                                    ";
            }
            // line 185
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 186
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Mortgage Information</a>
                             ";
        // line 191
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "47")) {
            // line 192
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 194
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 196
        echo "                                    
                                        
                                       ";
        // line 198
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 199
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "47")) {
                // line 200
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 201
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 203
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 205
                echo "                                                                    ";
            }
            // line 206
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 207
        echo "                                    </ul>

                                </li>
  ";
        // line 210
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "39")) {
            echo " <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Auto Insurance</a>
                                    <ul class=\"children active\">
                                           ";
            // line 214
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
            foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                // line 215
                echo "                                                                ";
                if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "39")) {
                    // line 216
                    echo "                                                                    <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                    ";
                }
                // line 218
                echo "                                                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 219
            echo "                                    </ul>
                                </li>
";
        }
        // line 222
        echo "
";
        // line 223
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "44")) {
            // line 224
            echo "
<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Insurance</a>
                                    <ul class=\"children active\">
                                           ";
            // line 229
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
            foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                // line 230
                echo "                                                                ";
                if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "44")) {
                    // line 231
                    echo "                                                                    <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                    ";
                }
                // line 233
                echo "                                                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 234
            echo "                                    </ul>
                                </li>
";
        }
        // line 237
        echo "

                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
                                                     </aside>
                    <!-- /SIDEBAR -->
</div></div></section>
                     <!-- FOOTER -->
      ";
        // line 247
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
<!-- /WRAPPER -->
   <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact Us</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 291
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 292
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 293
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 295
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 297
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 298
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\" selected>Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    </div></div></div>
 <script>

                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"click\", \".subsc\", function (e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 346
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function (response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function (request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });

                                                    \$('#locationName').click(function (e) {
                                                        \$('.loclist').show(100);
                                                    });
                                                    \$('.loclist').blur(function (e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function getSelected() {

                                                        document.getElementById('locationName').value = document.getElementById('locationList').value;

                                                        \$('#locationList').hide(100);
                                                    }

                                                    \$('#agentLocationName').click(function (e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function (e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function () {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }


                                                    \$('.locations').on('click', function () {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function (e) {
                                                        e.preventDefault();
                                                        \$('.level1 ul').toggle(500);
                                                    });
                                                    \$('.level2Btn').on('click', function (e) {
                                                        e.preventDefault();
                                                        \$('.level2 ul').toggle(500);
                                                    });
                                                    \$('.level3Btn').on('click', function (e) {
                                                        e.preventDefault();
                                                        \$('.level3 ul').toggle(500);
                                                    });

                                                    \$(document).on(\"change\", \".required\", function () {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function (e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 471
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function () {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function (response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                    window.location.href = '/thank-you';
                                                                },
                                                                error: function (request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:GuideDesc.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 231,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 210,  492 => 203,  484 => 201,  410 => 173,  397 => 165,  388 => 163,  380 => 161,  366 => 157,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 199,  442 => 237,  417 => 227,  372 => 159,  336 => 197,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 255,  509 => 207,  482 => 240,  386 => 195,  357 => 182,  353 => 180,  344 => 199,  339 => 176,  335 => 175,  329 => 174,  321 => 171,  610 => 410,  462 => 192,  394 => 239,  370 => 186,  364 => 204,  349 => 212,  340 => 143,  325 => 172,  319 => 194,  304 => 185,  295 => 179,  289 => 176,  280 => 170,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 228,  531 => 226,  516 => 319,  476 => 204,  464 => 230,  421 => 183,  343 => 152,  324 => 135,  316 => 129,  313 => 128,  303 => 123,  292 => 127,  288 => 114,  510 => 235,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 196,  411 => 194,  389 => 184,  378 => 181,  311 => 147,  708 => 448,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 252,  483 => 226,  452 => 227,  448 => 226,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 41,  277 => 141,  521 => 214,  513 => 253,  508 => 216,  499 => 248,  495 => 247,  489 => 229,  472 => 203,  396 => 202,  392 => 201,  377 => 188,  356 => 202,  352 => 201,  348 => 149,  192 => 74,  883 => 685,  699 => 504,  449 => 239,  432 => 222,  428 => 180,  414 => 175,  406 => 171,  403 => 244,  399 => 203,  390 => 216,  376 => 233,  373 => 191,  369 => 158,  265 => 161,  261 => 104,  253 => 161,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 263,  535 => 227,  527 => 313,  524 => 298,  520 => 254,  505 => 250,  497 => 301,  494 => 231,  479 => 239,  475 => 238,  467 => 288,  458 => 196,  454 => 208,  450 => 194,  446 => 238,  184 => 38,  180 => 106,  172 => 104,  160 => 91,  152 => 30,  937 => 621,  809 => 496,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 218,  530 => 292,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 295,  477 => 270,  471 => 289,  463 => 242,  460 => 191,  456 => 228,  445 => 257,  441 => 268,  433 => 203,  429 => 185,  424 => 254,  420 => 228,  416 => 252,  412 => 251,  385 => 233,  382 => 277,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 297,  529 => 295,  525 => 215,  517 => 254,  511 => 304,  503 => 206,  500 => 205,  496 => 243,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 276,  451 => 224,  447 => 185,  443 => 192,  439 => 260,  434 => 231,  426 => 214,  422 => 178,  400 => 242,  395 => 185,  114 => 37,  260 => 189,  256 => 103,  248 => 186,  266 => 193,  262 => 147,  250 => 189,  242 => 136,  234 => 185,  226 => 183,  222 => 182,  218 => 105,  279 => 111,  275 => 194,  271 => 193,  267 => 137,  263 => 191,  259 => 158,  255 => 155,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 103,  194 => 133,  190 => 41,  186 => 131,  178 => 35,  150 => 41,  146 => 79,  134 => 24,  124 => 72,  104 => 67,  391 => 164,  383 => 214,  375 => 313,  371 => 159,  367 => 158,  363 => 157,  359 => 156,  351 => 179,  347 => 153,  188 => 36,  301 => 173,  293 => 151,  113 => 90,  174 => 34,  170 => 33,  148 => 29,  77 => 30,  231 => 130,  165 => 106,  161 => 105,  153 => 92,  195 => 96,  191 => 95,  34 => 8,  155 => 27,  310 => 188,  306 => 145,  302 => 237,  290 => 126,  286 => 197,  282 => 143,  274 => 153,  270 => 194,  251 => 139,  237 => 114,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 94,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 82,  215 => 151,  211 => 124,  207 => 58,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 29,  358 => 154,  354 => 152,  350 => 150,  346 => 220,  342 => 166,  338 => 165,  334 => 142,  330 => 163,  326 => 165,  318 => 277,  206 => 110,  244 => 174,  236 => 133,  232 => 85,  228 => 84,  216 => 79,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 25,  53 => 11,  127 => 33,  97 => 62,  76 => 19,  58 => 26,  480 => 162,  474 => 198,  469 => 284,  461 => 155,  457 => 241,  453 => 186,  444 => 184,  440 => 224,  437 => 204,  435 => 186,  430 => 257,  427 => 260,  423 => 142,  413 => 226,  409 => 132,  407 => 205,  402 => 130,  398 => 218,  393 => 197,  387 => 215,  384 => 235,  381 => 182,  379 => 230,  374 => 180,  368 => 205,  365 => 189,  362 => 156,  360 => 203,  355 => 215,  341 => 105,  337 => 103,  322 => 214,  314 => 177,  312 => 136,  309 => 135,  305 => 134,  298 => 172,  294 => 171,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 97,  252 => 187,  247 => 88,  241 => 159,  229 => 107,  220 => 81,  214 => 104,  177 => 83,  169 => 54,  140 => 27,  132 => 25,  128 => 85,  107 => 28,  61 => 14,  273 => 140,  269 => 94,  254 => 102,  243 => 86,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 152,  217 => 122,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 37,  135 => 35,  119 => 31,  102 => 34,  71 => 12,  67 => 29,  63 => 22,  59 => 27,  201 => 77,  196 => 75,  183 => 100,  171 => 31,  166 => 32,  163 => 29,  158 => 30,  156 => 100,  151 => 26,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 67,  91 => 24,  62 => 27,  49 => 10,  87 => 16,  28 => 8,  94 => 35,  89 => 20,  85 => 14,  75 => 31,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 56,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 32,  72 => 13,  69 => 15,  47 => 24,  40 => 10,  37 => 5,  22 => 2,  246 => 137,  157 => 98,  145 => 92,  139 => 36,  131 => 34,  123 => 32,  120 => 71,  115 => 30,  111 => 29,  108 => 68,  101 => 18,  98 => 36,  96 => 37,  83 => 33,  74 => 30,  66 => 28,  55 => 26,  52 => 12,  50 => 24,  43 => 23,  41 => 10,  35 => 8,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 44,  189 => 103,  187 => 101,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 92,  162 => 50,  154 => 29,  149 => 99,  147 => 25,  144 => 28,  141 => 91,  133 => 95,  130 => 23,  125 => 93,  122 => 39,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 27,  99 => 26,  95 => 25,  92 => 57,  86 => 33,  82 => 32,  80 => 20,  73 => 29,  64 => 20,  60 => 19,  57 => 93,  54 => 25,  51 => 25,  48 => 11,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 4,  30 => 10,);
    }
}
