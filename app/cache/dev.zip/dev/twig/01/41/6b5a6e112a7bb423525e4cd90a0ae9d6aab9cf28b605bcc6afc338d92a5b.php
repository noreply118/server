<?php

/* MainRatetradeBundle:Default:broker-data.html_1.twig */
class __TwigTemplate_01416b5a6e112a7bb423525e4cd90a0ae9d6aab9cf28b605bcc6afc338d92a5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <meta name=\"geo.region\" content=\"CA\" />
        <title>Broker Details</title>
        <link rel=\"shortcut icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/styles.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,400italic,600,600italic,700,300italic,300,900|Roboto+Condensed:400,700,700italic,400italic,300italic,300' rel='stylesheet' type='text/css'>
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-77426284-3', 'auto');
            ga('send', 'pageview');

        </script>
    </head>
    <body>
        <header>
            <div class=\"top-area\" style=\"text-align: right;\">
                <a href=\"#\">
                    ";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "email"), "html", null, true);
        echo "
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("broker_logout");
        echo "\">
                    Logout
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
            </div>
            <nav class=\"navbar navbar-default\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <div class=\"logo mobi-menu\">
                            <a href=\"";
        // line 56
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                <img src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                            </a>
                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <!-- Desktop / tab -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <div class=\"col-xs-12 col-sm-12 col-md-4 col-lg-4\">
                            <div class=\"logo\">
                                <a href=\"";
        // line 67
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                    <img src=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                                </a>
                            </div>
                        </div>
                        <div class=\"col-xs-12 col-sm-12 col-md-8 col-lg-8 text-center\">
                            <ul class=\"nav navbar-nav navbar-right\">
                                <li class=\"dropdown\">
                                    <a href=\"";
        // line 75
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\" class=\"visible-lg visible-md hidden\">
                                        <span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Home 
                                        <i class=\"fa fa-caret-down hidden\"></i>
                                    </a>
                                    <a href=\"";
        // line 79
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\" class=\" visible-xs visible-sm hidden\" id=\"mob-menu\">
                                        <span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Home 
                                        <i class=\"fa fa-caret-down\"></i>
                                    </a>
                                </li>
                                <li class=\"dropdown\">
                                    <a href=\"javascript:\" class=\"visible-lg visible-md hidden\"><span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Mortgages <i class=\"fa fa-caret-down hidden\"></i></a>
                                    <a href=\"javascript:\" class=\" visible-xs visible-sm hidden\" id=\"mob-menu\"><span class=\"fa fa-home\" style=\"font-size:24px; \"></span> Mortgages <i class=\"fa fa-caret-down\"></i></a>

                                    <ul class=\"sub-menu-div\">
                                        <li><a href=\"#\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-percent\"></i> Rates <i class=\"fa fa-chevron-circle-right f-r\"></i></a> <a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-rates\"><i class=\"fa fa-percent\" ></i> Rates <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob\">
                                                <li><a href=\"";
        // line 91
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "\">Fixed Mortgage Rates</a></li>
                                                <li><a href=\"";
        // line 92
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "variable"));
        echo "\">Variable Mortgage Rates</a></li>

                                            </ul>

                                        </li>
                                        <li><a href=\"#\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-calculator\"></i> Calculators <i class=\"fa fa-chevron-circle-right f-r\"></i></a>
                                            <a href=\"#\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-calc\"><i class=\"fa fa-calculator\"></i> Calculator <i class=\"fa fa-chevron-circle-down f-r\"></i></a>
                                            <ul class=\"mob2\">
                                                <li><a href=\"";
        // line 100
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 101
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 102
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 103
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 104
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 105
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 106
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                            </ul>

                                        </li>
                                         <li><a href=\"";
        // line 110
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-book\"></i> Home Buying Process </a>
                                            <a href=\"";
        // line 111
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-mortgage\"><i class=\"fa fa-book\"></i> Home Buying Process </a>
                                        </li>
                                        <li><a href=\"";
        // line 113
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "renewing-guide"));
        echo "\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-book\"></i> Renewing Your Mortgage </a>
                                            <a href=\"";
        // line 114
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "renewing-guide"));
        echo "\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-mortgage\"><i class=\"fa fa-book\"></i> Renewing Your Mortgage </a>
                                        </li>
                                        <li><a href=\"";
        // line 116
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "mortgage-refinancing-guide"));
        echo "\" class=\" visible-lg visible-md hidden\"><i class=\"fa fa-book\"></i> Mortgage Refinancing Guide </a>
                                            <a href=\"";
        // line 117
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "mortgage-refinancing-guide"));
        echo "\" class=\" visible-xs visible-sm hidden\" id=\"sub-mob-mortgage\"><i class=\"fa fa-book\"></i> Mortgage Refinancing Guide </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"right-end active\">
                                    <a href=\"";
        // line 122
        echo $this->env->getExtension('routing')->getPath("broker_list");
        echo "\">
                                        <span class=\"fa fa-users\" style=\"font-size:24px; \">                                            
                                        </span> Brokers </a>
                                </li>
                                <li class=\"right-end\"><a href=\"";
        // line 126
        echo $this->env->getExtension('routing')->getPath("contact_us");
        echo "\"> <span class=\"fa fa-paper-plane\" style=\"font-size:24px; \"></span> Contact</a></li>

                            </ul>

                        </div>
                    </div><!-- /.navbar-collapse -->

                    <!-- Mobile -->


                </div><!-- /.container-fluid -->
            </nav>


        </header>
        <section>
            <div class=\"middle-content-contact\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-xs-12 col-sm-7 col-md-7\">
                            <div class=\"col-xs-12\" style=\"border: 1px solid #f1f1f1;background: rgba(255,255,255,0.87);padding: 30px;\">
                                <h1 style=\"color: rgba(121,134,209,1.00); margin-left: 10px;\">Your Rates</h1>
                                <br/>
                                <table class=\"table table-bordered table-striped\">
                                    <tr>
                                        <th> Term </th>
                                        <th> Fixed </th>
                                        <th> Variable </th>
                                    </tr>
                                    <tr>
                                        <td> 1 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 158
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateOne"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 161
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateOne"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 2 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 167
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateTwo"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 170
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateTwo"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 3 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateThree"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 179
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateThree"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 4 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 185
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateFour"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 188
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateFour"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 5 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateFive"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateFive"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 6 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateSix"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 206
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateSix"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 7 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 212
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateSeven"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateSeven"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 8 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 221
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateEight"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateEight"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 9 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 230
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateNine"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateNine"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td> 10 Year </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratef\" value=\"";
        // line 239
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fixedRateTen"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                        <td> 
                                            <input type=\"text\" class=\"form-control ratev\" value=\"";
        // line 242
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "variableRateTen"), "html", null, true);
        echo "\" style=\"width: 50%;\"/>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class=\"col-xs-12 col-sm-5\">
                            <div class=\"col-xs-12\">
                                <h1 style=\"color: rgba(121,134,209,1.00); margin-left: 10px;\">Broker Details</h1>
                            </div>
                            <form class=\"form-class\">
                                <input type=\"hidden\" id=\"broker-id\" value=\"";
        // line 253
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "id"), "html", null, true);
        echo "\" />
                                <div class=\"form-group\">
                                    <label for=\"fname\">First Name: </label>
                                    <input type=\"text\" class=\"form-control required\" name=\"fistName\" id=\"fname\" value=\"";
        // line 256
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fname"), "html", null, true);
        echo "\" placeholder=\"First Name\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"lname\">Last Name: </label>
                                    <input type=\"text\" class=\"form-control required\" name=\"lastName\" value=\"";
        // line 260
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "lname"), "html", null, true);
        echo "\" id=\"lname\" placeholder=\"Last Name\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"email\">Email address:</label>
                                    <input type=\"email\" class=\"form-control required\" id=\"email\" value=\"";
        // line 264
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "email"), "html", null, true);
        echo "\" placeholder=\"Email Address\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"phone\">Phone Number:</label>
                                    <input type=\"tel\" class=\"form-control required\" id=\"phone\" value=\"";
        // line 268
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "phone"), "html", null, true);
        echo "\" placeholder=\"Phone Number\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"city\">City:</label>
                                    <input type=\"text\" class=\"form-control required\" id=\"city\" value=\"";
        // line 272
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "city"), "html", null, true);
        echo "\" placeholder=\"City\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"brokerage_name\">Brokerage Name:</label>
                                    <input type=\"text\" class=\"form-control required\" id=\"brokerage_name\" value=\"";
        // line 276
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "brokerageName"), "html", null, true);
        echo "\" placeholder=\"Brokerage Name\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"weburl\">Website Url:</label>
                                    <input type=\"text\" class=\"form-control required\" id=\"weburl\" value=\"";
        // line 280
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "websiteUrl"), "html", null, true);
        echo "\" placeholder=\"Website URL\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"message\">About Broker:</label>
                                    <textarea name=\"message\" id=\"message\" placeholder=\"Enter Your Message\" class=\"form-control required\">";
        // line 284
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "about"), "html", null, true);
        echo "</textarea>
                                </div>
                                <button type=\"button\" class=\"btn btn-default\" id=\"submit\">Update</button>
                            </form>
                        </div>
                    </div>  
                </div>
            </div>
        </section>
        ";
        // line 293
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 295
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/bootstrap.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 296
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/menu-js.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script>
            function validateEmail(email) {
                var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                return re.test(email);
            }

            \$(document).on(\"click\", \".subsc\", function(e) {
                e.preventDefault();
                \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                if (\$(\"#exampleInputEmail2\") == '')
                {
                    \$(\"#exampleInputEmail2\").focus();
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                {
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                    \$(\"#exampleInputEmail2\").focus();
                }
                else {
                    \$.ajax({
                        url: '";
        // line 319
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                        type: \"post\",
                        async: true,
                        data: {'email': \$(\"#exampleInputName2\").val(),
                            'name': \"testname\"},
                        success: function(response) {
                            \$(\"#exampleInputEmail2\").val('');
                            alert(response);
                        },
                        error: function(request, error) {
                            // alert('No data found');
                        }
                    });
                }
            });


            \$(document).on(\"change\", \".required\", function() {
                \$(this).css('border', '1px solid green');

                if (\$(this).val() == '')
                {
                    \$(this).focus();
                    \$(this).css('border', '1px solid red');
                }

                var id = \$(this).attr('id');
                if (id == 'email' && !validateEmail(\$(\"#email\").val()))
                {
                    \$(\"#email\").focus();
                    \$(\"#email\").css('border', '1px solid red');
                }
            });

            \$(document).on(\"click\", \"#submit\", function(e) {

                var fixed = [];
                var variable = [];

                \$(\".ratef\").each(function() {
                    fixed.push(\$(this).val());
                });

                \$(\".ratev\").each(function() {
                    variable.push(\$(this).val());
                });

                if (\$(\"#fname\").val() == '')
                {
                    \$(\"#fname\").focus();
                    \$(\"#fname\").css('border', '1px solid red');
                }
                else if (\$(\"#lname\").val() == '')
                {
                    \$(\"#lname\").focus();
                    \$(\"#lname\").css('border', '1px solid red');
                }
                else if (\$(\"#email\").val() == '')
                {
                    \$(\"#email\").focus();
                    \$(\"#email\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#email\").val()))
                {
                    \$(\"#email\").css('border', '1px solid red');
                    \$(\"#email\").focus();
                }
                else if (\$(\"#phone\").val() == '')
                {
                    \$(\"#phone\").focus();
                    \$(\"#phone\").css('border', '1px solid red');
                }
                else {
                    var currentRequest = null;
                    \$(\"#submit\").text(\"Please Wait..\");
                    var formData = {
                        id: \$(\"#broker-id\").val(),
                        fname: \$(\"#fname\").val(),
                        lname: \$(\"#lname\").val(),
                        email: \$(\"#email\").val(),
                        phone: \$(\"#phone\").val(),
                        city: \$(\"#city\").val(),
                        brokerage_name: \$(\"#brokerage_name\").val(),
                        weburl: \$(\"#weburl\").val(),
                        variable: variable.join(\",\"),
                        fixed: fixed.join(\",\"),
                        message: \$(\"#message\").val()
                    };
                    currentRequest = \$.ajax({
                        type: \"post\",
                        async: true,
                        url: \"";
        // line 410
        echo $this->env->getExtension('routing')->getPath("broker_login_update");
        echo "\",
                        data: formData,
                        beforeSend: function() {
                            if (currentRequest != null) {
                                currentRequest.abort();
                            }
                        },
                        success: function(response) {
                            \$(\"#submit\").text(\"Submit\");
                            \$(\"#success\").text(\"Data Captured Successfully\");
                            \$(\".required\").removeAttr('style');
                        },
                        error: function(request, error) {
                            \$(\"#success\").text(\"Failed! Try Again\");
                            \$(\"#success\").css('color', 'red');
                            \$(\"#submit\").text(\"Submit\");
                        }
                    });
                }
            });
        </script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:broker-data.html_1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  610 => 410,  462 => 280,  394 => 239,  370 => 224,  364 => 221,  349 => 212,  340 => 206,  325 => 197,  319 => 194,  304 => 185,  295 => 179,  289 => 176,  280 => 170,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 304,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 228,  531 => 226,  516 => 319,  476 => 204,  464 => 197,  421 => 183,  343 => 152,  324 => 135,  316 => 129,  313 => 128,  303 => 123,  292 => 115,  288 => 114,  510 => 235,  506 => 234,  502 => 233,  498 => 232,  425 => 197,  419 => 196,  411 => 194,  389 => 184,  378 => 181,  311 => 147,  708 => 448,  619 => 362,  580 => 326,  558 => 306,  552 => 305,  544 => 303,  537 => 301,  523 => 294,  512 => 291,  483 => 226,  452 => 267,  448 => 272,  436 => 257,  408 => 193,  404 => 173,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 658,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 182,  100 => 41,  277 => 125,  521 => 255,  513 => 253,  508 => 216,  499 => 248,  495 => 247,  489 => 229,  472 => 203,  396 => 202,  392 => 201,  377 => 192,  356 => 186,  352 => 185,  348 => 184,  192 => 118,  883 => 685,  699 => 504,  449 => 259,  432 => 256,  428 => 255,  414 => 253,  406 => 245,  403 => 244,  399 => 203,  390 => 170,  376 => 233,  373 => 191,  369 => 190,  265 => 161,  261 => 104,  253 => 161,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 428,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 385,  635 => 384,  631 => 383,  570 => 327,  564 => 326,  556 => 324,  549 => 322,  541 => 302,  535 => 227,  527 => 313,  524 => 312,  520 => 311,  505 => 215,  497 => 301,  494 => 231,  479 => 205,  475 => 224,  467 => 288,  458 => 196,  454 => 208,  450 => 194,  446 => 282,  184 => 38,  180 => 106,  172 => 104,  160 => 101,  152 => 30,  937 => 621,  809 => 496,  759 => 448,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 395,  670 => 394,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 293,  530 => 292,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 296,  486 => 295,  477 => 270,  471 => 289,  463 => 270,  460 => 266,  456 => 265,  445 => 257,  441 => 268,  433 => 203,  429 => 185,  424 => 254,  420 => 256,  416 => 252,  412 => 251,  385 => 233,  382 => 277,  118 => 50,  597 => 325,  593 => 324,  589 => 323,  585 => 340,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 299,  532 => 297,  529 => 295,  525 => 256,  517 => 254,  511 => 304,  503 => 249,  500 => 284,  496 => 284,  487 => 207,  481 => 293,  473 => 274,  470 => 273,  466 => 228,  455 => 276,  451 => 224,  447 => 193,  443 => 192,  439 => 260,  434 => 264,  426 => 214,  422 => 264,  400 => 242,  395 => 185,  114 => 19,  260 => 189,  256 => 103,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 135,  279 => 111,  275 => 194,  271 => 193,  267 => 107,  263 => 191,  259 => 158,  255 => 155,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 41,  186 => 131,  178 => 35,  150 => 28,  146 => 27,  134 => 24,  124 => 72,  104 => 67,  391 => 317,  383 => 168,  375 => 313,  371 => 159,  367 => 158,  363 => 157,  359 => 156,  351 => 154,  347 => 153,  188 => 36,  301 => 305,  293 => 299,  113 => 90,  174 => 34,  170 => 33,  148 => 29,  77 => 30,  231 => 183,  165 => 106,  161 => 105,  153 => 92,  195 => 113,  191 => 111,  34 => 8,  155 => 27,  310 => 188,  306 => 145,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 167,  270 => 194,  251 => 188,  237 => 140,  233 => 138,  225 => 135,  213 => 152,  205 => 116,  175 => 32,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 137,  215 => 151,  211 => 124,  207 => 58,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 38,  358 => 223,  354 => 222,  350 => 221,  346 => 220,  342 => 166,  338 => 165,  334 => 203,  330 => 163,  326 => 165,  318 => 277,  206 => 126,  244 => 174,  236 => 172,  232 => 209,  228 => 170,  216 => 167,  212 => 166,  200 => 114,  110 => 63,  90 => 52,  84 => 25,  53 => 11,  127 => 20,  97 => 62,  76 => 23,  58 => 11,  480 => 162,  474 => 161,  469 => 284,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 205,  437 => 204,  435 => 186,  430 => 257,  427 => 260,  423 => 142,  413 => 206,  409 => 132,  407 => 205,  402 => 130,  398 => 172,  393 => 126,  387 => 169,  384 => 235,  381 => 182,  379 => 230,  374 => 180,  368 => 112,  365 => 189,  362 => 288,  360 => 187,  355 => 215,  341 => 105,  337 => 103,  322 => 214,  314 => 240,  312 => 98,  309 => 207,  305 => 306,  298 => 118,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 27,  132 => 25,  128 => 85,  107 => 60,  61 => 12,  273 => 109,  269 => 94,  254 => 102,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 138,  224 => 126,  221 => 154,  219 => 152,  217 => 122,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 24,  135 => 77,  119 => 75,  102 => 37,  71 => 12,  67 => 29,  63 => 37,  59 => 27,  201 => 115,  196 => 113,  183 => 34,  171 => 31,  166 => 32,  163 => 29,  158 => 30,  156 => 100,  151 => 26,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 67,  91 => 50,  62 => 24,  49 => 10,  87 => 16,  28 => 3,  94 => 41,  89 => 20,  85 => 14,  75 => 31,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 45,  88 => 56,  78 => 28,  46 => 8,  44 => 15,  27 => 7,  79 => 32,  72 => 13,  69 => 40,  47 => 24,  40 => 8,  37 => 5,  22 => 2,  246 => 188,  157 => 98,  145 => 92,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 18,  98 => 15,  96 => 37,  83 => 33,  74 => 15,  66 => 25,  55 => 26,  52 => 17,  50 => 21,  43 => 23,  41 => 10,  35 => 12,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 44,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 102,  162 => 31,  154 => 29,  149 => 99,  147 => 25,  144 => 28,  141 => 91,  133 => 95,  130 => 23,  125 => 93,  122 => 48,  116 => 21,  112 => 69,  109 => 68,  106 => 45,  103 => 20,  99 => 31,  95 => 28,  92 => 57,  86 => 51,  82 => 50,  80 => 24,  73 => 29,  64 => 20,  60 => 19,  57 => 93,  54 => 92,  51 => 25,  48 => 16,  45 => 10,  42 => 22,  39 => 10,  36 => 13,  33 => 4,  30 => 10,);
    }
}
