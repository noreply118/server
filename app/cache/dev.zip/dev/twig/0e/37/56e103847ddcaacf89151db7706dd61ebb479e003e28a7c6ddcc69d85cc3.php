<?php

/* form_div_layout.html.twig */
class __TwigTemplate_0e3756e103847ddcaacf89151db7706dd61ebb479e003e28a7c6ddcc69d85cc3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'form_widget' => array($this, 'block_form_widget'),
            'form_widget_simple' => array($this, 'block_form_widget_simple'),
            'form_widget_compound' => array($this, 'block_form_widget_compound'),
            'collection_widget' => array($this, 'block_collection_widget'),
            'textarea_widget' => array($this, 'block_textarea_widget'),
            'choice_widget' => array($this, 'block_choice_widget'),
            'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
            'choice_widget_collapsed' => array($this, 'block_choice_widget_collapsed'),
            'choice_widget_options' => array($this, 'block_choice_widget_options'),
            'checkbox_widget' => array($this, 'block_checkbox_widget'),
            'radio_widget' => array($this, 'block_radio_widget'),
            'datetime_widget' => array($this, 'block_datetime_widget'),
            'date_widget' => array($this, 'block_date_widget'),
            'time_widget' => array($this, 'block_time_widget'),
            'number_widget' => array($this, 'block_number_widget'),
            'integer_widget' => array($this, 'block_integer_widget'),
            'money_widget' => array($this, 'block_money_widget'),
            'url_widget' => array($this, 'block_url_widget'),
            'search_widget' => array($this, 'block_search_widget'),
            'percent_widget' => array($this, 'block_percent_widget'),
            'password_widget' => array($this, 'block_password_widget'),
            'hidden_widget' => array($this, 'block_hidden_widget'),
            'email_widget' => array($this, 'block_email_widget'),
            'button_widget' => array($this, 'block_button_widget'),
            'submit_widget' => array($this, 'block_submit_widget'),
            'reset_widget' => array($this, 'block_reset_widget'),
            'form_label' => array($this, 'block_form_label'),
            'button_label' => array($this, 'block_button_label'),
            'repeated_row' => array($this, 'block_repeated_row'),
            'form_row' => array($this, 'block_form_row'),
            'button_row' => array($this, 'block_button_row'),
            'hidden_row' => array($this, 'block_hidden_row'),
            'form' => array($this, 'block_form'),
            'form_start' => array($this, 'block_form_start'),
            'form_end' => array($this, 'block_form_end'),
            'form_enctype' => array($this, 'block_form_enctype'),
            'form_errors' => array($this, 'block_form_errors'),
            'form_rest' => array($this, 'block_form_rest'),
            'form_rows' => array($this, 'block_form_rows'),
            'widget_attributes' => array($this, 'block_widget_attributes'),
            'widget_container_attributes' => array($this, 'block_widget_container_attributes'),
            'button_attributes' => array($this, 'block_button_attributes'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
";
        // line 3
        $this->displayBlock('form_widget', $context, $blocks);
        // line 12
        echo "
";
        // line 13
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 19
        echo "
";
        // line 20
        $this->displayBlock('form_widget_compound', $context, $blocks);
        // line 31
        echo "
";
        // line 32
        $this->displayBlock('collection_widget', $context, $blocks);
        // line 40
        echo "
";
        // line 41
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 46
        echo "
";
        // line 47
        $this->displayBlock('choice_widget', $context, $blocks);
        // line 56
        echo "
";
        // line 57
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 67
        echo "
";
        // line 68
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 89
        echo "
";
        // line 90
        $this->displayBlock('choice_widget_options', $context, $blocks);
        // line 104
        echo "
";
        // line 105
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 110
        echo "
";
        // line 111
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 116
        echo "
";
        // line 117
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 131
        echo "
";
        // line 132
        $this->displayBlock('date_widget', $context, $blocks);
        // line 147
        echo "
";
        // line 148
        $this->displayBlock('time_widget', $context, $blocks);
        // line 160
        echo "
";
        // line 161
        $this->displayBlock('number_widget', $context, $blocks);
        // line 168
        echo "
";
        // line 169
        $this->displayBlock('integer_widget', $context, $blocks);
        // line 175
        echo "
";
        // line 176
        $this->displayBlock('money_widget', $context, $blocks);
        // line 181
        echo "
";
        // line 182
        $this->displayBlock('url_widget', $context, $blocks);
        // line 188
        echo "
";
        // line 189
        $this->displayBlock('search_widget', $context, $blocks);
        // line 195
        echo "
";
        // line 196
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 202
        echo "
";
        // line 203
        $this->displayBlock('password_widget', $context, $blocks);
        // line 209
        echo "
";
        // line 210
        $this->displayBlock('hidden_widget', $context, $blocks);
        // line 216
        echo "
";
        // line 217
        $this->displayBlock('email_widget', $context, $blocks);
        // line 223
        echo "
";
        // line 224
        $this->displayBlock('button_widget', $context, $blocks);
        // line 232
        echo "
";
        // line 233
        $this->displayBlock('submit_widget', $context, $blocks);
        // line 239
        echo "
";
        // line 240
        $this->displayBlock('reset_widget', $context, $blocks);
        // line 246
        echo "
";
        // line 248
        echo "
";
        // line 249
        $this->displayBlock('form_label', $context, $blocks);
        // line 265
        echo "
";
        // line 266
        $this->displayBlock('button_label', $context, $blocks);
        // line 267
        echo "
";
        // line 269
        echo "
";
        // line 270
        $this->displayBlock('repeated_row', $context, $blocks);
        // line 279
        echo "
";
        // line 280
        $this->displayBlock('form_row', $context, $blocks);
        // line 289
        echo "
";
        // line 290
        $this->displayBlock('button_row', $context, $blocks);
        // line 297
        echo "
";
        // line 298
        $this->displayBlock('hidden_row', $context, $blocks);
        // line 301
        echo "
";
        // line 303
        echo "
";
        // line 304
        $this->displayBlock('form', $context, $blocks);
        // line 311
        echo "
";
        // line 312
        $this->displayBlock('form_start', $context, $blocks);
        // line 326
        echo "
";
        // line 327
        $this->displayBlock('form_end', $context, $blocks);
        // line 335
        echo "
";
        // line 336
        $this->displayBlock('form_enctype', $context, $blocks);
        // line 341
        echo "
";
        // line 342
        $this->displayBlock('form_errors', $context, $blocks);
        // line 353
        echo "
";
        // line 354
        $this->displayBlock('form_rest', $context, $blocks);
        // line 363
        echo "
";
        // line 365
        echo "
";
        // line 366
        $this->displayBlock('form_rows', $context, $blocks);
        // line 373
        echo "
";
        // line 374
        $this->displayBlock('widget_attributes', $context, $blocks);
        // line 392
        echo "
";
        // line 393
        $this->displayBlock('widget_container_attributes', $context, $blocks);
        // line 408
        echo "
";
        // line 409
        $this->displayBlock('button_attributes', $context, $blocks);
    }

    // line 3
    public function block_form_widget($context, array $blocks = array())
    {
        // line 4
        ob_start();
        // line 5
        echo "    ";
        if ((isset($context["compound"]) ? $context["compound"] : $this->getContext($context, "compound"))) {
            // line 6
            echo "        ";
            $this->displayBlock("form_widget_compound", $context, $blocks);
            echo "
    ";
        } else {
            // line 8
            echo "        ";
            $this->displayBlock("form_widget_simple", $context, $blocks);
            echo "
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 13
    public function block_form_widget_simple($context, array $blocks = array())
    {
        // line 14
        ob_start();
        // line 15
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "text")) : ("text"));
        // line 16
        echo "    <input type=\"";
        echo twig_escape_filter($this->env, (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "html", null, true);
        echo "\" ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        echo " ";
        if ((!twig_test_empty((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value"))))) {
            echo "value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
            echo "\" ";
        }
        echo "/>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 20
    public function block_form_widget_compound($context, array $blocks = array())
    {
        // line 21
        ob_start();
        // line 22
        echo "    <div ";
        $this->displayBlock("widget_container_attributes", $context, $blocks);
        echo ">
        ";
        // line 23
        if (twig_test_empty($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent"))) {
            // line 24
            echo "            ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
        ";
        }
        // line 26
        echo "        ";
        $this->displayBlock("form_rows", $context, $blocks);
        echo "
        ";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 32
    public function block_collection_widget($context, array $blocks = array())
    {
        // line 33
        ob_start();
        // line 34
        echo "    ";
        if (array_key_exists("prototype", $context)) {
            // line 35
            echo "        ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), array("data-prototype" => $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["prototype"]) ? $context["prototype"] : $this->getContext($context, "prototype")), 'row')));
            // line 36
            echo "    ";
        }
        // line 37
        echo "    ";
        $this->displayBlock("form_widget", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 41
    public function block_textarea_widget($context, array $blocks = array())
    {
        // line 42
        ob_start();
        // line 43
        echo "    <textarea ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        echo ">";
        echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
        echo "</textarea>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 47
    public function block_choice_widget($context, array $blocks = array())
    {
        // line 48
        ob_start();
        // line 49
        echo "    ";
        if ((isset($context["expanded"]) ? $context["expanded"] : $this->getContext($context, "expanded"))) {
            // line 50
            echo "        ";
            $this->displayBlock("choice_widget_expanded", $context, $blocks);
            echo "
    ";
        } else {
            // line 52
            echo "        ";
            $this->displayBlock("choice_widget_collapsed", $context, $blocks);
            echo "
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 57
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        // line 58
        ob_start();
        // line 59
        echo "    <div ";
        $this->displayBlock("widget_container_attributes", $context, $blocks);
        echo ">
    ";
        // line 60
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 61
            echo "        ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["child"]) ? $context["child"] : $this->getContext($context, "child")), 'widget');
            echo "
        ";
            // line 62
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["child"]) ? $context["child"] : $this->getContext($context, "child")), 'label');
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 68
    public function block_choice_widget_collapsed($context, array $blocks = array())
    {
        // line 69
        ob_start();
        // line 70
        echo "    ";
        if (((((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required")) && (null === (isset($context["empty_value"]) ? $context["empty_value"] : $this->getContext($context, "empty_value")))) && (!(isset($context["empty_value_in_choices"]) ? $context["empty_value_in_choices"] : $this->getContext($context, "empty_value_in_choices")))) && (!(isset($context["multiple"]) ? $context["multiple"] : $this->getContext($context, "multiple"))))) {
            // line 71
            echo "        ";
            $context["required"] = false;
            // line 72
            echo "    ";
        }
        // line 73
        echo "    <select ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        if ((isset($context["multiple"]) ? $context["multiple"] : $this->getContext($context, "multiple"))) {
            echo " multiple=\"multiple\"";
        }
        echo ">
        ";
        // line 74
        if ((!(null === (isset($context["empty_value"]) ? $context["empty_value"] : $this->getContext($context, "empty_value"))))) {
            // line 75
            echo "            <option value=\"\"";
            if (((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required")) && twig_test_empty((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value"))))) {
                echo " selected=\"selected\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["empty_value"]) ? $context["empty_value"] : $this->getContext($context, "empty_value")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
            echo "</option>
        ";
        }
        // line 77
        echo "        ";
        if ((twig_length_filter($this->env, (isset($context["preferred_choices"]) ? $context["preferred_choices"] : $this->getContext($context, "preferred_choices"))) > 0)) {
            // line 78
            echo "            ";
            $context["options"] = (isset($context["preferred_choices"]) ? $context["preferred_choices"] : $this->getContext($context, "preferred_choices"));
            // line 79
            echo "            ";
            $this->displayBlock("choice_widget_options", $context, $blocks);
            echo "
            ";
            // line 80
            if (((twig_length_filter($this->env, (isset($context["choices"]) ? $context["choices"] : $this->getContext($context, "choices"))) > 0) && (!(null === (isset($context["separator"]) ? $context["separator"] : $this->getContext($context, "separator")))))) {
                // line 81
                echo "                <option disabled=\"disabled\">";
                echo twig_escape_filter($this->env, (isset($context["separator"]) ? $context["separator"] : $this->getContext($context, "separator")), "html", null, true);
                echo "</option>
            ";
            }
            // line 83
            echo "        ";
        }
        // line 84
        echo "        ";
        $context["options"] = (isset($context["choices"]) ? $context["choices"] : $this->getContext($context, "choices"));
        // line 85
        echo "        ";
        $this->displayBlock("choice_widget_options", $context, $blocks);
        echo "
    </select>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 90
    public function block_choice_widget_options($context, array $blocks = array())
    {
        // line 91
        ob_start();
        // line 92
        echo "    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["group_label"] => $context["choice"]) {
            // line 93
            echo "        ";
            if (twig_test_iterable((isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")))) {
                // line 94
                echo "            <optgroup label=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["group_label"]) ? $context["group_label"] : $this->getContext($context, "group_label")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
                echo "\">
                ";
                // line 95
                $context["options"] = (isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice"));
                // line 96
                echo "                ";
                $this->displayBlock("choice_widget_options", $context, $blocks);
                echo "
            </optgroup>
        ";
            } else {
                // line 99
                echo "            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")), "value"), "html", null, true);
                echo "\"";
                if ($this->env->getExtension('form')->isSelectedChoice((isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")), (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")))) {
                    echo " selected=\"selected\"";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")), "label"), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
                echo "</option>
        ";
            }
            // line 101
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['group_label'], $context['choice'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 105
    public function block_checkbox_widget($context, array $blocks = array())
    {
        // line 106
        ob_start();
        // line 107
        echo "    <input type=\"checkbox\" ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        if (array_key_exists("value", $context)) {
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
            echo "\"";
        }
        if ((isset($context["checked"]) ? $context["checked"] : $this->getContext($context, "checked"))) {
            echo " checked=\"checked\"";
        }
        echo " />
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 111
    public function block_radio_widget($context, array $blocks = array())
    {
        // line 112
        ob_start();
        // line 113
        echo "    <input type=\"radio\" ";
        $this->displayBlock("widget_attributes", $context, $blocks);
        if (array_key_exists("value", $context)) {
            echo " value=\"";
            echo twig_escape_filter($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "html", null, true);
            echo "\"";
        }
        if ((isset($context["checked"]) ? $context["checked"] : $this->getContext($context, "checked"))) {
            echo " checked=\"checked\"";
        }
        echo " />
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 117
    public function block_datetime_widget($context, array $blocks = array())
    {
        // line 118
        ob_start();
        // line 119
        echo "    ";
        if (((isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")) == "single_text")) {
            // line 120
            echo "        ";
            $this->displayBlock("form_widget_simple", $context, $blocks);
            echo "
    ";
        } else {
            // line 122
            echo "        <div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">
            ";
            // line 123
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date"), 'errors');
            echo "
            ";
            // line 124
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "time"), 'errors');
            echo "
            ";
            // line 125
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date"), 'widget');
            echo "
            ";
            // line 126
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "time"), 'widget');
            echo "
        </div>
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 132
    public function block_date_widget($context, array $blocks = array())
    {
        // line 133
        ob_start();
        // line 134
        echo "    ";
        if (((isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")) == "single_text")) {
            // line 135
            echo "        ";
            $this->displayBlock("form_widget_simple", $context, $blocks);
            echo "
    ";
        } else {
            // line 137
            echo "        <div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">
            ";
            // line 138
            echo strtr((isset($context["date_pattern"]) ? $context["date_pattern"] : $this->getContext($context, "date_pattern")), array("{{ year }}" =>             // line 139
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "year"), 'widget'), "{{ month }}" =>             // line 140
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "month"), 'widget'), "{{ day }}" =>             // line 141
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "day"), 'widget')));
            // line 142
            echo "
        </div>
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 148
    public function block_time_widget($context, array $blocks = array())
    {
        // line 149
        ob_start();
        // line 150
        echo "    ";
        if (((isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")) == "single_text")) {
            // line 151
            echo "        ";
            $this->displayBlock("form_widget_simple", $context, $blocks);
            echo "
    ";
        } else {
            // line 153
            echo "        ";
            $context["vars"] = ((((isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")) == "text")) ? (array("attr" => array("size" => 1))) : (array()));
            // line 154
            echo "        <div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">
            ";
            // line 155
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "hour"), 'widget', (isset($context["vars"]) ? $context["vars"] : $this->getContext($context, "vars")));
            if ((isset($context["with_minutes"]) ? $context["with_minutes"] : $this->getContext($context, "with_minutes"))) {
                echo ":";
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "minute"), 'widget', (isset($context["vars"]) ? $context["vars"] : $this->getContext($context, "vars")));
            }
            if ((isset($context["with_seconds"]) ? $context["with_seconds"] : $this->getContext($context, "with_seconds"))) {
                echo ":";
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "second"), 'widget', (isset($context["vars"]) ? $context["vars"] : $this->getContext($context, "vars")));
            }
            // line 156
            echo "        </div>
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 161
    public function block_number_widget($context, array $blocks = array())
    {
        // line 162
        ob_start();
        // line 163
        echo "    ";
        // line 164
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "text")) : ("text"));
        // line 165
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 169
    public function block_integer_widget($context, array $blocks = array())
    {
        // line 170
        ob_start();
        // line 171
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "number")) : ("number"));
        // line 172
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 176
    public function block_money_widget($context, array $blocks = array())
    {
        // line 177
        ob_start();
        // line 178
        echo "    ";
        echo strtr((isset($context["money_pattern"]) ? $context["money_pattern"] : $this->getContext($context, "money_pattern")), array("{{ widget }}" => $this->renderBlock("form_widget_simple", $context, $blocks)));
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 182
    public function block_url_widget($context, array $blocks = array())
    {
        // line 183
        ob_start();
        // line 184
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "url")) : ("url"));
        // line 185
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 189
    public function block_search_widget($context, array $blocks = array())
    {
        // line 190
        ob_start();
        // line 191
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "search")) : ("search"));
        // line 192
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 196
    public function block_percent_widget($context, array $blocks = array())
    {
        // line 197
        ob_start();
        // line 198
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "text")) : ("text"));
        // line 199
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo " %
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 203
    public function block_password_widget($context, array $blocks = array())
    {
        // line 204
        ob_start();
        // line 205
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "password")) : ("password"));
        // line 206
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 210
    public function block_hidden_widget($context, array $blocks = array())
    {
        // line 211
        ob_start();
        // line 212
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "hidden")) : ("hidden"));
        // line 213
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 217
    public function block_email_widget($context, array $blocks = array())
    {
        // line 218
        ob_start();
        // line 219
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "email")) : ("email"));
        // line 220
        echo "    ";
        $this->displayBlock("form_widget_simple", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 224
    public function block_button_widget($context, array $blocks = array())
    {
        // line 225
        ob_start();
        // line 226
        echo "    ";
        if (twig_test_empty((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")))) {
            // line 227
            echo "        ";
            $context["label"] = $this->env->getExtension('form')->humanize((isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")));
            // line 228
            echo "    ";
        }
        // line 229
        echo "    <button type=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "button")) : ("button")), "html", null, true);
        echo "\" ";
        $this->displayBlock("button_attributes", $context, $blocks);
        echo ">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
        echo "</button>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 233
    public function block_submit_widget($context, array $blocks = array())
    {
        // line 234
        ob_start();
        // line 235
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "submit")) : ("submit"));
        // line 236
        echo "    ";
        $this->displayBlock("button_widget", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 240
    public function block_reset_widget($context, array $blocks = array())
    {
        // line 241
        ob_start();
        // line 242
        echo "    ";
        $context["type"] = ((array_key_exists("type", $context)) ? (_twig_default_filter((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "reset")) : ("reset"));
        // line 243
        echo "    ";
        $this->displayBlock("button_widget", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 249
    public function block_form_label($context, array $blocks = array())
    {
        // line 250
        ob_start();
        // line 251
        echo "    ";
        if ((!((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")) === false))) {
            // line 252
            echo "        ";
            if ((!(isset($context["compound"]) ? $context["compound"] : $this->getContext($context, "compound")))) {
                // line 253
                echo "            ";
                $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) ? $context["label_attr"] : $this->getContext($context, "label_attr")), array("for" => (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id"))));
                // line 254
                echo "        ";
            }
            // line 255
            echo "        ";
            if ((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required"))) {
                // line 256
                echo "            ";
                $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) ? $context["label_attr"] : $this->getContext($context, "label_attr")), array("class" => trim(((($this->getAttribute((isset($context["label_attr"]) ? $context["label_attr"] : null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["label_attr"]) ? $context["label_attr"] : null), "class"), "")) : ("")) . " required"))));
                // line 257
                echo "        ";
            }
            // line 258
            echo "        ";
            if (twig_test_empty((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")))) {
                // line 259
                echo "            ";
                $context["label"] = $this->env->getExtension('form')->humanize((isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")));
                // line 260
                echo "        ";
            }
            // line 261
            echo "        <label";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["label_attr"]) ? $context["label_attr"] : $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
            echo "</label>
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 266
    public function block_button_label($context, array $blocks = array())
    {
    }

    // line 270
    public function block_repeated_row($context, array $blocks = array())
    {
        // line 271
        ob_start();
        // line 272
        echo "    ";
        // line 276
        echo "    ";
        $this->displayBlock("form_rows", $context, $blocks);
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 280
    public function block_form_row($context, array $blocks = array())
    {
        // line 281
        ob_start();
        // line 282
        echo "    <div>
        ";
        // line 283
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'label');
        echo "
        ";
        // line 284
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
        ";
        // line 285
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 290
    public function block_button_row($context, array $blocks = array())
    {
        // line 291
        ob_start();
        // line 292
        echo "    <div>
        ";
        // line 293
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    </div>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 298
    public function block_hidden_row($context, array $blocks = array())
    {
        // line 299
        echo "    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
    }

    // line 304
    public function block_form($context, array $blocks = array())
    {
        // line 305
        ob_start();
        // line 306
        echo "    ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 307
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 308
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 312
    public function block_form_start($context, array $blocks = array())
    {
        // line 313
        ob_start();
        // line 314
        echo "    ";
        $context["method"] = twig_upper_filter($this->env, (isset($context["method"]) ? $context["method"] : $this->getContext($context, "method")));
        // line 315
        echo "    ";
        if (twig_in_filter((isset($context["method"]) ? $context["method"] : $this->getContext($context, "method")), array(0 => "GET", 1 => "POST"))) {
            // line 316
            echo "        ";
            $context["form_method"] = (isset($context["method"]) ? $context["method"] : $this->getContext($context, "method"));
            // line 317
            echo "    ";
        } else {
            // line 318
            echo "        ";
            $context["form_method"] = "POST";
            // line 319
            echo "    ";
        }
        // line 320
        echo "    <form name=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name"), "html", null, true);
        echo "\" method=\"";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, (isset($context["form_method"]) ? $context["form_method"] : $this->getContext($context, "form_method"))), "html", null, true);
        echo "\" action=\"";
        echo twig_escape_filter($this->env, (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), "html", null, true);
        echo "\"";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
            echo "=\"";
            echo twig_escape_filter($this->env, (isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), "html", null, true);
            echo "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        if ((isset($context["multipart"]) ? $context["multipart"] : $this->getContext($context, "multipart"))) {
            echo " enctype=\"multipart/form-data\"";
        }
        echo ">
    ";
        // line 321
        if (((isset($context["form_method"]) ? $context["form_method"] : $this->getContext($context, "form_method")) != (isset($context["method"]) ? $context["method"] : $this->getContext($context, "method")))) {
            // line 322
            echo "        <input type=\"hidden\" name=\"_method\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["method"]) ? $context["method"] : $this->getContext($context, "method")), "html", null, true);
            echo "\" />
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 327
    public function block_form_end($context, array $blocks = array())
    {
        // line 328
        ob_start();
        // line 329
        echo "    ";
        if (((!array_key_exists("render_rest", $context)) || (isset($context["render_rest"]) ? $context["render_rest"] : $this->getContext($context, "render_rest")))) {
            // line 330
            echo "        ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
            echo "
    ";
        }
        // line 332
        echo "    </form>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 336
    public function block_form_enctype($context, array $blocks = array())
    {
        // line 337
        ob_start();
        // line 338
        echo "    ";
        if ((isset($context["multipart"]) ? $context["multipart"] : $this->getContext($context, "multipart"))) {
            echo "enctype=\"multipart/form-data\"";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 342
    public function block_form_errors($context, array $blocks = array())
    {
        // line 343
        ob_start();
        // line 344
        echo "    ";
        if ((twig_length_filter($this->env, (isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors"))) > 0)) {
            // line 345
            echo "    <ul>
        ";
            // line 346
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 347
                echo "            <li>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message"), "html", null, true);
                echo "</li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 349
            echo "    </ul>
    ";
        }
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 354
    public function block_form_rest($context, array $blocks = array())
    {
        // line 355
        ob_start();
        // line 356
        echo "    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 357
            echo "        ";
            if ((!$this->getAttribute((isset($context["child"]) ? $context["child"] : $this->getContext($context, "child")), "rendered"))) {
                // line 358
                echo "            ";
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["child"]) ? $context["child"] : $this->getContext($context, "child")), 'row');
                echo "
        ";
            }
            // line 360
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 366
    public function block_form_rows($context, array $blocks = array())
    {
        // line 367
        ob_start();
        // line 368
        echo "    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 369
            echo "        ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["child"]) ? $context["child"] : $this->getContext($context, "child")), 'row');
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 374
    public function block_widget_attributes($context, array $blocks = array())
    {
        // line 375
        ob_start();
        // line 376
        echo "    id=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
        echo "\" name=\"";
        echo twig_escape_filter($this->env, (isset($context["full_name"]) ? $context["full_name"] : $this->getContext($context, "full_name")), "html", null, true);
        echo "\"";
        // line 377
        if ((isset($context["read_only"]) ? $context["read_only"] : $this->getContext($context, "read_only"))) {
            echo " readonly=\"readonly\"";
        }
        // line 378
        if ((isset($context["disabled"]) ? $context["disabled"] : $this->getContext($context, "disabled"))) {
            echo " disabled=\"disabled\"";
        }
        // line 379
        if ((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required"))) {
            echo " required=\"required\"";
        }
        // line 380
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            // line 381
            echo " ";
            // line 382
            if (twig_in_filter((isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), array(0 => "placeholder", 1 => "title"))) {
                // line 383
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
                echo "\"";
            } elseif (((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")) === true)) {
                // line 385
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "\"";
            } elseif ((!((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")) === false))) {
                // line 387
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), "html", null, true);
                echo "\"";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 393
    public function block_widget_container_attributes($context, array $blocks = array())
    {
        // line 394
        ob_start();
        // line 395
        if ((!twig_test_empty((isset($context["id"]) ? $context["id"] : $this->getContext($context, "id"))))) {
            echo "id=\"";
            echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
            echo "\"";
        }
        // line 396
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            // line 397
            echo " ";
            // line 398
            if (twig_in_filter((isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), array(0 => "placeholder", 1 => "title"))) {
                // line 399
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
                echo "\"";
            } elseif (((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")) === true)) {
                // line 401
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "\"";
            } elseif ((!((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")) === false))) {
                // line 403
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), "html", null, true);
                echo "\"";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 409
    public function block_button_attributes($context, array $blocks = array())
    {
        // line 410
        ob_start();
        // line 411
        echo "    id=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
        echo "\" name=\"";
        echo twig_escape_filter($this->env, (isset($context["full_name"]) ? $context["full_name"] : $this->getContext($context, "full_name")), "html", null, true);
        echo "\"";
        if ((isset($context["disabled"]) ? $context["disabled"] : $this->getContext($context, "disabled"))) {
            echo " disabled=\"disabled\"";
        }
        // line 412
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")));
        foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
            // line 413
            echo " ";
            // line 414
            if (twig_in_filter((isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), array(0 => "placeholder", 1 => "title"))) {
                // line 415
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), array(), (isset($context["translation_domain"]) ? $context["translation_domain"] : $this->getContext($context, "translation_domain"))), "html", null, true);
                echo "\"";
            } elseif (((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")) === true)) {
                // line 417
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "\"";
            } elseif ((!((isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")) === false))) {
                // line 419
                echo twig_escape_filter($this->env, (isset($context["attrname"]) ? $context["attrname"] : $this->getContext($context, "attrname")), "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, (isset($context["attrvalue"]) ? $context["attrvalue"] : $this->getContext($context, "attrvalue")), "html", null, true);
                echo "\"";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    public function getTemplateName()
    {
        return "form_div_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1402 => 419,  1390 => 415,  1386 => 413,  1382 => 412,  1373 => 411,  1371 => 410,  1368 => 409,  1355 => 403,  1349 => 401,  1343 => 399,  1341 => 398,  1339 => 397,  1335 => 396,  1329 => 395,  1327 => 394,  1324 => 393,  1311 => 387,  1305 => 385,  1299 => 383,  1297 => 382,  1295 => 381,  1291 => 380,  1287 => 379,  1283 => 378,  1279 => 377,  1273 => 376,  1271 => 375,  1268 => 374,  1256 => 369,  1251 => 368,  1249 => 367,  1246 => 366,  1237 => 360,  1231 => 358,  1228 => 357,  1223 => 356,  1221 => 355,  1218 => 354,  1211 => 349,  1202 => 347,  1198 => 346,  1195 => 345,  1192 => 344,  1190 => 343,  1187 => 342,  1179 => 338,  1177 => 337,  1174 => 336,  1168 => 332,  1162 => 330,  1159 => 329,  1157 => 328,  1154 => 327,  1145 => 322,  1143 => 321,  1118 => 320,  1115 => 319,  1112 => 318,  1109 => 317,  1106 => 316,  1103 => 315,  1100 => 314,  1098 => 313,  1095 => 312,  1088 => 308,  1084 => 307,  1079 => 306,  1074 => 304,  1067 => 299,  1056 => 293,  1053 => 292,  1040 => 285,  1036 => 284,  1029 => 282,  1027 => 281,  1024 => 280,  1016 => 276,  1014 => 272,  1012 => 271,  1009 => 270,  982 => 261,  979 => 260,  976 => 259,  973 => 258,  964 => 255,  961 => 254,  958 => 253,  952 => 251,  950 => 250,  939 => 243,  936 => 242,  934 => 241,  931 => 240,  920 => 235,  918 => 234,  915 => 233,  903 => 229,  900 => 228,  897 => 227,  894 => 226,  892 => 225,  889 => 224,  881 => 220,  876 => 218,  873 => 217,  865 => 213,  857 => 210,  849 => 206,  846 => 205,  841 => 203,  814 => 191,  793 => 182,  769 => 171,  767 => 170,  751 => 163,  739 => 156,  715 => 151,  712 => 150,  707 => 148,  697 => 141,  695 => 139,  689 => 137,  683 => 135,  662 => 125,  598 => 107,  459 => 69,  792 => 488,  775 => 485,  749 => 162,  746 => 161,  710 => 149,  694 => 138,  690 => 469,  677 => 465,  649 => 122,  606 => 449,  1077 => 305,  1073 => 656,  1069 => 654,  1064 => 298,  1055 => 648,  1051 => 291,  1048 => 290,  1044 => 645,  1035 => 639,  1023 => 632,  1021 => 631,  1013 => 627,  1004 => 266,  1000 => 623,  997 => 622,  993 => 621,  984 => 615,  975 => 609,  972 => 608,  970 => 257,  967 => 256,  959 => 602,  955 => 252,  947 => 249,  941 => 595,  935 => 592,  930 => 590,  926 => 589,  923 => 236,  919 => 587,  909 => 580,  905 => 579,  896 => 573,  891 => 571,  888 => 570,  884 => 568,  880 => 566,  870 => 560,  864 => 558,  862 => 212,  844 => 204,  836 => 543,  828 => 197,  815 => 531,  810 => 492,  796 => 183,  790 => 519,  788 => 486,  774 => 509,  770 => 507,  754 => 499,  742 => 492,  737 => 490,  718 => 482,  705 => 480,  702 => 472,  698 => 471,  686 => 468,  642 => 449,  636 => 446,  628 => 444,  626 => 443,  622 => 452,  551 => 424,  308 => 13,  20 => 1,  327 => 126,  249 => 92,  858 => 576,  730 => 451,  659 => 398,  654 => 123,  590 => 339,  438 => 271,  664 => 463,  658 => 124,  650 => 396,  643 => 120,  588 => 262,  567 => 414,  345 => 147,  1594 => 1360,  1587 => 1356,  1583 => 1355,  1577 => 1352,  1573 => 1351,  1569 => 1350,  1507 => 1291,  1465 => 1252,  1456 => 1246,  1449 => 1242,  1428 => 1224,  1424 => 1223,  1420 => 1222,  1416 => 1221,  1412 => 1220,  1408 => 1219,  1404 => 1218,  1400 => 1217,  1396 => 417,  1392 => 1215,  1388 => 414,  860 => 211,  854 => 552,  823 => 665,  817 => 192,  791 => 642,  785 => 178,  773 => 639,  750 => 522,  634 => 456,  595 => 380,  571 => 374,  485 => 305,  297 => 200,  874 => 562,  801 => 185,  692 => 474,  688 => 415,  684 => 414,  679 => 466,  675 => 132,  671 => 465,  612 => 373,  562 => 329,  624 => 376,  545 => 371,  605 => 336,  601 => 446,  575 => 375,  488 => 209,  776 => 467,  703 => 397,  573 => 249,  557 => 96,  401 => 172,  287 => 131,  1156 => 880,  1083 => 810,  963 => 604,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 544,  830 => 198,  824 => 537,  813 => 601,  800 => 523,  794 => 592,  786 => 590,  783 => 177,  779 => 640,  768 => 580,  764 => 169,  760 => 578,  756 => 165,  752 => 576,  748 => 575,  744 => 574,  740 => 491,  732 => 487,  405 => 49,  333 => 115,  307 => 128,  299 => 8,  257 => 84,  807 => 491,  617 => 112,  611 => 311,  596 => 106,  591 => 436,  491 => 294,  431 => 189,  415 => 180,  291 => 173,  284 => 177,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 434,  582 => 396,  578 => 432,  317 => 208,  565 => 430,  468 => 284,  281 => 409,  465 => 283,  361 => 146,  332 => 20,  328 => 113,  320 => 127,  276 => 393,  272 => 124,  245 => 335,  724 => 154,  668 => 464,  660 => 464,  653 => 293,  648 => 292,  574 => 431,  566 => 386,  563 => 429,  559 => 427,  550 => 94,  547 => 93,  542 => 421,  514 => 415,  492 => 252,  484 => 201,  410 => 173,  397 => 246,  388 => 42,  380 => 160,  366 => 33,  331 => 140,  323 => 128,  315 => 111,  300 => 121,  296 => 121,  832 => 563,  734 => 471,  727 => 476,  706 => 473,  554 => 291,  548 => 304,  533 => 300,  528 => 216,  478 => 74,  442 => 62,  417 => 143,  372 => 199,  336 => 164,  924 => 587,  851 => 517,  826 => 532,  819 => 491,  805 => 480,  798 => 184,  762 => 504,  646 => 451,  632 => 378,  625 => 453,  620 => 451,  616 => 440,  555 => 95,  538 => 237,  534 => 418,  526 => 306,  509 => 83,  482 => 287,  386 => 159,  357 => 158,  353 => 121,  344 => 24,  339 => 227,  335 => 21,  329 => 131,  321 => 135,  610 => 337,  462 => 202,  394 => 168,  370 => 146,  364 => 197,  349 => 200,  340 => 145,  325 => 129,  319 => 194,  304 => 185,  295 => 174,  289 => 196,  280 => 194,  126 => 147,  845 => 613,  772 => 172,  685 => 337,  680 => 134,  676 => 467,  644 => 291,  638 => 118,  630 => 301,  618 => 298,  614 => 111,  539 => 229,  531 => 227,  516 => 319,  476 => 286,  464 => 71,  421 => 266,  343 => 146,  324 => 112,  316 => 16,  313 => 15,  303 => 122,  292 => 128,  288 => 4,  510 => 280,  506 => 298,  502 => 233,  498 => 296,  425 => 267,  419 => 198,  411 => 140,  389 => 160,  378 => 157,  311 => 14,  708 => 550,  619 => 113,  580 => 376,  558 => 306,  552 => 244,  544 => 238,  537 => 301,  523 => 233,  512 => 84,  483 => 208,  452 => 241,  448 => 206,  436 => 225,  408 => 50,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 283,  1026 => 633,  1018 => 630,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 581,  907 => 680,  899 => 674,  893 => 572,  885 => 671,  882 => 670,  878 => 219,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 548,  837 => 649,  833 => 199,  829 => 647,  821 => 664,  816 => 602,  812 => 190,  808 => 641,  804 => 640,  780 => 176,  418 => 177,  100 => 36,  277 => 176,  521 => 282,  513 => 280,  508 => 225,  499 => 212,  495 => 295,  489 => 306,  472 => 257,  396 => 157,  392 => 185,  377 => 37,  356 => 122,  352 => 138,  348 => 140,  192 => 112,  883 => 685,  699 => 142,  449 => 198,  432 => 222,  428 => 59,  414 => 52,  406 => 213,  403 => 48,  399 => 178,  390 => 43,  376 => 200,  373 => 156,  369 => 217,  265 => 105,  261 => 85,  253 => 342,  898 => 592,  825 => 196,  725 => 431,  721 => 153,  717 => 429,  713 => 456,  709 => 427,  704 => 419,  700 => 418,  696 => 140,  661 => 390,  655 => 457,  647 => 387,  640 => 119,  635 => 117,  631 => 342,  570 => 321,  564 => 99,  556 => 318,  549 => 411,  541 => 310,  535 => 309,  527 => 91,  524 => 90,  520 => 305,  505 => 297,  497 => 222,  494 => 308,  479 => 302,  475 => 285,  467 => 72,  458 => 207,  454 => 206,  450 => 64,  446 => 197,  184 => 233,  180 => 70,  172 => 68,  160 => 32,  152 => 54,  937 => 593,  809 => 189,  759 => 493,  753 => 164,  745 => 493,  738 => 443,  733 => 426,  729 => 155,  682 => 467,  678 => 133,  674 => 402,  670 => 419,  666 => 126,  629 => 454,  623 => 299,  615 => 355,  608 => 372,  603 => 439,  599 => 351,  553 => 425,  536 => 419,  530 => 417,  522 => 406,  519 => 304,  515 => 85,  507 => 282,  501 => 80,  493 => 78,  490 => 77,  486 => 251,  477 => 270,  471 => 237,  463 => 242,  460 => 281,  456 => 68,  445 => 272,  441 => 196,  433 => 60,  429 => 188,  424 => 266,  420 => 265,  416 => 264,  412 => 214,  385 => 41,  382 => 131,  118 => 49,  597 => 247,  593 => 105,  589 => 323,  585 => 237,  581 => 282,  576 => 101,  572 => 318,  568 => 254,  561 => 277,  546 => 423,  540 => 309,  532 => 410,  529 => 92,  525 => 331,  517 => 404,  511 => 319,  503 => 81,  500 => 223,  496 => 79,  487 => 251,  481 => 286,  473 => 308,  470 => 73,  466 => 209,  455 => 195,  451 => 224,  447 => 247,  443 => 246,  439 => 195,  434 => 270,  426 => 58,  422 => 184,  400 => 47,  395 => 135,  114 => 111,  260 => 363,  256 => 96,  248 => 336,  266 => 366,  262 => 93,  250 => 341,  242 => 136,  234 => 90,  226 => 84,  222 => 297,  218 => 105,  279 => 142,  275 => 105,  271 => 374,  267 => 101,  263 => 365,  259 => 103,  255 => 353,  239 => 150,  81 => 40,  65 => 17,  1085 => 1059,  210 => 270,  198 => 103,  194 => 248,  190 => 57,  186 => 239,  178 => 64,  150 => 55,  146 => 181,  134 => 161,  124 => 132,  104 => 90,  391 => 176,  383 => 174,  375 => 163,  371 => 35,  367 => 155,  363 => 32,  359 => 123,  351 => 141,  347 => 119,  188 => 90,  301 => 204,  293 => 6,  113 => 40,  174 => 217,  170 => 84,  148 => 29,  77 => 25,  231 => 90,  165 => 83,  161 => 202,  153 => 77,  195 => 106,  191 => 246,  34 => 4,  155 => 55,  310 => 122,  306 => 286,  302 => 125,  290 => 5,  286 => 112,  282 => 109,  274 => 96,  270 => 102,  251 => 182,  237 => 91,  233 => 304,  225 => 298,  213 => 78,  205 => 78,  175 => 58,  167 => 71,  137 => 84,  129 => 148,  23 => 3,  223 => 119,  215 => 280,  211 => 119,  207 => 269,  202 => 266,  197 => 249,  185 => 66,  181 => 232,  70 => 19,  358 => 151,  354 => 231,  350 => 26,  346 => 229,  342 => 23,  338 => 116,  334 => 141,  330 => 163,  326 => 138,  318 => 141,  206 => 92,  244 => 112,  236 => 133,  232 => 89,  228 => 84,  216 => 79,  212 => 279,  200 => 72,  110 => 38,  90 => 27,  84 => 41,  53 => 11,  127 => 35,  97 => 62,  76 => 31,  58 => 15,  480 => 75,  474 => 211,  469 => 284,  461 => 70,  457 => 234,  453 => 199,  444 => 192,  440 => 246,  437 => 61,  435 => 178,  430 => 257,  427 => 211,  423 => 57,  413 => 234,  409 => 238,  407 => 138,  402 => 226,  398 => 136,  393 => 245,  387 => 164,  384 => 132,  381 => 149,  379 => 173,  374 => 36,  368 => 34,  365 => 125,  362 => 124,  360 => 232,  355 => 27,  341 => 117,  337 => 22,  322 => 173,  314 => 140,  312 => 124,  309 => 129,  305 => 108,  298 => 120,  294 => 112,  285 => 3,  283 => 115,  278 => 408,  268 => 373,  264 => 122,  258 => 354,  252 => 117,  247 => 149,  241 => 90,  229 => 85,  220 => 290,  214 => 122,  177 => 69,  169 => 210,  140 => 27,  132 => 25,  128 => 42,  107 => 37,  61 => 2,  273 => 392,  269 => 107,  254 => 159,  243 => 327,  240 => 326,  238 => 312,  235 => 311,  230 => 303,  227 => 301,  224 => 141,  221 => 80,  219 => 88,  217 => 289,  208 => 76,  204 => 267,  179 => 224,  159 => 196,  143 => 27,  135 => 46,  119 => 117,  102 => 30,  71 => 19,  67 => 16,  63 => 18,  59 => 13,  201 => 74,  196 => 92,  183 => 71,  171 => 216,  166 => 209,  163 => 82,  158 => 80,  156 => 195,  151 => 188,  142 => 26,  138 => 47,  136 => 168,  121 => 131,  117 => 37,  105 => 34,  91 => 56,  62 => 14,  49 => 12,  87 => 26,  28 => 3,  94 => 57,  89 => 47,  85 => 26,  75 => 22,  68 => 30,  56 => 12,  38 => 5,  24 => 3,  25 => 35,  21 => 2,  31 => 3,  26 => 3,  19 => 1,  93 => 28,  88 => 30,  78 => 24,  46 => 10,  44 => 8,  27 => 3,  79 => 32,  72 => 18,  69 => 13,  47 => 9,  40 => 11,  37 => 7,  22 => 2,  246 => 136,  157 => 98,  145 => 74,  139 => 169,  131 => 160,  123 => 61,  120 => 38,  115 => 40,  111 => 110,  108 => 33,  101 => 89,  98 => 29,  96 => 67,  83 => 33,  74 => 20,  66 => 12,  55 => 12,  52 => 12,  50 => 10,  43 => 9,  41 => 7,  35 => 4,  32 => 5,  29 => 3,  209 => 132,  203 => 73,  199 => 265,  193 => 47,  189 => 240,  187 => 38,  182 => 87,  176 => 223,  173 => 85,  168 => 61,  164 => 203,  162 => 59,  154 => 189,  149 => 182,  147 => 51,  144 => 176,  141 => 175,  133 => 45,  130 => 46,  125 => 41,  122 => 28,  116 => 116,  112 => 39,  109 => 105,  106 => 104,  103 => 20,  99 => 68,  95 => 27,  92 => 31,  86 => 46,  82 => 25,  80 => 24,  73 => 23,  64 => 3,  60 => 20,  57 => 19,  54 => 19,  51 => 13,  48 => 10,  45 => 8,  42 => 7,  39 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
