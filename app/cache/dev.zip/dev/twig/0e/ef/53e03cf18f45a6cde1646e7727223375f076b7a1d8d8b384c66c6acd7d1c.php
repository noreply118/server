<?php

/* AcmeDemoBundle:Demo:payment-analyzer-ratetrade.html.twig */
class __TwigTemplate_0eef53e03cf18f45a6cde1646e7727223375f076b7a1d8d8b384c66c6acd7d1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/emicalculator.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery-ui.css"), "html", null, true);
        echo "\">
<style type=\"text/css\">
    \${demo.css}

    #ana-result td{
        padding: 20px;
    }
</style>
<div class=\"left-details\" style=\"width:100%!important;\">
    <div class=\"right-inner\">
        <div class=\"inner\">
            <form class=\"imageform\">
                <div class=\"entry-content\">
                    <div id=\"emicalcalulatorinnerform\" style=\"padding: 0px 0px 10px;\">
                        <div class=\"pbox\">
                            <div class=\"lamount\">
                                <label for=\"loanamount\" class=\"orange\"><strong>Mortgage Amount (\$)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"property-error\" style=\"color: #993A00;\"></label>
                                <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                                <div id=\"loanamountslider\" style=\"margin-top: 45px;\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div>
                            </div>
                        </div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"loanterm\" class=\"orange\"><strong class=\"orange\">Ammortization Period (Yr)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"ammort-error\" style=\"color: #993A00;\"></label>
                                <input id=\"loanterm\" name=\"loanterm\" value=\"\" type=\"text\" />
                                <div id=\"loantermslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 19.67%;\">|<br/><span class=\"marker\">5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 39.8%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left: 59.8%;\">|<br/><span class=\"marker\">15</span></span>
                                    <span class=\"tick\" style=\"left: 79.67%;\">|<br/><span class=\"marker\">20</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">25</span></span>
                                </div>
                            </div>
                        </div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"mortrate\" class=\"orange\"><strong class=\"orange\">Mortgage Rate (%)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"mortrate-error\" style=\"color: #993A00;\"></label>
                                <input id=\"mortrate\" name=\"mortrate\" value=\"\" type=\"text\" />
                                <div id=\"mortrateslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class=\"left-details\" style=\"width:100%!important;\">
    <br/><br/>
    <div class=\"box-full payresult\">
        <table id=\"ana-result\">
            <tr class=\"aprow\">
                <td><strong style=\"color:rgb(127, 0, 135);\">&nbsp;</strong></td>
                <td><span style=\"color: rgb(35, 98, 2);\">Monthly</span></td>
                <td><span style=\"color: rgb(35, 98, 2);\">Semi Monthly</span></td>
                <td><span style=\"color: rgb(35, 98, 2);\">Bi Weekly</span> </td>
                <td><span style=\"color: rgb(35, 98, 2);\">Accelerated Bi Weekly</span></td>
                <td><span style=\"color: rgb(35, 98, 2);\">Weekly</span></td>
                <td><span style=\"color: rgb(35, 98, 2);\">Accelerated Weekly</span></td>
            </tr>
            <tr>
                <td><strong style=\"color:rgb(127, 0, 135);\">Payment</strong></td>
                <td><span class=\"emi-monthly\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"emi-semi_monthly\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"emi-bi_weekly\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"emi-acc_bi_weekly\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"emi-weekly\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"emi-acc_weekly\" style=\"font-size: 15px;\"></span></td>
            </tr>
            <tr>
                <td><strong style=\"color:rgb(127, 0, 135);\">Ammortization</strong></td>
                <td><span class=\"monthly-ammort\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"semi_monthly-ammort\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"bi_weekly-ammort\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"acc_bi_weekly-ammort\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"weekly-ammort\" style=\"font-size: 15px;\"></span></td>
                <td><span class=\"acc_weekly-ammort\" style=\"font-size: 15px;\"></span></td>
            </tr>
        </table>
    </div>
\t  <div class=\"box-full payresult1\" style=\"display:none;\">
        <table id=\"ana-result1\">
            <tr>
              <th coslspan=\"2\"><strong style=\"color:rgb(127, 0, 135);\">Payment</strong></th>
            
            </tr>
            <tr>
                <td><span style=\"color: rgb(35, 98, 2);\">Monthly</span></td>   <td><span class=\"emi-monthly\" style=\"font-size: 15px;\"></span></td></tr><tr>
                <td><span style=\"color: rgb(35, 98, 2);\">Semi Monthly</span></td> <td><span class=\"emi-semi_monthly\" style=\"font-size: 15px;\"></span></td></tr><tr>
                <td><span style=\"color: rgb(35, 98, 2);\">Bi Weekly</span> </td><td><span class=\"emi-bi_weekly\" style=\"font-size: 15px;\"></span></td></tr><tr>
                <td><span style=\"color: rgb(35, 98, 2);\">Accelerated Bi Weekly</span></td><td><span class=\"emi-acc_bi_weekly\" style=\"font-size: 15px;\"></span></td></tr><tr>
                 <td><span style=\"color: rgb(35, 98, 2);\">Weekly</span></td> <td><span class=\"emi-weekly\" style=\"font-size: 15px;\"></span></td></tr><tr>
                  <td><span style=\"color: rgb(35, 98, 2);\">Accelerated Weekly</span></td> <td><span class=\"emi-acc_weekly\" style=\"font-size: 15px;\"></span></td>
            </tr>
            <tr>
                <th colspan=\"2\"><strong style=\"color:rgb(127, 0, 135);\">Ammortization</strong></th></tr><tr>
                 <td><span style=\"color: rgb(35, 98, 2);\">Monthly</span></td>  <td><span class=\"monthly-ammort\" style=\"font-size: 15px;\"></span></td></tr><tr>
                <td><span style=\"color: rgb(35, 98, 2);\">Semi Monthly</span></td> <td><span class=\"semi_monthly-ammort\" style=\"font-size: 15px;\"></span></td></tr><tr>
                   <td><span style=\"color: rgb(35, 98, 2);\">Bi Weekly</span> </td><td><span class=\"bi_weekly-ammort\" style=\"font-size: 15px;\"></span></td></tr><tr>
                 <td><span style=\"color: rgb(35, 98, 2);\">Accelerated Bi Weekly</span></td><td><span class=\"acc_bi_weekly-ammort\" style=\"font-size: 15px;\"></span></td></tr><tr>
                 <td><span style=\"color: rgb(35, 98, 2);\">Weekly</span></td> <td><span class=\"weekly-ammort\" style=\"font-size: 15px;\"></span></td></tr><tr>
                  <td><span style=\"color: rgb(35, 98, 2);\">Accelerated Weekly</span></td><td><span class=\"acc_weekly-ammort\" style=\"font-size: 15px;\"></span></td>
            </tr>
        </table>
    </div>
</div>
<script type=\"text/javascript\" src=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery_ss.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 145
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 147
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/superfish.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/analyser_ratetrade.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 152
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 153
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.datepicker.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 154
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/highcharts.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 155
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/exporting.js"), "html", null, true);
        echo "\"></script>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:payment-analyzer-ratetrade.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  231 => 155,  165 => 130,  161 => 129,  153 => 127,  195 => 146,  191 => 145,  34 => 8,  155 => 93,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 134,  167 => 127,  137 => 94,  129 => 92,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 128,  197 => 105,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 97,  305 => 95,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 131,  140 => 55,  132 => 51,  128 => 49,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 154,  224 => 169,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 142,  159 => 109,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 13,  201 => 149,  196 => 90,  183 => 143,  171 => 128,  166 => 71,  163 => 126,  158 => 79,  156 => 66,  151 => 92,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 64,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 9,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 6,  19 => 1,  93 => 28,  88 => 31,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 6,  37 => 14,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 15,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 151,  203 => 148,  199 => 147,  193 => 104,  189 => 103,  187 => 144,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 107,  149 => 97,  147 => 58,  144 => 49,  141 => 95,  133 => 93,  130 => 41,  125 => 44,  122 => 48,  116 => 41,  112 => 42,  109 => 65,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 36,  86 => 51,  82 => 50,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 19,  36 => 5,  33 => 4,  30 => 10,);
    }
}
