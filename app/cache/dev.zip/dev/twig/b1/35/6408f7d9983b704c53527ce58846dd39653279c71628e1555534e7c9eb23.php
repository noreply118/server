<?php

/* AcmeDemoBundle:Demo:mortgage-payment-ratetrade.html.twig */
class __TwigTemplate_b1356408f7d9983b704c53527ce58846dd39653279c71628e1555534e7c9eb23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/emicalculator.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery-ui.css"), "html", null, true);
        echo "\">
 <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <style type=\"text/css\">
        \${demo.css}
    </style>
        <div class=\"left-details newdatain\" style=\"width:100%!important;\">
            <div class=\"right-inner\">
                <div class=\"inner\">
                    <form class=\"imageform\">
                        <div class=\"entry-content\">
                            <div id=\"emicalcalulatorinnerform\" style=\"padding: 0px 0px 10px;\">
                             <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"loanamount\" class=\"orange\"><strong> Property Value (\$)</strong> </label>
                                  <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"property-error errorc\" style=\"color: #993A00;\"></label>
                                    <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                                     <span class=\"prc-addon\">\$</span>
                              
                                <div id=\"loanamountslider\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                               <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$250,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$750,000</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                 </div> </div>
                           </div>
                           <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"loaninterest\" class=\"orange\"><strong> Down Payment (%)</strong> </label>
                                    <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"down-error errorc\" style=\"color: rgb(153, 58, 0);\"></label>
                                    <input id=\"loaninterest\" name=\"loaninterest\" value=\"\" type=\"text\" form=\"percent\" />
                                      <span class=\"prc-addon\">%</span>
                                                                  
                            <div id=\"loaninterestslider\"></div>
                            <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">7.5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left:  50%;\">|<br/><span class=\"marker\">12.5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">15</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">17.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">20</span></span>
                           </div></div>
                                </div>
                                     <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"loanterm\" class=\"orange\"><strong class=\"orange\"> Amortization Period (Yr)</strong> </label>
                                    <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"ammort-error errorc\" style=\"color: #993A00;\"></label>
                                    <input id=\"loanterm\" name=\"loanterm\" value=\"\" type=\"text\" />
                                    <span class=\"prc-addon\">Yr</span>
                                
                                <div id=\"loantermslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 19.67%;\">|<br/><span class=\"marker\">5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 39.8%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left: 59.8%;\">|<br/><span class=\"marker\">15</span></span>
                                    <span class=\"tick\" style=\"left: 79.67%;\">|<br/><span class=\"marker\">20</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">25</span></span>
                                </div>
  </div></div>
                                     <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"mortrate\" class=\"orange\"><strong class=\"orange\"> Mortgage Rate (%)</strong> </label>
                                    <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"rate-error errorc\" style=\"color: #993A00;\"></label>
                                    <input id=\"mortrate\" name=\"mortrate\" value=\"\" type=\"text\" />
                                     <span class=\"prc-addon\">%</span>
                                
                                <div id=\"mortrateslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                                </div></div>
                                </div>   </div>
                            </div>
                    </form>
                </div>
            </div>
  
        <div class=\"left-details \" >
           <div class=\"box resultam\">
                <strong class=\"orange\">Down Payment</strong>
                <input id=\"down-payment\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
            </div>
            <div class=\"box resultam\">
                <strong class=\"orange\">CHMC / GE / CG</strong>
                <input id=\"chmc-ins\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/> 
            </div>
            <div class=\"box resultam\">
                <strong class=\"orange\">Required Mortgage</strong>
                <input id=\"mort-reqd\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
            </div>
            <div class=\"box-full ratech\">
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"monthly\" type=\"radio\" checked=\"checked\" /><br/><span style=\"color: rgb(35, 98, 2);\">Monthly</span>
                </div>
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"semi_monthly\" type=\"radio\"/><br/><span style=\"color: rgb(35, 98, 2);\">Semi Monthly</span>
                </div>
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"bi_weekly\" type=\"radio\"/><br/><span style=\"color: rgb(35, 98, 2);\">Bi Weekly</span> 
                </div>
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"weekly\" type=\"radio\"/><br/><span style=\"color: rgb(35, 98, 2);\">Weekly</span>
                </div> 
            </div>
            <div class=\"box-full resultbarhead\">
                <strong style=\"color:rgb(127, 0, 135);\"><i class=\"fa fa-arrow-circle-down\" aria-hidden=\"true\"></i> Mortgage Payment <i class=\"fa fa-arrow-circle-down\" aria-hidden=\"true\"></i></strong>
                <span class=\"emi-data result\" style=\"font-size: 22px;\"></span> 
            </div>
            <div class=\"sch\"> <h2 align=\"center\"><u>Amortization schedule</u></h2>
            <div id=\"container\" style=\"float: left;
position: relative;
width: 100%;
text-align: center;
padding: 5px;height: 200px;\"></div>
           
            <div id=\"emipaymenttable\" style=\"float: left;
position: relative;
width: 100%;
text-align: center;
padding: 11px 5px 5px;\"></div>  
            </div>
        </div>
    <script type=\"text/javascript\" src=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 147
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery_ss.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/superfish.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 152
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 153
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 154
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/emical_ratetrade.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 155
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 157
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.datepicker.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 158
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/highcharts.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 159
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/exporting.js"), "html", null, true);
        echo "\"></script>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:mortgage-payment-ratetrade.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 105,  167 => 103,  137 => 94,  129 => 92,  23 => 3,  223 => 134,  215 => 132,  211 => 131,  207 => 130,  202 => 128,  197 => 148,  185 => 123,  181 => 122,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 32,  84 => 29,  53 => 10,  127 => 28,  97 => 41,  76 => 17,  58 => 17,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 154,  219 => 133,  217 => 153,  208 => 165,  204 => 164,  179 => 69,  159 => 101,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 14,  201 => 149,  196 => 90,  183 => 82,  171 => 104,  166 => 71,  163 => 102,  158 => 79,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 18,  91 => 38,  62 => 24,  49 => 9,  87 => 25,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 6,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 11,  19 => 1,  93 => 28,  88 => 31,  78 => 28,  46 => 8,  44 => 12,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 6,  37 => 5,  22 => 2,  246 => 90,  157 => 56,  145 => 96,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 43,  111 => 37,  108 => 19,  101 => 43,  98 => 31,  96 => 31,  83 => 25,  74 => 27,  66 => 25,  55 => 15,  52 => 14,  50 => 10,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 151,  203 => 78,  199 => 67,  193 => 147,  189 => 146,  187 => 84,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 99,  149 => 97,  147 => 58,  144 => 49,  141 => 95,  133 => 93,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 45,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 10,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 10,  36 => 5,  33 => 4,  30 => 3,);
    }
}
