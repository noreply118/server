<?php

/* MainRatetradeBundle:Default:footer.html.twig */
class __TwigTemplate_714e0de8b234fe0c8437d15af0a885892ee0d4e9f46147af0b8b6f59e47f08f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<footer class=\"footer\">
        <div class=\"footer-widgets\">
            <div class=\"container\">
                <div class=\"row\">

                    <div class=\"col-md-3\">
                        <div class=\"widget\">
                            <h4 class=\"widget-title\">About Us</h4>
                            <p>We share knowledge, information, expert advice and easy to use mortgage comparison tools to find you the ideal mortgage rate. </p>
                            <ul class=\"social-icons\">
                                <li><a href=\"https://www.facebook.com/ratetrade/\" class=\"facebook\" target=\"_blank\"><i class=\"fa fa-facebook\"></i></a></li>
                                <li><a href=\"https://twitter.com/ratetrade/\" class=\"twitter\"  target=\"_blank\"><i class=\"fa fa-twitter\"></i></a></li>
                                <li><a href=\"#\" class=\"instagram\"><i class=\"fa fa-instagram\"  target=\"_blank\"></i></a></li>
                                <li><a href=\"https://in.pinterest.com/ratetrade/\" class=\"pinterest\"  target=\"_blank\"><i class=\"fa fa-pinterest\"></i></a></li>
                            </ul>
                        </div>
                    </div>
                   
                    <div class=\"col-md-3\">
                        <div class=\"widget widget-categories\">
                            <h4 class=\"widget-title\">Resources</h4>
                            <ul>
                               
                                <li><a href=\"https://www.ratetrade.ca/buying-home-canada\">Buying Home in Canada</a></li>
                                <li><a href=\"https://www.ratetrade.ca/renewing-guide\">Renewing Your Mortgage</a></li>
                                <li><a href=\"https://www.ratetrade.ca/mortgage-refinancing-guide\">Mortgage Refinancing Guide</a></li>
                                <li><a href=\"https://www.ratetrade.ca/mortgage-information-center\">Mortgage Information Center</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class=\"col-md-3\">
                        <div class=\"widget widget-categories\">
                            <h4 class=\"widget-title\">Community</h4>
                            <ul>
                                <li><a href=\"https://www.ratetrade.ca/mortgage-broker-signup\">Affiliated Partners</a></li>
                                <li><a href=\"https://www.ratetrade.ca/mortgage-broker-login\">Affiliate Login</a></li>
                                <li><a href=\"https://www.ratetrade.ca/blog\">Blog</a></li>
                                <li><a href=\"https://www.ratetrade.ca/contact-us\">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
 <div class=\"col-md-3\">
                        <div class=\"widget\">
                            <h4 class=\"widget-title\">News Letter</h4>
                            <p>Sign up to subscribe to our newsletter, receive alerts when rates change or schedule a reminder</p>
                            <form action=\"#\">
                                <div class=\"form-group\">
                                    <input class=\"form-control\" type=\"text\" placeholder=\"Enter Your Mail\"/>
                                </div>
                                <div class=\"form-group\">
                                    <button class=\"btn btn-theme btn-theme-transparent\">Subscribe</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"footer-meta\">
            <div class=\"container\">
                <div class=\"row\">

                    <div class=\"col-sm-12\">
                        <p class=\"btn-row text-center\">
                            <a href=\"https://www.facebook.com/ratetrade/\" class=\"btn btn-theme btn-icon-left facebook\" target=\"_blank\"><i class=\"fa fa-facebook\"></i>FACEBOOK</a>
                            <a href=\"https://twitter.com/ratetrade\" class=\"btn btn-theme btn-icon-left twitter\" target=\"_blank\"><i class=\"fa fa-twitter\"></i>TWITTER</a>
    <a href=\"https://instagram.com/ratetrade\" class=\"btn btn-theme btn-icon-left ripple-effect instagram wow fadeInDown\" data-wow-offset=\"20\" data-wow-delay=\"200ms\" target=\"_blank\"><i class=\"fa fa-instagram\"  target=\"_blank\"></i>INSTAGRAM</a>
                            <a href=\"https://in.pinterest.com/ratetrade/\" class=\"btn btn-theme btn-icon-left pinterest\" target=\"_blank\"><i class=\"fa fa-pinterest\"></i>PINTEREST</a>
                            <a href=\"https://plus.google.com/112981913805680468055\" class=\"btn btn-theme btn-icon-left google\"><i class=\"fa fa-google\" target=\"_blank\"></i>GOOGLE</a>
<a href=\"https://www.linkedin.com/company/ratetrade\" class=\"btn btn-theme btn-icon-left ripple-effect linkedin wow fadeInDown\" data-wow-offset=\"20\" data-wow-delay=\"400ms\" target=\"_blank\"><i class=\"fa fa-linkedin\"></i>LINKEDIN</a>
                        </p>
                        <div class=\"copyright\">© 2021 Ratetrade.ca | All right reserved</div>
                       </div>

                </div>
            </div>
        </div>
    </footer>
    <!-- /FOOTER -->

    <div id=\"to-top\" class=\"to-top\"><i class=\"fa fa-angle-up\"></i></div>

</div>
<!-- /WRAPPER -->
<!-- JS Global -->
<script src=\"https://code.jquery.com/jquery-3.5.1.min.js\"></script>
<script src=\"https://code.jquery.com/ui/1.11.4/jquery-ui.js\"></script>
<script src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/jquery/jquery-1.11.1.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/js/bootstrap.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/js/bootstrap-select.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/superfish/js/superfish.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/js/jquery.prettyPhoto.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/owl.carousel.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/jquery.sticky.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 96
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/jquery.easing.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/jquery.smoothscroll.min.js"), "html", null, true);
        echo "\" defer></script>
<!--<script src=\"";
        // line 98
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/smooth-scrollbar.min.js"), "html", null, true);
        echo "\"></script>-->
<!--<script src=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/wow/wow.min.js"), "html", null, true);
        echo "\"></script>-->
<script>
    // WOW - animated content
    //new WOW().init();
</script>
<script src=\"";
        // line 104
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/js/swiper.jquery.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/datetimepicker/js/moment-with-locales.min.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 106
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/datetimepicker/js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\" defer></script>

<!-- JS Page Level -->
<script src=\"";
        // line 109
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/js/theme-ajax-mail.js"), "html", null, true);
        echo "\" defer></script>
<script src=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/js/theme.js"), "html", null, true);
        echo "\" defer></script>


<!--[if (gte IE 9)|!(IE)]><!-->
<script src=\"";
        // line 114
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/jquery.cookie.js"), "html", null, true);
        echo "\" defer></script>
<!--<![endif]-->";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  277 => 125,  521 => 255,  513 => 253,  508 => 251,  499 => 248,  495 => 247,  489 => 244,  472 => 229,  396 => 202,  392 => 201,  377 => 192,  356 => 186,  352 => 185,  348 => 184,  192 => 37,  883 => 685,  699 => 504,  449 => 259,  432 => 255,  428 => 254,  414 => 247,  406 => 245,  403 => 244,  399 => 203,  390 => 236,  376 => 233,  373 => 191,  369 => 190,  265 => 159,  261 => 157,  253 => 154,  898 => 592,  825 => 522,  725 => 431,  721 => 430,  717 => 429,  713 => 428,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 385,  635 => 384,  631 => 383,  570 => 327,  564 => 326,  556 => 324,  549 => 322,  541 => 316,  535 => 315,  527 => 313,  524 => 312,  520 => 311,  505 => 303,  497 => 301,  494 => 300,  479 => 291,  475 => 290,  467 => 288,  458 => 226,  454 => 284,  450 => 283,  446 => 282,  184 => 35,  180 => 34,  172 => 32,  160 => 29,  152 => 27,  937 => 621,  809 => 496,  759 => 448,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 395,  670 => 394,  666 => 393,  629 => 358,  623 => 357,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 293,  530 => 292,  522 => 290,  519 => 289,  515 => 288,  507 => 282,  501 => 281,  493 => 279,  490 => 299,  486 => 277,  477 => 270,  471 => 289,  463 => 287,  460 => 266,  456 => 265,  445 => 257,  441 => 256,  433 => 254,  429 => 215,  424 => 251,  420 => 248,  416 => 249,  412 => 248,  385 => 224,  382 => 277,  118 => 50,  597 => 325,  593 => 324,  589 => 323,  585 => 340,  581 => 321,  576 => 319,  572 => 318,  568 => 317,  561 => 313,  546 => 300,  540 => 299,  532 => 297,  529 => 257,  525 => 256,  517 => 254,  511 => 304,  503 => 249,  500 => 285,  496 => 284,  487 => 277,  481 => 276,  473 => 274,  470 => 273,  466 => 228,  455 => 225,  451 => 224,  447 => 262,  443 => 218,  439 => 260,  434 => 258,  426 => 214,  422 => 213,  400 => 236,  395 => 234,  114 => 19,  260 => 189,  256 => 188,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 181,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 155,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 35,  150 => 28,  146 => 27,  134 => 24,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 36,  301 => 305,  293 => 299,  113 => 90,  174 => 34,  170 => 33,  148 => 26,  77 => 30,  231 => 183,  165 => 106,  161 => 105,  153 => 92,  195 => 113,  191 => 111,  34 => 8,  155 => 27,  310 => 239,  306 => 238,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 230,  270 => 194,  251 => 188,  237 => 140,  233 => 138,  225 => 135,  213 => 152,  205 => 116,  175 => 110,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 153,  215 => 151,  211 => 124,  207 => 149,  202 => 118,  197 => 114,  185 => 109,  181 => 101,  70 => 26,  358 => 223,  354 => 222,  350 => 221,  346 => 220,  342 => 219,  338 => 218,  334 => 217,  330 => 216,  326 => 165,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 42,  110 => 22,  90 => 52,  84 => 25,  53 => 11,  127 => 20,  97 => 62,  76 => 23,  58 => 11,  480 => 162,  474 => 161,  469 => 277,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 217,  435 => 256,  430 => 257,  427 => 143,  423 => 142,  413 => 206,  409 => 132,  407 => 205,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 235,  381 => 193,  379 => 314,  374 => 116,  368 => 112,  365 => 189,  362 => 288,  360 => 187,  355 => 308,  341 => 105,  337 => 103,  322 => 214,  314 => 240,  312 => 98,  309 => 207,  305 => 306,  298 => 236,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 193,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 136,  224 => 178,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 24,  135 => 77,  119 => 42,  102 => 37,  71 => 12,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 34,  171 => 109,  166 => 32,  163 => 29,  158 => 30,  156 => 28,  151 => 26,  142 => 26,  138 => 25,  136 => 87,  121 => 92,  117 => 91,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 41,  89 => 20,  85 => 14,  75 => 28,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 26,  78 => 28,  46 => 8,  44 => 15,  27 => 7,  79 => 29,  72 => 13,  69 => 28,  47 => 12,  40 => 8,  37 => 5,  22 => 2,  246 => 188,  157 => 104,  145 => 98,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 18,  98 => 15,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 20,  52 => 17,  50 => 21,  43 => 11,  41 => 10,  35 => 15,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 38,  189 => 103,  187 => 38,  182 => 114,  176 => 33,  173 => 65,  168 => 31,  164 => 30,  162 => 31,  154 => 29,  149 => 99,  147 => 25,  144 => 25,  141 => 97,  133 => 95,  130 => 23,  125 => 93,  122 => 48,  116 => 70,  112 => 69,  109 => 89,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 27,  86 => 51,  82 => 50,  80 => 24,  73 => 29,  64 => 20,  60 => 19,  57 => 93,  54 => 92,  51 => 14,  48 => 16,  45 => 10,  42 => 22,  39 => 10,  36 => 13,  33 => 4,  30 => 10,);
    }
}
