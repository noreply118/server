<?php

/* MainRatetradeBundle:Default:broker-data.html.twig */
class __TwigTemplate_786b036bde4e62d475b2a52f28dec27ce17dd53678defc23927bcb154a2c035c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <meta name=\"geo.region\" content=\"CA\" />
        <title>Broker Details</title>
        <link rel=\"shortcut icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"icon\" href=\"/symfonyratetrade/web/favicon.ico\" type=\"image/x-icon\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/css/custom-styles.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        
    <body>
        <header>
            <div class=\"top-area\" style=\"text-align: right;\">
                <a href=\"#\">
                    ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "email"), "html", null, true);
        echo "
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("broker_logout");
        echo "\">
                    Logout
                </a>
                &nbsp;&nbsp;&nbsp;&nbsp;
            </div>
          <nav class=\"navbar navbar-default\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <div class=\"logo mobi-menu\">
                            <a href=\"";
        // line 38
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                <img src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                            </a>
                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <!-- Desktop / tab -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <div class=\"col-xs-12 col-sm-12 col-md-4 col-lg-4\">
                            <div class=\"logo\">
                                <a href=\"";
        // line 49
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">
                                    <img src=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\" alt=\"\">
                                </a>
                            </div>
                        </div>
                        <div class=\"col-xs-12 col-sm-12 col-md-8 col-lg-8 text-center\">
                            <ul class=\"nav navbar-nav navbar-right\">
                                <li class=\"dropdown\">
                                    <a href=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("broker_dashboard", array("username" => (isset($context["username"]) ? $context["username"] : $this->getContext($context, "username")))), "html", null, true);
        echo "\" class=\"visible-lg visible-md hidden\">
                                        <i class=\"fa fa-user\" aria-hidden=\"true\"></i> Account 
                                        <i class=\"fa fa-caret-down hidden\"></i>
                                    </a>
                                </li>
                                    <li class=\"dropdown\">
                                    <a href=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("broker_rates", array("username" => (isset($context["username"]) ? $context["username"] : $this->getContext($context, "username")))), "html", null, true);
        echo "\" class=\"visible-lg visible-md hidden\">
                                      <i class=\"fa fa-percent\" aria-hidden=\"true\"></i> Manage Rates 
                                        <i class=\"fa fa-caret-down hidden\"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
        <section>
            <div class=\"middle-content-contact\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-xs-12 col-sm-5 col-md-3\">
                        <div class=\"manager\">
                        <p>If you  want add/edit your rates. Please click below link</p>
                        <i class=\"fa fa-angle-double-down\" aria-hidden=\"true\"></i>
                        <a href=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("broker_rates", array("username" => (isset($context["username"]) ? $context["username"] : $this->getContext($context, "username")))), "html", null, true);
        echo "\">Manange Rates</a>
                        </div>
                         <div class=\"manager\">
                        <p>If you  want check your details. Please click below link</p>
                        <i class=\"fa fa-angle-double-down\" aria-hidden=\"true\"></i>
                        <a href=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("broker_dashboard", array("username" => (isset($context["username"]) ? $context["username"] : $this->getContext($context, "username")))), "html", null, true);
        echo "\">Account</a>
                        </div>
                       </div>  
                       <div class=\"col-xs-12 col-sm-7 col-md-9\">
                            <div class=\"col-xs-12\">
                                <h1 class=\"title-style1\">Broker Details</h1>
                            </div>
                            <form class=\"form-class\">
                                <input type=\"hidden\" id=\"broker-id\" value=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "id"), "html", null, true);
        echo "\" />
                                <div class=\"form-group\">
                                    <label for=\"fname\">First Name: </label>
                                    <input type=\"text\" class=\"form-control required\" name=\"fistName\" id=\"fname\" value=\"";
        // line 98
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "fname"), "html", null, true);
        echo "\" placeholder=\"First Name\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"lname\">Last Name: </label>
                                    <input type=\"text\" class=\"form-control required\" name=\"lastName\" value=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "lname"), "html", null, true);
        echo "\" id=\"lname\" placeholder=\"Last Name\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"email\">Email address:</label>
                                    <input type=\"email\" class=\"form-control required\" id=\"email\" value=\"";
        // line 106
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "email"), "html", null, true);
        echo "\" placeholder=\"Email Address\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"phone\">Phone Number:</label>
                                    <input type=\"tel\" class=\"form-control required\" id=\"phone\" value=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "phone"), "html", null, true);
        echo "\" placeholder=\"Phone Number\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"city\">City:</label>
                                    <input type=\"text\" class=\"form-control required\" id=\"city\" value=\"";
        // line 114
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "city"), "html", null, true);
        echo "\" placeholder=\"City\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"brokerage_name\">Brokerage Name:</label>
                                    <input type=\"text\" class=\"form-control required\" id=\"brokerage_name\" value=\"";
        // line 118
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "brokerageName"), "html", null, true);
        echo "\" placeholder=\"Brokerage Name\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"weburl\">Website Url:</label>
                                    <input type=\"text\" class=\"form-control required\" id=\"weburl\" value=\"";
        // line 122
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "websiteUrl"), "html", null, true);
        echo "\" placeholder=\"Website URL\">
                                </div>
                                <div class=\"form-group\">
                                    <label for=\"message\">About Broker:</label>
                                    <textarea name=\"message\" id=\"message\" placeholder=\"Enter Your Message\" class=\"form-control required\">";
        // line 126
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["broker"]) ? $context["broker"] : $this->getContext($context, "broker")), "about"), "html", null, true);
        echo "</textarea>
                                </div>
                                <button type=\"button\" class=\"btn btn-default\" id=\"submit\">Update</button>
                            </form>
                        </div>
                    </div>  
                </div>
            </div>
        </section>
        ";
        // line 135
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 137
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/bootstrap.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/menu-js.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script>
            function validateEmail(email) {
                var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                return re.test(email);
            }

            \$(document).on(\"click\", \".subsc\", function(e) {
                e.preventDefault();
                \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                if (\$(\"#exampleInputEmail2\") == '')
                {
                    \$(\"#exampleInputEmail2\").focus();
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                {
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                    \$(\"#exampleInputEmail2\").focus();
                }
                else {
                    \$.ajax({
                        url: '";
        // line 161
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                        type: \"post\",
                        async: true,
                        data: {'email': \$(\"#exampleInputName2\").val(),
                            'name': \"testname\"},
                        success: function(response) {
                            \$(\"#exampleInputEmail2\").val('');
                            alert(response);
                        },
                        error: function(request, error) {
                            // alert('No data found');
                        }
                    });
                }
            });


            \$(document).on(\"change\", \".required\", function() {
                \$(this).css('border', '1px solid green');

                if (\$(this).val() == '')
                {
                    \$(this).focus();
                    \$(this).css('border', '1px solid red');
                }

                var id = \$(this).attr('id');
                if (id == 'email' && !validateEmail(\$(\"#email\").val()))
                {
                    \$(\"#email\").focus();
                    \$(\"#email\").css('border', '1px solid red');
                }
            });

            \$(document).on(\"click\", \"#submit\", function(e) {

                if (\$(\"#fname\").val() == '')
                {
                    \$(\"#fname\").focus();
                    \$(\"#fname\").css('border', '1px solid red');
                }
                else if (\$(\"#lname\").val() == '')
                {
                    \$(\"#lname\").focus();
                    \$(\"#lname\").css('border', '1px solid red');
                }
                else if (\$(\"#email\").val() == '')
                {
                    \$(\"#email\").focus();
                    \$(\"#email\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#email\").val()))
                {
                    \$(\"#email\").css('border', '1px solid red');
                    \$(\"#email\").focus();
                }
                else if (\$(\"#phone\").val() == '')
                {
                    \$(\"#phone\").focus();
                    \$(\"#phone\").css('border', '1px solid red');
                }
                else {
                    var currentRequest = null;
                    \$(\"#submit\").text(\"Please Wait..\");
                    var formData = {
                        id: \$(\"#broker-id\").val(),
                        fname: \$(\"#fname\").val(),
                        lname: \$(\"#lname\").val(),
                        email: \$(\"#email\").val(),
                        phone: \$(\"#phone\").val(),
                        city: \$(\"#city\").val(),
                        brokerage_name: \$(\"#brokerage_name\").val(),
                        weburl: \$(\"#weburl\").val(),
                        message: \$(\"#message\").val()
                    };
                    currentRequest = \$.ajax({
                        type: \"post\",
                        async: true,
                        url: \"";
        // line 239
        echo $this->env->getExtension('routing')->getPath("broker_login_update");
        echo "\",
                        data: formData,
                        beforeSend: function() {
                            if (currentRequest != null) {
                                currentRequest.abort();
                            }
                        },
                        success: function(response) {
                            \$(\"#submit\").text(\"Submit\");
                            \$(\"#success\").text(\"Data Captured Successfully\");
                            \$(\".required\").removeAttr('style');
                        },
                        error: function(request, error) {
                            \$(\"#success\").text(\"Failed! Try Again\");
                            \$(\"#success\").css('color', 'red');
                            \$(\"#submit\").text(\"Submit\");
                        }
                    });
                }
            });
        </script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:broker-data.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  277 => 125,  521 => 255,  513 => 253,  508 => 251,  499 => 248,  495 => 247,  489 => 244,  472 => 229,  396 => 202,  392 => 201,  377 => 192,  356 => 186,  352 => 185,  348 => 184,  192 => 118,  883 => 685,  699 => 504,  449 => 259,  432 => 255,  428 => 254,  414 => 247,  406 => 245,  403 => 244,  399 => 203,  390 => 236,  376 => 233,  373 => 191,  369 => 190,  265 => 159,  261 => 157,  253 => 161,  898 => 592,  825 => 522,  725 => 431,  721 => 430,  717 => 429,  713 => 428,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 385,  635 => 384,  631 => 383,  570 => 327,  564 => 326,  556 => 324,  549 => 322,  541 => 316,  535 => 315,  527 => 313,  524 => 312,  520 => 311,  505 => 303,  497 => 301,  494 => 300,  479 => 291,  475 => 290,  467 => 288,  458 => 226,  454 => 284,  450 => 283,  446 => 282,  184 => 35,  180 => 34,  172 => 32,  160 => 29,  152 => 27,  937 => 621,  809 => 496,  759 => 448,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 395,  670 => 394,  666 => 393,  629 => 358,  623 => 357,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 293,  530 => 292,  522 => 290,  519 => 289,  515 => 288,  507 => 282,  501 => 281,  493 => 279,  490 => 299,  486 => 277,  477 => 270,  471 => 289,  463 => 287,  460 => 266,  456 => 265,  445 => 257,  441 => 256,  433 => 254,  429 => 215,  424 => 251,  420 => 248,  416 => 249,  412 => 248,  385 => 224,  382 => 277,  118 => 50,  597 => 325,  593 => 324,  589 => 323,  585 => 340,  581 => 321,  576 => 319,  572 => 318,  568 => 317,  561 => 313,  546 => 300,  540 => 299,  532 => 297,  529 => 257,  525 => 256,  517 => 254,  511 => 304,  503 => 249,  500 => 285,  496 => 284,  487 => 277,  481 => 276,  473 => 274,  470 => 273,  466 => 228,  455 => 225,  451 => 224,  447 => 262,  443 => 218,  439 => 260,  434 => 258,  426 => 214,  422 => 213,  400 => 236,  395 => 234,  114 => 19,  260 => 189,  256 => 188,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 135,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 155,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 110,  150 => 28,  146 => 27,  134 => 24,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 36,  301 => 305,  293 => 299,  113 => 90,  174 => 34,  170 => 33,  148 => 26,  77 => 30,  231 => 183,  165 => 106,  161 => 105,  153 => 92,  195 => 113,  191 => 111,  34 => 8,  155 => 27,  310 => 239,  306 => 238,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 230,  270 => 194,  251 => 188,  237 => 140,  233 => 138,  225 => 135,  213 => 152,  205 => 116,  175 => 110,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 137,  215 => 151,  211 => 124,  207 => 149,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 38,  358 => 223,  354 => 222,  350 => 221,  346 => 220,  342 => 219,  338 => 218,  334 => 239,  330 => 216,  326 => 165,  318 => 277,  206 => 126,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 42,  110 => 63,  90 => 52,  84 => 25,  53 => 11,  127 => 20,  97 => 62,  76 => 23,  58 => 11,  480 => 162,  474 => 161,  469 => 277,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 217,  435 => 256,  430 => 257,  427 => 143,  423 => 142,  413 => 206,  409 => 132,  407 => 205,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 235,  381 => 193,  379 => 314,  374 => 116,  368 => 112,  365 => 189,  362 => 288,  360 => 187,  355 => 308,  341 => 105,  337 => 103,  322 => 214,  314 => 240,  312 => 98,  309 => 207,  305 => 306,  298 => 236,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 87,  132 => 82,  128 => 85,  107 => 60,  61 => 12,  273 => 193,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 138,  224 => 178,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 24,  135 => 77,  119 => 42,  102 => 37,  71 => 12,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 34,  171 => 106,  166 => 32,  163 => 29,  158 => 30,  156 => 28,  151 => 95,  142 => 26,  138 => 25,  136 => 87,  121 => 92,  117 => 91,  105 => 68,  91 => 50,  62 => 24,  49 => 10,  87 => 49,  28 => 3,  94 => 41,  89 => 20,  85 => 14,  75 => 28,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 45,  88 => 26,  78 => 28,  46 => 8,  44 => 15,  27 => 7,  79 => 29,  72 => 13,  69 => 28,  47 => 12,  40 => 8,  37 => 5,  22 => 2,  246 => 188,  157 => 98,  145 => 98,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 57,  98 => 15,  96 => 37,  83 => 33,  74 => 39,  66 => 25,  55 => 20,  52 => 17,  50 => 21,  43 => 11,  41 => 10,  35 => 12,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 122,  193 => 38,  189 => 103,  187 => 38,  182 => 114,  176 => 33,  173 => 65,  168 => 31,  164 => 102,  162 => 31,  154 => 29,  149 => 99,  147 => 25,  144 => 25,  141 => 97,  133 => 95,  130 => 23,  125 => 93,  122 => 48,  116 => 70,  112 => 69,  109 => 89,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 27,  86 => 51,  82 => 50,  80 => 24,  73 => 29,  64 => 20,  60 => 19,  57 => 93,  54 => 92,  51 => 22,  48 => 16,  45 => 19,  42 => 22,  39 => 10,  36 => 13,  33 => 4,  30 => 10,);
    }
}
