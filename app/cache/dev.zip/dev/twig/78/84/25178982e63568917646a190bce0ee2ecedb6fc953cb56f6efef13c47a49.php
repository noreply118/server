<?php

/* MainRatetradeBundle:Default:city-mortgage-rates.html.twig */
class __TwigTemplate_788425178982e63568917646a190bce0ee2ecedb6fc953cb56f6efef13c47a49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title>";
        // line 4
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageTitle"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\" />
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"";
        // line 10
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageTitle"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\" />
        <meta name=\"description\" content=\"";
        // line 11
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageMetaDesc"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\" /> 
       <meta name=\"keyword\" content=\"";
        // line 12
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageMetaKey"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\" /> 

        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"";
        // line 15
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageTitle"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\">
        <meta name=\"og:description\" content=\"";
        // line 16
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageMetaDesc"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"";
        // line 20
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageMetaDesc"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\">
        <meta name=\"twitter:title\" content=\"";
        // line 21
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageTitle"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" /> 
         <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
         <script language=\"JavaScript\" 
                src=\"https://www.iplocationtools.com/iplocationtools.js?key=7b71786a7773756d6a207270\">
        </script>
     ";
        // line 42
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
    <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">";
        // line 51
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageTitle"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">";
        // line 55
        echo twig_escape_filter($this->env, strtr($this->getAttribute((isset($context["metadata"]) ? $context["metadata"] : $this->getContext($context, "metadata")), "pageTitle"), array("%ratetype%" => twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "%city%" => twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "%term%" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"))), "html", null, true);
        echo "</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->
      

   <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
<p>Get Mortgage Rates ";
        // line 76
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "  ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
        echo ". Compare Current Best and Lowest Interest at RateTrade. With our easy to use platform for comparing fixed rate mortgages in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo ", you will be able to search, compare and choose the fixed mortgage rates with best terms and lowest interest rates in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo ".</p>

                                        <div class=\"best-rate-box\">
                                        <table align=\"left\" cellspacing=\"0\" cellpadding=\"0\" class=\"table-rates fixed\">
                                            <tbody>
                                                <tr>
                                                    <th scope=\"col\">Rate</th>
                                                    <th scope=\"col\" align=\"center\">Term</th>
                                                    <th scope=\"col\" align=\"center\">Type</th>
                                                    <th scope=\"col\" align=\"center\">&nbsp;</th>
                                                </tr>

                                                ";
        // line 88
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rates"]) ? $context["rates"] : $this->getContext($context, "rates")));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 89
            echo "                                                    <tr>
                                                        <td>
                                                            <span class=\"rt-rate\">
                                                                ";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "<sup>%</sup>
                                                            </span>
                                                        </td>  
                                                        <td class=\"terms\">";
            // line 95
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "html", null, true);
            echo "</td>
                                                        <td class=\"type\">";
            // line 96
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"), "html", null, true);
            echo "</td>
                                                        <td><span class=\"get_this-rate\">
                                                                <a rt-popup=\"\" href=\"#\" data-toggle=\"modal\" data-target=\"#agentModal1\" class=\"rate-btn ";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "\">
                                                                    <span class=\"wide\">
                                                                        <button class=\"btn btn-success rh-button\">
                                                                            Apply Now
                                                                        </button>
                                                                    </span>
                                                                </a>
                                                            </span>
                                                            <a rt-popup=\"\" href=\"";
            // line 106
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("compare_rates", array("rate" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "term" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "type" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"))), "html", null, true);
            echo "\">
                                                                Compare
                                                            </a>
                                                        </td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 112
        echo "                                            </tbody>
                                        </table>
                                    </div>
                                    <br/><br/>
                                    ";
        // line 116
        if ((twig_length_filter($this->env, (isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities"))) > 0)) {
            // line 117
            echo "                                        <strong>Find Mortgage Rates By City</strong>


                                        <br/>
                                        <ul class=\"listfrate\">
                                            ";
            // line 122
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities")));
            foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
                // line 123
                echo "                                                <li>
                                                        <a href=\"";
                // line 124
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("city_mortgage_rates", array("target" => $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "urlLink"), "term" => $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "termUrl"), "ratetype" => (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype")))), "html", null, true);
                echo "\">                                                ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "&nbsp;&nbsp;";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["term"]) ? $context["term"] : $this->getContext($context, "term")), "term"), "html", null, true);
                echo "&nbsp;&nbsp;";
                echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["ratetype"]) ? $context["ratetype"] : $this->getContext($context, "ratetype"))), "html", null, true);
                echo "</a>
                                                    </li>
                                                
                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 128
            echo "                                        </ul>
<div class=\"clear\"></div>
                                    ";
        }
        // line 131
        echo "                                </div>
                            </div>
                        </div>
                        <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>

<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-percent\"></i> &nbsp; Fixed Mortgage Rates</a>
                                    <ul class=\"children active\">
                                                  <li><a href=\"https://www.ratetrade.ca/best-";
        // line 147
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/1-year/fixed\">1 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 148
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/2-year/fixed\">2 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 149
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/3-year/fixed\">3 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 150
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/4-year/fixed\">4 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 151
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/5-year/fixed\">5 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 152
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/6-year/fixed\">6 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 153
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/7-year/fixed\">7 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 154
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/8-year/fixed\">8 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 155
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/9-year/fixed\">9 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 156
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/10-year/fixed\">10 Year Fixed Rate</a></li>
                                                    </li>
                                                
                                          
                                             
                                     </ul>
                                </li>
<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-percent\"></i> &nbsp; Variable Mortgage Rates</a>
                                    <ul class=\"children active\">
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 167
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/3-year/variable\">3 Year Variable Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 168
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/5-year/variable\">5 Year Variable Rate</a></li>

</ul></li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children\">
                                                <li><a href=\"";
        // line 175
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 176
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 177
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 178
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                                <li><a href=\"";
        // line 179
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 180
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 181
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 182
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 183
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 184
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                     </ul>
                                </li>
                                <li> 
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                    <ul class=\"children\">
                                        
                                                ";
        // line 192
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 193
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 194
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 196
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 197
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    <ul class=\"children\">
                                       ";
        // line 204
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 205
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 206
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 208
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 209
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    <ul class=\"children\">
                                      ";
        // line 215
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 216
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 217
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 219
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 220
        echo "                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
              
                                 </aside>
                    <!-- /SIDEBAR -->
                </div>
            </div>
        </section>
        ";
        // line 233
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact For Rate <span id=\"rate-r\"></span> %</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 276
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 277
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 278
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 280
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 282
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 283
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\">Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"modal-footer\">

                    </div>
                </div>
            </div>
        </div>
 
        <script>
                                                    \$(document).on(\"click\", \".rate-btn\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#rate-request\").val(\$(this).attr(\"class\").split(\" \")[1]);
                                                        \$(\"#rate-r\").html(\$(this).attr(\"class\").split(\" \")[1]);
                                                    });
                                                    
                                                     \$(document).ready(function () {
                                                      if(ip2location_country_long() === 'Canada')
                                                        {
                                                        \$(\"#agentLocationName\").val(ip2location_city());
                                                        \$(\"#agentLocation\").find(\"option:contains('\" + ip2location_city() + \"')\").prop(\"selected\", true);
                                                        }
                                                        else
                                                        {
                                                        \$(\"#agentLocationName\").val(\"Brampton\");
                                                        \$(\"#agentLocation\").find(\"option:contains('Brampton')\").prop(\"selected\", true);
                                                        }
                                                    });

                                                    \$('.locations').on('click', function() {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function() {
                                                        \$('.level1 ul').toggle(500);

                                                    });
                                                    \$('.level2Btn').on('click', function() {
                                                        \$('.level2 ul').toggle(500);

                                                    });
                                                    \$('.level3Btn').on('click', function() {
                                                        \$('.level3 ul').toggle(500);

                                                    });

                                                    \$('#agentLocationName').click(function(e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function(e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function() {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }



                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"click\", \".subsc\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 397
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function(response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function(request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });

                                                    \$(document).on(\"change\", \".required\", function() {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function(e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 467
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function() {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function(response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                    window.location.href = '/thank-you';
                                                                },
                                                                error: function(request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:city-mortgage-rates.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  776 => 467,  703 => 397,  573 => 280,  557 => 276,  401 => 183,  287 => 131,  1156 => 880,  1083 => 810,  963 => 692,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 611,  830 => 605,  824 => 604,  813 => 601,  800 => 593,  794 => 592,  786 => 590,  783 => 589,  779 => 588,  768 => 580,  764 => 579,  760 => 578,  756 => 577,  752 => 576,  748 => 575,  744 => 574,  740 => 573,  732 => 571,  405 => 184,  333 => 154,  307 => 156,  299 => 152,  257 => 136,  807 => 497,  617 => 312,  611 => 311,  596 => 307,  591 => 306,  491 => 237,  431 => 196,  415 => 196,  291 => 149,  284 => 145,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 283,  582 => 328,  578 => 327,  317 => 150,  565 => 320,  468 => 219,  281 => 177,  465 => 216,  361 => 157,  332 => 173,  328 => 147,  320 => 143,  276 => 141,  272 => 126,  245 => 131,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 278,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 281,  492 => 252,  484 => 201,  410 => 173,  397 => 182,  388 => 221,  380 => 219,  366 => 214,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 249,  442 => 237,  417 => 178,  372 => 159,  336 => 164,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 249,  509 => 245,  482 => 217,  386 => 194,  357 => 212,  353 => 180,  344 => 176,  339 => 151,  335 => 175,  329 => 153,  321 => 151,  610 => 410,  462 => 192,  394 => 222,  370 => 215,  364 => 181,  349 => 170,  340 => 175,  325 => 152,  319 => 194,  304 => 185,  295 => 150,  289 => 176,  280 => 167,  126 => 79,  845 => 613,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 297,  531 => 226,  516 => 319,  476 => 233,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 149,  303 => 154,  292 => 127,  288 => 114,  510 => 280,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 198,  411 => 194,  389 => 180,  378 => 181,  311 => 157,  708 => 550,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 246,  483 => 235,  452 => 241,  448 => 206,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 602,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 32,  277 => 176,  521 => 214,  513 => 271,  508 => 216,  499 => 248,  495 => 247,  489 => 261,  472 => 257,  396 => 234,  392 => 185,  377 => 177,  356 => 179,  352 => 178,  348 => 177,  192 => 112,  883 => 685,  699 => 504,  449 => 250,  432 => 222,  428 => 180,  414 => 177,  406 => 227,  403 => 205,  399 => 204,  390 => 216,  376 => 164,  373 => 176,  369 => 175,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 262,  535 => 296,  527 => 313,  524 => 298,  520 => 248,  505 => 244,  497 => 245,  494 => 231,  479 => 216,  475 => 215,  467 => 209,  458 => 253,  454 => 207,  450 => 205,  446 => 204,  184 => 86,  180 => 106,  172 => 104,  160 => 101,  152 => 57,  937 => 686,  809 => 600,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 334,  603 => 309,  599 => 351,  553 => 323,  536 => 218,  530 => 294,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 219,  486 => 251,  477 => 270,  471 => 247,  463 => 242,  460 => 191,  456 => 228,  445 => 205,  441 => 268,  433 => 203,  429 => 201,  424 => 254,  420 => 193,  416 => 192,  412 => 229,  385 => 179,  382 => 193,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 282,  576 => 319,  572 => 318,  568 => 254,  561 => 277,  546 => 300,  540 => 302,  532 => 284,  529 => 295,  525 => 215,  517 => 272,  511 => 233,  503 => 206,  500 => 205,  496 => 220,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 242,  451 => 224,  447 => 185,  443 => 237,  439 => 260,  434 => 245,  426 => 200,  422 => 232,  400 => 235,  395 => 172,  114 => 19,  260 => 137,  256 => 103,  248 => 114,  266 => 124,  262 => 121,  250 => 116,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 142,  275 => 141,  271 => 140,  267 => 137,  263 => 123,  259 => 122,  255 => 129,  239 => 185,  81 => 53,  65 => 21,  1085 => 1059,  210 => 121,  198 => 103,  194 => 133,  190 => 101,  186 => 103,  178 => 35,  150 => 55,  146 => 27,  134 => 24,  124 => 38,  104 => 33,  391 => 231,  383 => 214,  375 => 313,  371 => 159,  367 => 178,  363 => 177,  359 => 168,  351 => 171,  347 => 219,  188 => 87,  301 => 185,  293 => 149,  113 => 90,  174 => 76,  170 => 33,  148 => 29,  77 => 52,  231 => 110,  165 => 106,  161 => 78,  153 => 92,  195 => 106,  191 => 42,  34 => 8,  155 => 93,  310 => 197,  306 => 196,  302 => 195,  290 => 126,  286 => 146,  282 => 128,  274 => 153,  270 => 194,  251 => 128,  237 => 127,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 98,  167 => 96,  137 => 84,  129 => 94,  23 => 3,  223 => 119,  215 => 110,  211 => 124,  207 => 58,  202 => 118,  197 => 88,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 211,  350 => 210,  346 => 220,  342 => 165,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 199,  206 => 92,  244 => 112,  236 => 133,  232 => 106,  228 => 84,  216 => 96,  212 => 95,  200 => 114,  110 => 36,  90 => 34,  84 => 28,  53 => 15,  127 => 33,  97 => 62,  76 => 26,  58 => 11,  480 => 234,  474 => 198,  469 => 284,  461 => 208,  457 => 241,  453 => 206,  444 => 184,  440 => 246,  437 => 197,  435 => 213,  430 => 257,  427 => 211,  423 => 194,  413 => 226,  409 => 238,  407 => 192,  402 => 130,  398 => 186,  393 => 181,  387 => 215,  384 => 168,  381 => 178,  379 => 230,  374 => 227,  368 => 182,  365 => 189,  362 => 156,  360 => 180,  355 => 167,  341 => 156,  337 => 155,  322 => 200,  314 => 158,  312 => 136,  309 => 148,  305 => 147,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 195,  268 => 139,  264 => 122,  258 => 97,  252 => 117,  247 => 149,  241 => 129,  229 => 109,  220 => 113,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 33,  61 => 20,  273 => 140,  269 => 94,  254 => 135,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 184,  227 => 129,  224 => 126,  221 => 98,  219 => 104,  217 => 125,  208 => 96,  204 => 109,  179 => 99,  159 => 94,  143 => 51,  135 => 61,  119 => 36,  102 => 34,  71 => 24,  67 => 29,  63 => 22,  59 => 27,  201 => 89,  196 => 113,  183 => 100,  171 => 97,  166 => 32,  163 => 95,  158 => 30,  156 => 76,  151 => 92,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 61,  91 => 29,  62 => 27,  49 => 14,  87 => 28,  28 => 8,  94 => 35,  89 => 55,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 56,  88 => 29,  78 => 31,  46 => 23,  44 => 12,  27 => 7,  79 => 26,  72 => 25,  69 => 19,  47 => 24,  40 => 11,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 53,  139 => 65,  131 => 42,  123 => 37,  120 => 37,  115 => 35,  111 => 40,  108 => 34,  101 => 18,  98 => 36,  96 => 31,  83 => 27,  74 => 30,  66 => 43,  55 => 26,  52 => 12,  50 => 15,  43 => 23,  41 => 12,  35 => 8,  32 => 12,  29 => 9,  209 => 117,  203 => 94,  199 => 93,  193 => 90,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 102,  162 => 31,  154 => 29,  149 => 69,  147 => 25,  144 => 67,  141 => 85,  133 => 44,  130 => 23,  125 => 93,  122 => 72,  116 => 36,  112 => 35,  109 => 68,  106 => 41,  103 => 32,  99 => 31,  95 => 30,  92 => 30,  86 => 33,  82 => 32,  80 => 27,  73 => 20,  64 => 32,  60 => 40,  57 => 16,  54 => 16,  51 => 25,  48 => 11,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
