<?php

/* AcmeDemoBundle:Demo:loan-tools.html.twig */
class __TwigTemplate_e58012309f2e4eab26ed371669952d9c90f64cd779edba314bc91a30d3b4e74d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0;\">
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>Dashboard - Loan Tools</title>
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
<script src=\"http://code.jquery.com/jquery-1.8.3.js\"></script>
</head>
<body>
<div class=\"header\">
<div class=\"wrapper\">
<a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("loan_tools");
        echo "\" class=\"home-ico\">
    <img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/home-ico.jpg"), "html", null, true);
        echo "\"></a>
  <span class=\"page-name\">Loan Tools</span>
  </div>
</div>
<div class=\"headerfix\"></div>
<div class=\"wrapper bodywrapper\">
  <div class=\"left-nav\">
                <a href=\"";
        // line 21
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\" class=\"selected\">EMI Calculator</a>
                <a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">CHMC Calculator</a> 
                <a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a>
                <a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a>
                <a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a>
 </div>
  <div class=\"right-details\">
    <div class=\"right-inner\">
      <div class=\"dashboxes\">
      <div class=\"box\"><a href=\"";
        // line 30
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">
              <img src=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/offlinetemplate/images/admin/messages.png"), "html", null, true);
        echo "\">
              <br/>EMI Calculator</a></div>
      <div class=\"box\"><a href=\"";
        // line 33
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">
              <img src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/offlinetemplate/images/admin/my-products.png"), "html", null, true);
        echo "\">
              <br/>CHMC Calculator</a></div>
      <div class=\"box\"><a href=\"";
        // line 36
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">
              <img src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/offlinetemplate/images/admin/analytics.png"), "html", null, true);
        echo "\">
              <br/>Land Transfer Tax</a></div>
      <div class=\"box\"><a href=\"";
        // line 39
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">
              <img src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/offlinetemplate/images/admin/store-details.png"), "html", null, true);
        echo "\">
              <br/>Refinance Equity</a></div>
      <div class=\"box\">
          <a href=\"";
        // line 43
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">
              <img src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/offlinetemplate/images/admin/password.png"), "html", null, true);
        echo "\">
              <br/>Refinance Penalty</a></div>
      <div class=\"box\">
          <a href=\"#\">
              <img src=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/offlinetemplate/images/admin/password.png"), "html", null, true);
        echo "\">
              <br/>Refinance Calculator</a></div>
      </div>
    </div>
    </div>
  </div>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:loan-tools.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 105,  167 => 103,  137 => 94,  129 => 92,  23 => 3,  223 => 134,  215 => 132,  211 => 131,  207 => 130,  202 => 128,  197 => 148,  185 => 123,  181 => 122,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 32,  84 => 29,  53 => 10,  127 => 28,  97 => 41,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 154,  219 => 133,  217 => 153,  208 => 165,  204 => 164,  179 => 69,  159 => 101,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 14,  201 => 149,  196 => 90,  183 => 82,  171 => 104,  166 => 71,  163 => 102,  158 => 79,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 40,  91 => 38,  62 => 24,  49 => 9,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 6,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 11,  19 => 1,  93 => 28,  88 => 31,  78 => 31,  46 => 8,  44 => 12,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 14,  37 => 5,  22 => 2,  246 => 90,  157 => 56,  145 => 96,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 19,  101 => 39,  98 => 31,  96 => 37,  83 => 33,  74 => 30,  66 => 25,  55 => 15,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 151,  203 => 78,  199 => 67,  193 => 147,  189 => 146,  187 => 84,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 99,  149 => 97,  147 => 58,  144 => 49,  141 => 95,  133 => 93,  130 => 41,  125 => 44,  122 => 48,  116 => 41,  112 => 42,  109 => 34,  106 => 45,  103 => 32,  99 => 31,  95 => 28,  92 => 36,  86 => 28,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 13,  36 => 13,  33 => 4,  30 => 3,);
    }
}
