<?php

/* MainRatetradeBundle:Default:mortgage-payment.html.twig */
class __TwigTemplate_e819e80e15a0bebfbd08d23010a74838c4646436e289d8dff2c983f73bcb1eac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title> ";
        // line 4
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"description\" content=\"";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mdescription"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\"> 
        <meta name=\"keyword\" content=\"Mortgage Payment Calculator Canada, Simple Mortgage Calculator, Mortgage Payment Calculator Ontario, Mortgage Calculator, Mortgage Payment Calculator Scotiabank, Mortgage Payment Calculator Ratetrade, Mortgage Calculator Alberta, Simple Mortgage Calculator Canada\" />
        
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"og:description\" content=\"";
        // line 16
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mdescription"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"";
        // line 20
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "mdescription"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"twitter:title\" content=\"";
        // line 21
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id") == "25")) {
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "ptitle"), "html", null, true);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo "\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" /> 
         <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
\t    <script src=\"/./bundles/assets/plugins/modernizr.custom.js\"></script>
\t  <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
     <link rel=\"stylesheet\" type=\"text/css\" href=\"/./bundles/acmedemo/css/emicalculator.css\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"/./bundles/acmedemo/css/jquery-ui.css\">  
<style>
.pbox{
   height:197px!important;
}
</style>

             ";
        // line 47
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
 <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Best Mortgage Payment Calculator in Canada</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li>Calculator</li>
                                <li class=\"active\">Mortgage Payment Calculator</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS --
        <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                   
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes framecontent\">
                
<div class=\"calinfo\">
<p>Rate Trade brings you the most reliable <b>mortgage payment calculator Canada</b>. To buy your dream home, you need to get more than just a feel of the future liability that you are going to face; you must have an exact idea about the monthly payments on a mortgage. Our <b>mortgage calculator</b> not only follows an efficient mortgage payments estimation procedure, it also lets you find out the Total Mortgage Payment, CMHC Insurance as well as Land Transfer Tax, all in one place. And the best thing about all this is that the tools are absolutely free!</p>

<h2><strong>Why Do I Need A Mortgage Calculator?</strong></h2>
<p>It is quite difficult to find your dream home, but the problem does not end once you actually find it. It is important to have an estimate about how much you will have to pay in terms of mortgage payments to actually acquire the house. This is where <b>mortgage calculator </b>comes into the picture.</p>
<p>You can not only find out the monthly payments on a mortgage, but also compare different <a href=\"http://www.ratetrade.ca/bank-mortgage-rates\"><b>mortgage rates in Canada</b></a>. This calculator lets you make sure that repayments on mortgage do not become impossible for you by providing you with the best possible mortgage rates suited for you.</p>
<p>You can also find out the periodic payment required in case you opt for semi-monthly, bi-weekly or weekly payments.</p>
<p><strong>How Do I Use the Mortgage Calculator?</strong></p>
<p>Our website provides a very simple and user-friendly  interface to estimate the <b>monthly  payments on a mortgage</b>. All you need to do is enter few figures, like the  property value, down payment, the required amortization period, the applicable  mortgage rate, and our <b>mortgage  calculator</b> will do the rest. You will be provided with the monthly payment  required along with the entire amortization schedule of your mortgage.</p>
<p>You can also find out the periodic payment required in case  you opt for semi-monthly, bi-weekly or weekly payments. </p>
<h3><strong>What Other Calculators Can I Use?</strong></h3>
<p>Apart from the ordinary mortgage calculator, we also have a range of other useful calculator like <a href=\"http://www.ratetrade.ca/mortgage-affordability\"><b>Mortgage Affordability</b></a><b>, </b><a href=\"http://www.ratetrade.ca/cmhc-insurance-calculator\"><b>Mortgage Insurance</b></a><b>, </b><a href=\"http://www.ratetrade.ca/land-transfer-tax\"><b>Land Transfer Tax</b></a><b>, </b><a href=\"http://www.ratetrade.ca/mortgage-refinance-calculator\"><b>Refinance Calculator</b></a><b>, </b>and <a href=\"http://www.ratetrade.ca/mortgage-refinance-penalty\"><b>Refinance Penalty</b></a>, among several others.</p>
<p>You can have a look at our different <b>Mortgage Calculators</b> to get a better understanding.</p>
</div>             
                          <form>
                         <div class=\"pboxheading\">MORTGAGE PAYMENT CALCULATOR</div>
                            <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"loanamount\" class=\"orange\"><strong> Property Value (\$)</strong> </label>
                                  <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"property-error errorc\" style=\"color: #993A00;\"></label>
                                    <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                                     <span class=\"prc-addon\">\$</span>
                              
                                <div id=\"loanamountslider\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
<span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">\$500,000</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left:  50%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">\$2M</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">\$2.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$3</span></span>



                                 </div> </div>
                           </div>
                           <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"loaninterest\" class=\"orange\"><strong> Down Payment (%)</strong> </label>
                                    <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"down-error errorc\" style=\"color: rgb(153, 58, 0);\"></label>
                                    <input id=\"loaninterest\" name=\"loaninterest\" value=\"\" type=\"text\" form=\"percent\" />
                                      <span class=\"prc-addon\">%</span>
                                                                  
                            <div id=\"loaninterestslider\"></div>
                            <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">10</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">15</span></span>
                                    <span class=\"tick\" style=\"left:  50%;\">|<br/><span class=\"marker\">20</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">25</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">30</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">35</span></span>
                           </div></div>
                                </div>
                                     <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"loanterm\" class=\"orange\"><strong class=\"orange\"> Amortization Period (Yr)</strong> </label>
                                    <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"ammort-error errorc\" style=\"color: #993A00;\"></label>
                                    <input id=\"loanterm\" name=\"loanterm\" value=\"\" type=\"text\" />
                                    <span class=\"prc-addon\">Yr</span>
                                
                                <div id=\"loantermslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 14.28%;\">|<br/><span class=\"marker\">5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 28.56%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left: 42.84%;\">|<br/><span class=\"marker\">15</span></span>
                                    <span class=\"tick\" style=\"left: 57%;\">|<br/><span class=\"marker\">20</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 71.40%;\">|<br/><span class=\"marker\">25</span></span>
                                    <span class=\"tick\" style=\"left: 85.68%;\">|<br/><span class=\"marker\">30</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">35</span></span>
                                </div>
  </div></div>
                                     <div class=\"pbox\">
                                <div class=\"sep lint\">
                                    <label for=\"mortrate\" class=\"orange\"><strong class=\"orange\"> Mortgage Rate (%)</strong> </label>
                                    <span></span></div>
                                    <div class=\"datafeild\">
                                    <label class=\"rate-error errorc\" style=\"color: #993A00;\"></label>
                                    <input id=\"mortrate\" name=\"mortrate\" value=\"\" type=\"text\" />
                                     <span class=\"prc-addon\">%</span>
                                
                                <div id=\"mortrateslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                                </div></div>
                                </div>
                                                </form>
                
           <div class=\"box resultam\">
                <strong class=\"orange\">Down Payment</strong>
                <input id=\"down-payment\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
            </div>
            <div class=\"box resultam\">
                <strong class=\"orange\">CHMC / GE / CG</strong>
                <input id=\"chmc-ins\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/> 
            </div>
            <div class=\"box resultam\">
                <strong class=\"orange\">Required Mortgage</strong>
                <input id=\"mort-reqd\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
            </div>
            <div class=\"box-full ratech\">
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"monthly\" type=\"radio\" checked=\"checked\" /><br/><span style=\"color: rgb(35, 98, 2);\">Monthly</span>
                </div>
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"semi_monthly\" type=\"radio\"/><br/><span style=\"color: rgb(35, 98, 2);\">Semi Monthly</span>
                </div>
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"bi_weekly\" type=\"radio\"/><br/><span style=\"color: rgb(35, 98, 2);\">Bi Weekly</span> 
                </div>
                <div class=\"box-4\">
                    <input class=\"payment-freq\" name=\"installment\" value=\"weekly\" type=\"radio\"/><br/><span style=\"color: rgb(35, 98, 2);\">Weekly</span>
                </div> 
            </div>
            <div class=\"box-full resultbarhead\">
                <strong style=\"color:rgb(7, 40, 49);\"><i class=\"fa fa-arrow-circle-down\" aria-hidden=\"true\"></i> Mortgage Payment <i class=\"fa fa-arrow-circle-down\" aria-hidden=\"true\"></i></strong>
                <span class=\"emi-data result\" style=\"font-size: 22px;\"></span> 
            </div>
            <div class=\"sch\"> <h2 align=\"center\"><u>Amortization schedule</u></h2>
            <div id=\"container\" style=\"float: left;
position: relative;
width: 100%;
text-align: center;
padding: 5px;height: 200px;\"></div>
           
            <div id=\"emipaymenttable\" style=\"float: left;
position: relative;
width: 100%;
text-align: center;
padding: 11px 5px 5px;\"></div>  
            </div>

<div class=\"calinfo\">
<p><strong>Should I Renew My Mortgage or Should I Go for Refinance?</strong></p>
<p>This is a  big decision that every home buyer has to make several times during the  mortgage period. In Canada, a  mortgage is typically arranged to be paid off in monthly installments so that  the entire amount of mortgage can be fully paid off within any time between 25  and 30 years or by the choice of individual taking mortgage.However, you cannot  take loan extending to that many years. Because of this, you have to face the  question of whether to go for <b>renewal or  refinance </b>of the mortgage loan.</p>
<p>To simplify the concept, suppose you have taken a \$200,000  mortgage on your house, which has to be paid off in 30 years based on the  amortization schedule. However, it may be so that the term of the mortgage is a  mere 5 years, at the end of which the lender has the  right to demand full payment in case mortgage is not renewed. Then you will  have the option of either renewing the mortgage or catching hold of another  lender.</p>
<p>For some of us, it may seem that mortgage  renewal appears to be better option, since we do not have to handle the hassles  of looking for a different lender and getting a fresh loan approved.  However, you must make it a point to find out the existing  rates. Why would you continue paying at higher rates, if the rate of interest  has gone down in the meantime?</p>
<p>Whenever you face the <b>Renewal or Refinance</b> problem, all you  have to do is use our Refinance Calculator. You can also find out the Maximum  Mortgage Refinance Value.</p>
<p><strong>What is Land Transfer Tax?</strong></p>
<p>Land Transfer Tax is a tax which is imposed on the  acquisition or purchase of any residential or commercial property. It is  necessarily a provincial tax which is imposed whenever a property changes  hands. If you are <b>a first time home  buyer</b>, you may be eligible for obtaining a refund. </p>
<p><strong>What is CMHC Insurance?</strong></p>
<p><b>CMHC Insurance</b> is basically a mortgage default  insurance, which is imposed to protect lenders from possible future payment defaults on the part of the borrower. In Canada, it is mandatory for you to pay <b>CMHC Insurance</b> if your down payment  lies anywhere between the minimum rate of 5% and up to 19.99%. </p>
</div>
                     
                                    <div class=\"mortapb\"><a href=\"#\" class=\"an-button\" data-toggle=\"modal\" data-target=\"#agentModal1\">Apply Now</a>
                                        &nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;
                                        <a href=\"";
        // line 241
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "\" class=\"an-button\">Best Available Rates</a>
                                    </div>
\t\t\t\t\t\t\t\t\t<div class=\"clear\"></div>
                                </div>
                            </div></div>
                            </article>
                   




 <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
<a href=\"https://www.ratetrade.ca/home-buying-process\"><img src=\"/bundles/assets/img/side-pic1.jpg\"></a>
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children active\">
                                                <li><a href=\"";
        // line 265
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 266
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 267
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 268
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                              
                                                <li><a href=\"";
        // line 270
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 271
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 272
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 273
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 274
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                     </ul>
                                </li>
                                <li> 
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                    <ul class=\"children\">
                                        
                                                ";
        // line 282
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 283
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 284
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 286
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 287
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    <ul class=\"children\">
                                       ";
        // line 294
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 295
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 296
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 298
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 299
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    <ul class=\"children\">
                                      ";
        // line 305
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 306
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 307
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 309
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 310
        echo "                                    </ul>
                                </li>
  <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Mortgage Information</a>
                                    <ul class=\"children\">
                                      ";
        // line 316
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 317
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "47")) {
                // line 318
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 320
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 321
        echo "                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
                   
                                 </aside>
                    <!-- /SIDEBAR -->





                </div>
            </div>
        </section>
        ";
        // line 339
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "

    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/jquery.ui.widget.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/jquery.ui.accordion.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/jquery.ui.tabs.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/jquery.loadmask.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/globalize.min.js\"></script>
       <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/emical_ratetrade.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/jquery.ui.mouse.min.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/jquery.ui.slider.min.js\"></script>

 
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/highcharts.js\"></script>
    <script type=\"text/javascript\" src=\"/bundles/acmedemo/js/exporting.js\"></script> 
<!-- /WRAPPER -->
   <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact Us</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 396
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 397
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 398
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 400
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 402
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 403
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\" selected>Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    </div></div></div>
 <script>

                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"click\", \".subsc\", function (e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 451
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function (response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function (request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });

                                                    \$('#locationName').click(function (e) {
                                                        \$('.loclist').show(100);
                                                    });
                                                    \$('.loclist').blur(function (e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function getSelected() {

                                                        document.getElementById('locationName').value = document.getElementById('locationList').value;

                                                        \$('#locationList').hide(100);
                                                    }

                                                    \$('#agentLocationName').click(function (e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function (e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function () {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }


                                                    \$('.locations').on('click', function () {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function (e) {
                                                        e.preventDefault();
                                                        \$('.level1 ul').toggle(500);
                                                    });
                                                    \$('.level2Btn').on('click', function (e) {
                                                        e.preventDefault();
                                                        \$('.level2 ul').toggle(500);
                                                    });
                                                    \$('.level3Btn').on('click', function (e) {
                                                        e.preventDefault();
                                                        \$('.level3 ul').toggle(500);
                                                    });

                                                    \$(document).on(\"change\", \".required\", function () {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function (e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 576
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function () {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function (response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                    window.location.href = '/thank-you';
                                                                },
                                                                error: function (request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
       
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:mortgage-payment.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  858 => 576,  730 => 451,  659 => 398,  654 => 397,  590 => 339,  438 => 271,  664 => 312,  658 => 311,  650 => 396,  643 => 307,  588 => 262,  567 => 248,  345 => 151,  1594 => 1360,  1587 => 1356,  1583 => 1355,  1577 => 1352,  1573 => 1351,  1569 => 1350,  1507 => 1291,  1465 => 1252,  1456 => 1246,  1449 => 1242,  1428 => 1224,  1424 => 1223,  1420 => 1222,  1416 => 1221,  1412 => 1220,  1408 => 1219,  1404 => 1218,  1400 => 1217,  1396 => 1216,  1392 => 1215,  1388 => 1214,  860 => 695,  854 => 497,  823 => 665,  817 => 663,  791 => 642,  785 => 641,  773 => 639,  750 => 522,  634 => 305,  595 => 380,  571 => 374,  485 => 305,  297 => 203,  874 => 702,  801 => 513,  692 => 416,  688 => 415,  684 => 414,  679 => 412,  675 => 411,  671 => 410,  612 => 373,  562 => 329,  624 => 376,  545 => 371,  605 => 336,  601 => 381,  575 => 375,  488 => 209,  776 => 467,  703 => 397,  573 => 249,  557 => 276,  401 => 183,  287 => 131,  1156 => 880,  1083 => 810,  963 => 692,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 611,  830 => 605,  824 => 604,  813 => 601,  800 => 593,  794 => 592,  786 => 590,  783 => 589,  779 => 640,  768 => 580,  764 => 579,  760 => 578,  756 => 577,  752 => 576,  748 => 575,  744 => 574,  740 => 573,  732 => 571,  405 => 184,  333 => 146,  307 => 137,  299 => 186,  257 => 104,  807 => 497,  617 => 374,  611 => 311,  596 => 307,  591 => 306,  491 => 294,  431 => 187,  415 => 182,  291 => 173,  284 => 177,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 378,  582 => 396,  578 => 327,  317 => 208,  565 => 320,  468 => 284,  281 => 177,  465 => 283,  361 => 157,  332 => 173,  328 => 147,  320 => 201,  276 => 115,  272 => 124,  245 => 153,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 386,  563 => 230,  559 => 246,  550 => 290,  547 => 231,  542 => 288,  514 => 226,  492 => 252,  484 => 201,  410 => 173,  397 => 246,  388 => 169,  380 => 201,  366 => 236,  331 => 146,  323 => 139,  315 => 141,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 291,  548 => 304,  533 => 300,  528 => 216,  478 => 212,  442 => 272,  417 => 265,  372 => 199,  336 => 164,  924 => 587,  851 => 517,  826 => 532,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 378,  625 => 341,  620 => 323,  616 => 322,  555 => 266,  538 => 237,  534 => 308,  526 => 306,  509 => 245,  482 => 287,  386 => 222,  357 => 158,  353 => 156,  344 => 192,  339 => 227,  335 => 175,  329 => 145,  321 => 151,  610 => 337,  462 => 208,  394 => 224,  370 => 237,  364 => 197,  349 => 200,  340 => 175,  325 => 143,  319 => 194,  304 => 185,  295 => 174,  289 => 176,  280 => 126,  126 => 29,  845 => 613,  772 => 421,  685 => 337,  680 => 403,  676 => 334,  644 => 291,  638 => 306,  630 => 301,  618 => 298,  614 => 297,  539 => 229,  531 => 227,  516 => 319,  476 => 286,  464 => 282,  421 => 266,  343 => 228,  324 => 145,  316 => 184,  313 => 207,  303 => 131,  292 => 128,  288 => 128,  510 => 280,  506 => 298,  502 => 233,  498 => 296,  425 => 267,  419 => 198,  411 => 181,  389 => 180,  378 => 181,  311 => 139,  708 => 550,  619 => 362,  580 => 376,  558 => 306,  552 => 244,  544 => 238,  537 => 301,  523 => 233,  512 => 299,  483 => 208,  452 => 241,  448 => 206,  436 => 225,  408 => 249,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 664,  816 => 602,  812 => 642,  808 => 641,  804 => 640,  780 => 426,  418 => 177,  100 => 32,  277 => 176,  521 => 282,  513 => 280,  508 => 225,  499 => 212,  495 => 295,  489 => 306,  472 => 257,  396 => 234,  392 => 185,  377 => 219,  356 => 154,  352 => 194,  348 => 193,  192 => 112,  883 => 685,  699 => 504,  449 => 273,  432 => 222,  428 => 267,  414 => 250,  406 => 213,  403 => 179,  399 => 178,  390 => 241,  376 => 200,  373 => 238,  369 => 217,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 419,  700 => 418,  696 => 417,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 342,  570 => 321,  564 => 320,  556 => 318,  549 => 316,  541 => 310,  535 => 309,  527 => 307,  524 => 306,  520 => 305,  505 => 297,  497 => 222,  494 => 308,  479 => 302,  475 => 285,  467 => 283,  458 => 207,  454 => 206,  450 => 274,  446 => 273,  184 => 107,  180 => 106,  172 => 35,  160 => 32,  152 => 30,  937 => 686,  809 => 600,  759 => 493,  753 => 462,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 402,  670 => 419,  666 => 400,  629 => 358,  623 => 299,  615 => 355,  608 => 372,  603 => 275,  599 => 351,  553 => 317,  536 => 228,  530 => 235,  522 => 219,  519 => 304,  515 => 261,  507 => 282,  501 => 256,  493 => 221,  490 => 293,  486 => 251,  477 => 270,  471 => 237,  463 => 242,  460 => 281,  456 => 228,  445 => 272,  441 => 271,  433 => 194,  429 => 268,  424 => 266,  420 => 265,  416 => 264,  412 => 214,  385 => 179,  382 => 193,  118 => 27,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 282,  576 => 319,  572 => 318,  568 => 254,  561 => 277,  546 => 289,  540 => 309,  532 => 284,  529 => 284,  525 => 331,  517 => 281,  511 => 319,  503 => 206,  500 => 223,  496 => 220,  487 => 251,  481 => 286,  473 => 308,  470 => 210,  466 => 209,  455 => 195,  451 => 224,  447 => 247,  443 => 246,  439 => 270,  434 => 270,  426 => 200,  422 => 232,  400 => 247,  395 => 177,  114 => 26,  260 => 162,  256 => 103,  248 => 114,  266 => 124,  262 => 121,  250 => 116,  242 => 136,  234 => 185,  226 => 87,  222 => 86,  218 => 105,  279 => 142,  275 => 171,  271 => 164,  267 => 163,  263 => 123,  259 => 122,  255 => 129,  239 => 150,  81 => 53,  65 => 21,  1085 => 1059,  210 => 121,  198 => 103,  194 => 123,  190 => 57,  186 => 109,  178 => 35,  150 => 35,  146 => 34,  134 => 31,  124 => 77,  104 => 19,  391 => 176,  383 => 174,  375 => 163,  371 => 159,  367 => 161,  363 => 177,  359 => 168,  351 => 171,  347 => 153,  188 => 42,  301 => 204,  293 => 202,  113 => 90,  174 => 34,  170 => 39,  148 => 29,  77 => 52,  231 => 90,  165 => 37,  161 => 36,  153 => 97,  195 => 106,  191 => 42,  34 => 11,  155 => 30,  310 => 197,  306 => 176,  302 => 195,  290 => 180,  286 => 146,  282 => 166,  274 => 153,  270 => 194,  251 => 128,  237 => 93,  233 => 138,  225 => 127,  213 => 87,  205 => 78,  175 => 35,  167 => 33,  137 => 84,  129 => 82,  23 => 3,  223 => 119,  215 => 135,  211 => 119,  207 => 118,  202 => 118,  197 => 111,  185 => 117,  181 => 38,  70 => 29,  358 => 156,  354 => 231,  350 => 210,  346 => 229,  342 => 150,  338 => 149,  334 => 142,  330 => 163,  326 => 201,  318 => 141,  206 => 92,  244 => 112,  236 => 133,  232 => 131,  228 => 84,  216 => 96,  212 => 95,  200 => 126,  110 => 25,  90 => 34,  84 => 28,  53 => 24,  127 => 26,  97 => 62,  76 => 41,  58 => 11,  480 => 234,  474 => 211,  469 => 284,  461 => 282,  457 => 234,  453 => 206,  444 => 192,  440 => 246,  437 => 270,  435 => 269,  430 => 257,  427 => 211,  423 => 194,  413 => 234,  409 => 238,  407 => 180,  402 => 226,  398 => 211,  393 => 245,  387 => 175,  384 => 168,  381 => 240,  379 => 173,  374 => 227,  368 => 198,  365 => 189,  362 => 156,  360 => 232,  355 => 227,  341 => 156,  337 => 155,  322 => 173,  314 => 140,  312 => 136,  309 => 206,  305 => 205,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 116,  268 => 123,  264 => 122,  258 => 97,  252 => 117,  247 => 149,  241 => 94,  229 => 109,  220 => 113,  214 => 122,  177 => 103,  169 => 101,  140 => 27,  132 => 25,  128 => 85,  107 => 28,  61 => 14,  273 => 185,  269 => 110,  254 => 159,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 144,  227 => 129,  224 => 141,  221 => 98,  219 => 88,  217 => 125,  208 => 96,  204 => 83,  179 => 114,  159 => 31,  143 => 90,  135 => 28,  119 => 31,  102 => 19,  71 => 19,  67 => 29,  63 => 37,  59 => 27,  201 => 115,  196 => 113,  183 => 53,  171 => 44,  166 => 32,  163 => 32,  158 => 37,  156 => 31,  151 => 95,  142 => 33,  138 => 32,  136 => 26,  121 => 92,  117 => 73,  105 => 61,  91 => 59,  62 => 36,  49 => 14,  87 => 16,  28 => 8,  94 => 35,  89 => 51,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 10,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 18,  88 => 56,  78 => 31,  46 => 23,  44 => 11,  27 => 7,  79 => 20,  72 => 40,  69 => 40,  47 => 21,  40 => 8,  37 => 11,  22 => 2,  246 => 96,  157 => 98,  145 => 53,  139 => 89,  131 => 27,  123 => 25,  120 => 37,  115 => 20,  111 => 29,  108 => 67,  101 => 18,  98 => 36,  96 => 31,  83 => 27,  74 => 15,  66 => 43,  55 => 26,  52 => 12,  50 => 15,  43 => 23,  41 => 12,  35 => 12,  32 => 12,  29 => 9,  209 => 132,  203 => 94,  199 => 93,  193 => 47,  189 => 109,  187 => 41,  182 => 108,  176 => 36,  173 => 102,  168 => 34,  164 => 33,  162 => 38,  154 => 36,  149 => 69,  147 => 28,  144 => 28,  141 => 85,  133 => 44,  130 => 30,  125 => 93,  122 => 28,  116 => 21,  112 => 65,  109 => 68,  106 => 41,  103 => 20,  99 => 26,  95 => 60,  92 => 57,  86 => 15,  82 => 17,  80 => 20,  73 => 14,  64 => 12,  60 => 15,  57 => 16,  54 => 14,  51 => 11,  48 => 11,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 8,  30 => 10,);
    }
}
