<?php

/* AcmeDemoBundle:Demo:rate-entry-form.html.twig */
class __TwigTemplate_2aff78376511de5288dffa90f0b0a59fb4a341eae9993133558f6a6abf7dddb2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0;\">
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>Rate Entry Form</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
    </head>
    <body>
        <div class=\"header\">
            <div class=\"wrapper\"> <a href=\"#\" onClick=\"window.history.back();\" class=\"home-ico\">
                    <img src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/back.png"), "html", null, true);
        echo "\"></a> 
                <span class=\"page-name\">Add New Rate</span> </div>
        </div>
        <div class=\"headerfix\"></div>
        <div class=\"wrapper bodywrapper\">
            <div class=\"left-nav\"> <a href=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("rateform");
        echo "\" class=\"selected\">Add Rate</a> <a href=\"";
        echo $this->env->getExtension('routing')->getPath("allrates");
        echo "\">All Rates</a><a href=\"";
        echo $this->env->getExtension('routing')->getPath("logout");
        echo "\">Sign Out</a> </div>
            <div class=\"right-details\">
                <div class=\"right-inner\">
                    <div class=\"inner\">
                        <form class=\"imageform\" id=\"imageform\" method=\"post\" action=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("rateform_update");
        echo "\">
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Province</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"province\" name=\"province\" >
                                    <option value=\"AL\">Alberta</option>
                                    <option value=\"BC\">British Columbia</option>
                                    <option value=\"MA\">Manitoba</option>
                                    <option value=\"NB\">New Brunswick</option>
                                    <option value=\"NE\">Newfoundland</option>
                                    <option value=\"NS\">Nova Scotia</option>
                                    <option value=\"NT\">Northwest Territories</option>
                                    <option value=\"NU\">Nunavut</option>
                                    <option value=\"ON\" selected=\"selected\">Ontario</option>
                                    <option value=\"PE\">Prince Edward Island</option>
                                    <option value=\"QU\">Quebec</option>
                                    <option value=\"SK\">Saskatchewan</option>
                                    <option value=\"YU\">Yukon</option>\t\t\t\t
                                </select>
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>City</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"city\" name=\"city\" >
                                </select>
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Mortgage Rate</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"mort-rate\" name=\"mort-rate\" >
                                    <option value=\"Buying Home\">Buying Home</option>
                                    <option value=\"Renewing\">Renewing</option>
                                    <option value=\"Refinancing\">Refinancing</option>
                                    <option value=\"Home Equity\">Accessing Home Equity</option> 
                                </select>
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Rate Type</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"rate-type\" name=\"rate-type\" >
                                    <option value=\"Fixed\">Fixed</option>
                                    <option value=\"Variable\">Variable</option>
                                    <option value=\"Fixed - Open\">Fixed - Open</option>
                                    <option value=\"Variable - Open\">Variable - Open</option> 
                                    <option value=\"Cash Back\">Cash Back</option> 
                                </select>
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Terms Length</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"terms-length\" name=\"terms-length\" >
                                    <option value=\"1 Year\">1 Year</option>
                                    <option value=\"2 Year\">2 Year</option>
                                    <option value=\"3 Year\">3 Year</option>
                                    <option value=\"4 Year\">4 Year</option>
                                    <option value=\"5 Year\">5 Year</option>
                                    <option value=\"6 Year\">6 Year</option>
                                    <option value=\"7 Year\">7 Year</option>
                                    <option value=\"8 Year\">8 Year</option>
                                    <option value=\"9 Year\">9 Year</option>
                                    <option value=\"10 Year\">10 Year</option>
                                </select>
                            </div>
                            <div style=\"clear:both\"></div>
                             <label>
                                <strong>Enter Rate</strong>
                            </label>
                            <div class=\"fields\">
                                <input type=\"text\" value=\"\" name=\"rate\" id=\"rate\" placeholder=\"Enter Rate\"/>
                            </div>
                            <input id=\"signup-submit\" name=\"signup\" value=\"ADD\" class=\"prodsubmit\" type=\"Submit\">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script type=\"text/javascript\" src=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/rate_entry.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:rate-entry-form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 70,  174 => 98,  170 => 97,  148 => 90,  77 => 39,  231 => 155,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 134,  167 => 127,  137 => 94,  129 => 92,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 128,  197 => 105,  185 => 102,  181 => 101,  70 => 37,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 97,  305 => 95,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 154,  224 => 169,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 142,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 17,  67 => 36,  63 => 19,  59 => 13,  201 => 149,  196 => 90,  183 => 143,  171 => 128,  166 => 96,  163 => 126,  158 => 94,  156 => 66,  151 => 81,  142 => 59,  138 => 54,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 9,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 7,  27 => 7,  79 => 18,  72 => 38,  69 => 25,  47 => 15,  40 => 6,  37 => 5,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 47,  96 => 37,  83 => 33,  74 => 27,  66 => 24,  55 => 20,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 151,  203 => 148,  199 => 147,  193 => 104,  189 => 103,  187 => 144,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 95,  154 => 107,  149 => 97,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 75,  125 => 73,  122 => 48,  116 => 41,  112 => 42,  109 => 69,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 36,  86 => 51,  82 => 42,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 8,  45 => 8,  42 => 7,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
