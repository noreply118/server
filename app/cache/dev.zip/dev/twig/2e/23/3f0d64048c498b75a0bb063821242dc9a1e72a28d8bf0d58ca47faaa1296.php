<?php

/* AcmeDemoBundle:Demo:refinance-calculator-ratetrade.html.twig */
class __TwigTemplate_2e233f0d64048c498b75a0bb063821242dc9a1e72a28d8bf0d58ca47faaa1296 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <title>Debt Consolidation Calculator</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/max-equity-cal.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/emicalculator.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery-ui.css"), "html", null, true);
        echo "\">
    </head>

    <body>   <div class=\"debt-left-details\">
            <form class=\"imageform\">
                <div class=\"entry-content\">
                    <div id=\"emicalcalulatorinnerform\" style=\"padding: 0px 0px 10px;\">
                        <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label for=\"loanamount\" class=\"orange\"><strong>Current Property Value (\$)</strong> </label>
                            <span></span>
                        </div>
                        <div class=\"datafeild\">
                        <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                        <div id=\"loanamountslider\" style=\"margin-top: 45px;\"></div>
                        <div id=\"loanamountsteps\" class=\"steps\">
                            <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                            <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                            <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                            <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                            <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                        </div></div></div>
                        <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label for=\"leftamount\" class=\"orange\"><strong>Remaining Balance on Mortgage (\$)</strong> </label>
                            <span></span>
                            </div>
                            <div class=\"datafeild\">
                            <input id=\"leftamount\" name=\"leftamount\" value=\"\" type=\"text\" />
                        <div id=\"leftamountslider\" style=\"margin-top: 45px;\"></div>
                        <div id=\"leftamountsteps\" class=\"steps\">
                             <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                            <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                            <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                            <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                            <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                      </div></div></div> 
                <div style=\"text-align: center;border:1px solid #ddd; background: #c1c1c1; padding: 10px;\">
                    <strong><u>Available Equity</u></strong>
                    <table style=\"margin-left: 26%;margin-top: 15px;text-align: center;\">
                        <tr>
                            <td><label id=\"mortamount\">0</label></td>
                            <td>X</td>
                            <td><label>80%</label></td>
                            <td>-</td>
                            <td><label id=\"left-amount\">0</label></td>
                            <td>&nbsp;</td>
                            <td>=</td>
                            <td>&nbsp;</td>
                            <td><label id=\"equity\">0</label></td>
                        </tr>
                        <tr>
                            <td style=\"font-size: 15px;padding-top:10px;\">(Property Value)</td>
                            <td>&nbsp;</td>
                            <td style=\"font-size: 15px;padding-top:10px;\">(Loan value ratio)</td>
                            <td>&nbsp;</td>
                            <td style=\"font-size: 15px;padding-top:10px;\">(Current Mortgage)</td>
                            <td>&nbsp;</td>
                            <td>=</td>
                            <td>&nbsp;</td>
                            <td style=\"font-size: 15px;padding-top:10px;\">(Equity Available)</td>
                        </tr>
                    </table>
               </div>
                <div class=\"pbox\">
                <div class=\"lamount\">
                    <label for=\"equityamount\" class=\"orange\" style=\"display: inline-table;\"><strong>How much Equity <br/>want to access? (\$)</strong> </label>
                    <span></span>
                </div>
                <div class=\"datafeild\">
                <input id=\"equityamount\" name=\"equityamount\" value=\"15,000\" type=\"text\" disabled=\"disabled\"/>
                <div id=\"equityamountslider\" style=\"margin-top: 45px;\"></div>
                <div id=\"equityamountsteps\" class=\"steps\">
                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">Max Equity</span></span>
                </div></div></div>
                <div style=\"text-align: center;border:1px solid #ddd; background: #c1c1c1; padding: 10px;\">
                    <strong><u>New Mortgage Amount</u></strong>
                    <table style=\"margin-left: 26%;text-align: center;\">
                        <tr>
                            <td><label id=\"curmort\">0</label></td>
                            <td>+</td>
                            <td><label id=\"add-equity\">0</label></td>
                            <td>&nbsp;</td>
                            <td>=</td>
                            <td>&nbsp;</td>
                            <td><label id=\"new-mort\">0</label></td>
                        </tr>
                        <tr>
                            <td style=\"font-size: 15px;padding-top:10px;\">(Current Mortgage)</td>
                            <td>&nbsp;</td>
                            <td style=\"font-size: 15px;padding-top:10px;\">(Additional Equity)</td>
                            <td>&nbsp;</td>
                            <td>=</td>
                            <td>&nbsp;</td>
                            <td style=\"font-size: 15px;padding-top:10px;\">(New Mortgage)</td>
                        </tr>
                    </table>
                </div>
                <div class=\"refdetail\">
                <h2 style=\"text-align: center;\"> Estimate Penalty </h2>
               <div class=\"pbox\">
                <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>Current Mortgage Payment (\$)</strong>
                </label></div>  <div class=\"datafeild\">
                <div class=\"fields\">
                    <input id=\"cur-mort\" value=\"1,250\" type=\"text\" style=\"width:50%;\"/>
                </div></div></div>
                <div class=\"pbox\">
                    <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>How offen do you make payment?</strong>
                </label></div><div class=\"datafeild\">
                <div class=\"fields\">
                    <select id=\"month\" style=\"width:50%;\">
                        <option value=\"monthly\">Monthly</option>
                        <option value=\"semi_monthly\">Semi Monthly</option>
                        <option value=\"acc_bi_weekly\">Accelerated Bi-Weekly</option>
                        <option value=\"weekly\">Weekly</option>
                    </select>
                </div></div></div>
                 <div class=\"pbox\">
                    <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>Mortgage Start Date</strong>
                </label></div><div class=\"datafeild\">
                <div class=\"fields\">
                    <select id=\"date\" style=\"width:30%;\"><option value=\"1\">1</option><option value=\"2\">2</option><option value=\"3\">3</option><option value=\"4\">4</option><option value=\"5\">5</option><option value=\"6\">6</option><option value=\"7\">7</option><option value=\"8\">8</option><option value=\"9\">9</option><option value=\"10\">10</option><option value=\"11\">11</option><option value=\"12\">12</option><option value=\"13\">13</option><option value=\"14\">14</option><option value=\"15\">15</option><option value=\"16\">16</option><option value=\"17\">17</option><option value=\"18\">18</option><option value=\"19\">19</option><option value=\"20\">20</option><option value=\"21\">21</option><option value=\"22\">22</option><option value=\"23\">23</option><option value=\"24\">24</option><option value=\"25\">25</option><option value=\"26\">26</option><option value=\"27\">27</option><option value=\"28\">28</option><option value=\"29\">29</option><option value=\"30\">30</option></select>
                    &nbsp;
                    <select id=\"month\" style=\"width:30%;\">
                        <option value=\"1\">January</option>
                        <option value=\"2\">February</option>
                        <option value=\"3\">March</option>
                        <option value=\"4\">April</option>
                        <option value=\"5\">May</option>
                        <option value=\"6\">June</option>
                        <option value=\"7\">July</option>
                        <option value=\"8\">August</option>
                        <option value=\"9\">September</option>
                        <option value=\"10\">October</option>
                        <option value=\"11\">November</option>
                        <option value=\"12\">December</option>
                    </select>
                    &nbsp;
                    <select id=\"year\" style=\"width:30%;\"><option value=\"2000\">2000</option><option value=\"2001\">2001</option><option value=\"2002\">2002</option><option value=\"2003\">2003</option><option value=\"2004\">2004</option><option value=\"2005\">2005</option><option value=\"2006\">2006</option><option value=\"2007\">2007</option><option value=\"2008\">2008</option><option value=\"2009\">2009</option><option value=\"2010\">2010</option><option value=\"2011\">2011</option><option value=\"2012\">2012</option><option value=\"2013\">2013</option><option value=\"2014\">2014</option><option value=\"2015\">2015</option><option value=\"2016\" selected>2016</option></select>
                </div></div></div>
                <div class=\"pbox\">
                    <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>Mortgage Original Term</strong>
                </label></div><div class=\"datafeild\">
                <div class=\"fields\">
                    <select id=\"mort-term\" style=\"width:30%;\">
                        <option>Select Term</option>
                        <option>1</option>
                        <option selected>3</option>
                        <option>5</option>
                        <option>10</option>
                    </select></div></div></div>
                <div class=\"pbox\">
                    <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>Type of Existing Mortgage</strong>
                </label></div><div class=\"datafeild\">
                <div class=\"fields\">
                    <input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"variable\" checked=\"checked\"/> Variable
                    &nbsp;&nbsp;<input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"fixed\" /> Fixed   
                </div></div></div>

                <div class=\"pbox\">
                <div class=\"sep lint\">
                    <label for=\"loaninterest\" class=\"orange\"><strong>Existing Mortgage Rate (%)</strong> </label>
                    <span></span></div><div class=\"datafeild\">
                    <input id=\"loaninterest\" name=\"loaninterest\" value=\"2.99\" type=\"text\" />
                <div id=\"loaninterestslider\"></div>
                <div id=\"loanintereststeps\" class=\"steps\">
                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                </div></div></div> 
                <div class=\"pbox\">
                <div class=\"sep lint\">
                    <label for=\"newloaninterest\" class=\"orange\"><strong>New Mortgage Rate (%)</strong> </label>
                    <span></span></div><div class=\"datafeild\">
                    <input id=\"newloaninterest\" name=\"newloaninterest\" value=\"1.99\" type=\"text\" />
               <div id=\"newloaninterestslider\"></div>
                <div id=\"loanintereststeps\" class=\"steps\">
                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                </div>
                </div></div>
                <div class=\"pbox\">
                  <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>Province</strong>
                </label></div><div class=\"datafeild\">
                <div class=\"fields\">
                    <select id=\"province\" name=\"province\" >
                        <option value=\"AL\">Alberta</option>
                        <option value=\"BC\">British Columbia</option>
                        <option value=\"MA\">Manitoba</option>
                        <option value=\"NB\">New Brunswick</option>
                        <option value=\"NE\">Newfoundland</option>
                        <option value=\"NS\">Nova Scotia</option>
                        <option value=\"NT\">Northwest Territories</option>
                        <option value=\"NU\">Nunavut</option>
                        <option value=\"ON\" selected=\"selected\">Ontario</option>
                        <option value=\"PE\">Prince Edward Island</option>
                        <option value=\"QU\">Quebec</option>
                        <option value=\"SK\">Saskatchewan</option>
                        <option value=\"YU\">Yukon</option>\t\t\t\t
                    </select>    
                </div></div></div>
                <div class=\"pbox\">
                  <div class=\"lamount\">
                <label class=\"orange\">
                    <strong>Mortgage Provider</strong>
                </label></div><div class=\"datafeild\">
                <div class=\"fields\">
                    <select id=\"provider\" name=\"provider\" style=\"width:50%;\">
                        <option value=\"hsbc\">HSBC</option>
                        <option value=\"rbc\">RBC</option>
                        <option value=\"bmo\">BMO</option>
                        <option value=\"other\">Other</option>
                    </select>
                </div></div></div>   
                
                <h2 style=\"text-align: center;\">Mortgage Payment</h2>
                <div id=\"consolid\">
                    <div class=\"con-box-debt\" style=\"width:99%;color: #5CB426;border: none;\">Yes! You can refinance your mortgage.</div>
                    <div class=\"con-box-debt\">&nbsp;</div>
                    <div class=\"con-box-debt\"><b>Current Status</b></div>
                    <div class=\"con-box-debt\"><b>After Refinancing</b></div>
                    <div class=\"con-box-debt\">Mortgage Amount</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"mort-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-mort-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><b>Total Mortgage Amount</b></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"total-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-total-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Existing Rate</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"exist-rate\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-rate\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Mortagage Payment</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"old-pay\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-pay\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Refinance Penalty</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"mortgage-penalty\" disabled=\"disabled\"/></div>

                </div>
                <div id=\"non-consolid\" style=\"height: 400px;\">
                    <div class=\"con-box-debt\" style=\"width:99%;color: #E45630;border: none;\">No! You can't Refinance your mortgage.</div>
                </div>
                </div>
              </div></div>
            </form>
        </div>
        <script type=\"text/javascript\" src=\"";
        // line 277
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 278
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery_ss.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 279
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 280
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 281
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 282
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/superfish.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 283
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 284
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 285
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/refinancemort_ratetrade.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 286
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 287
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 288
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.datepicker.min.js"), "html", null, true);
        echo "\"></script>
        <script>
            \$(\".add-debt\").click(function (e) {
                e.preventDefault();
                \$(\".debt-div:last\").clone().insertAfter(\".debt-div:last\");
            });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:refinance-calculator-ratetrade.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 32,  84 => 29,  53 => 10,  127 => 28,  97 => 41,  76 => 17,  58 => 17,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 168,  214 => 69,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 77,  219 => 76,  217 => 75,  208 => 165,  204 => 164,  179 => 69,  159 => 61,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 14,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 79,  156 => 66,  151 => 63,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 18,  91 => 27,  62 => 23,  49 => 13,  87 => 25,  28 => 5,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 6,  24 => 4,  25 => 35,  21 => 2,  31 => 3,  26 => 11,  19 => 1,  93 => 28,  88 => 31,  78 => 26,  46 => 8,  44 => 9,  27 => 4,  79 => 18,  72 => 16,  69 => 25,  47 => 8,  40 => 8,  37 => 5,  22 => 2,  246 => 90,  157 => 56,  145 => 46,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 43,  111 => 37,  108 => 19,  101 => 43,  98 => 31,  96 => 31,  83 => 25,  74 => 27,  66 => 24,  55 => 15,  52 => 14,  50 => 10,  43 => 11,  41 => 10,  35 => 5,  32 => 6,  29 => 3,  209 => 82,  203 => 78,  199 => 67,  193 => 73,  189 => 71,  187 => 84,  182 => 66,  176 => 64,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 58,  149 => 51,  147 => 58,  144 => 49,  141 => 48,  133 => 55,  130 => 41,  125 => 44,  122 => 43,  116 => 41,  112 => 42,  109 => 34,  106 => 45,  103 => 32,  99 => 31,  95 => 28,  92 => 21,  86 => 28,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 10,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 9,  36 => 7,  33 => 4,  30 => 3,);
    }
}
