<?php

/* AcmeDemoBundle:Demo:income-ratetrade.html.twig */
class __TwigTemplate_cdbdcaf2e30b85aadca5b8d26f562faa535a658f8cc7db5c245c3957920a2591 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/emicalculator.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery-ui.css"), "html", null, true);
        echo "\">
<style type=\"text/css\">
    \${demo.css}
</style>
<div class=\"left-details\" style=\"width:100%!important;\">
    <div class=\"right-inner\">
        <div class=\"inner\">
            <form class=\"imageform\">
                <div class=\"entry-content\">
                    <div id=\"emicalcalulatorinnerform\" style=\"padding: 0px 0px 10px;\">
                        <div class=\"pbox\">
                            <div class=\"lamount\">
                                <label for=\"loanamount\" class=\"orange\"><strong>Property Value (\$)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"property-error\" style=\"color: #993A00;\"></label>
                                <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                                <div id=\"loanamountslider\" style=\"margin-top: 45px;\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"loaninterest\" class=\"orange\"><strong>Down Payment (\$)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"down-error\" style=\"color: rgb(153, 58, 0);\"></label>
                                <input id=\"loaninterest\" name=\"loaninterest\" value=\"\" type=\"text\" />
                                <div id=\"loaninterestslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"loanterm\" class=\"orange\"><strong class=\"orange\">Ammortization Period (Yr)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"ammort-error\" style=\"color: #993A00;\"></label>
                                <input id=\"loanterm\" name=\"loanterm\" value=\"\" type=\"text\" />
                                <div id=\"loantermslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 19.67%;\">|<br/><span class=\"marker\">5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 39.8%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left: 59.8%;\">|<br/><span class=\"marker\">15</span></span>
                                    <span class=\"tick\" style=\"left: 79.67%;\">|<br/><span class=\"marker\">20</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">25</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"mortrate\" class=\"orange\"><strong class=\"orange\">Mortgage Rate (%)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"mortrate-error\" style=\"color: #993A00;\"></label>
                                <input id=\"mortrate\" name=\"mortrate\" value=\"\" type=\"text\" />
                                <div id=\"mortrateslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"proptax\" class=\"orange\"><strong>Property Tax (Yearly)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"property-error\" style=\"color: #993A00;\"></label>
                                <input id=\"proptax\" name=\"proptax\" value=\"\" type=\"text\" />
                                <div id=\"proptaxslider\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"heating\" class=\"orange\"><strong>Heating Cost (Monthly)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"property-error\" style=\"color: #993A00;\"></label>
                                <input id=\"heating\" name=\"heating\" value=\"\" type=\"text\" />
                                <div id=\"heatingslider\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div>
                            </div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"condo\" class=\"orange\"><strong>Condo Fees (\$)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"property-error\" style=\"color: #993A00;\"></label>
                                <input id=\"condo\" name=\"condo\" value=\"\" type=\"text\" />
                                <div id=\"condoslider\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"sep lint\">
                                <label for=\"debt\" class=\"orange\"><strong>Monthly Debts (\$)</strong> </label>
                                <span></span>
                            </div>
                            <div class=\"datafeild\">
                                <label class=\"property-error\" style=\"color: #993A00;\"></label>
                                <input id=\"debt\" name=\"debt\" value=\"\" type=\"text\" />
                                <div id=\"debtslider\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$1.5M</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$2M</span></span>
                                </div>
                            </div></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class=\"left-details\" style=\"width:100%!important; margin-top: -10px; padding: 0 9px 0 14px;\">
    <div class=\"box resultam\">
        <strong class=\"orange\">Loan to Value (%)</strong><br/>
        <input id=\"down-payment\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
    </div>
    <div class=\"box resultam\">
        <strong class=\"orange\">Mortgage Insurance (\$)</strong><br/>
        <input id=\"chmc-ins\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/> 
    </div>
    <div class=\"box resultam\">
        <strong class=\"orange\">Total Mortgage (\$)</strong><br/>
        <input id=\"mort-reqd\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
    </div>
    <div class=\"box resultam\">
        <strong class=\"orange\">Mortgage Payment (\$)</strong><br/>
        <input id=\"emi-data\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
    </div>
    <div class=\"box resultam\">
        <strong class=\"orange\">Total Monthly Payment(\$)</strong><br/>
        <input id=\"total-emi\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
    </div>
    <div class=\"box resultam\">
        <strong class=\"orange\">Income Required(\$)</strong><br/>
        <input id=\"income\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"width:70%;text-align:center;color:rgb(35, 98, 2);\"/>
    </div>
</div>
<script type=\"text/javascript\" src=\"";
        // line 181
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 182
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery_ss.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 183
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 184
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 185
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 186
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/superfish.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 187
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 188
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/income_ratetrade.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 192
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.datepicker.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/highcharts.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/exporting.js"), "html", null, true);
        echo "\"></script>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:income-ratetrade.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 181,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 189,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 155,  150 => 80,  146 => 79,  134 => 76,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 128,  170 => 127,  148 => 90,  77 => 30,  231 => 183,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 194,  251 => 188,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 107,  167 => 105,  137 => 94,  129 => 74,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 135,  197 => 114,  185 => 102,  181 => 101,  70 => 37,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 235,  285 => 89,  283 => 196,  278 => 231,  268 => 85,  264 => 84,  258 => 191,  252 => 80,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 154,  224 => 178,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 108,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 27,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 109,  171 => 106,  166 => 126,  163 => 104,  158 => 94,  156 => 66,  151 => 81,  142 => 78,  138 => 77,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 95,  49 => 10,  87 => 34,  28 => 3,  94 => 41,  89 => 20,  85 => 32,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 29,  72 => 38,  69 => 28,  47 => 12,  40 => 6,  37 => 5,  22 => 2,  246 => 188,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 96,  55 => 20,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 147,  193 => 113,  189 => 103,  187 => 144,  182 => 130,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 125,  154 => 107,  149 => 87,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 71,  125 => 73,  122 => 48,  116 => 70,  112 => 69,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 50,  80 => 30,  73 => 29,  64 => 13,  60 => 6,  57 => 93,  54 => 92,  51 => 14,  48 => 10,  45 => 8,  42 => 22,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
