<?php

/* MainRatetradeBundle:Default:apply-now.html.twig */
class __TwigTemplate_becc27ec92c8f110ba63a7a355fcf6d1fb3c38a032e89c890d4a140798251c47 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <meta name=\"geo.region\" content=\"CA\" />
        <title>Apply For Lowest Mortgage Interest Rates</title>
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" />   
        <link rel=\"canonical\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"> 
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
     <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
        <script language=\"JavaScript\" 
                src=\"http://www.iplocationtools.com/iplocationtools.js?key=7b71786a7773756d6a207270\">
        </script>


    <body>
           ";
        // line 37
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "


        <section class=\"inner-page\">

            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-xs-12\">
                        <div id=\"agentModal2\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel2\">
                            <div class=\"modal-dialog modal-lg\" role=\"document\">
                                <div class=\"modal-content\">
                                    <div class=\"modal-header\">
                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                                        <h4 class=\"modal-title\" id=\"myModalLabel2\">Contact For Rate <span id=\"rate-r\">";
        // line 50
        echo twig_escape_filter($this->env, (isset($context["rate"]) ? $context["rate"] : $this->getContext($context, "rate")), "html", null, true);
        echo "</span> %</h4>
                                    </div>
                                    <div class=\"modal-body\">
                                        <div class=\"row\">
                                            <div class=\"col-xs-12 col-sm-12\">
                                                <div class=\"form-class\">
                                                    <form class=\"\">
                                                        <div class=\"col-xs-12 col-sm-6\">
                                                            <div class=\"form-group\">
                                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                                            </div>
                                                            <div class=\"form-group\">

                                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                                            </div>
                                                            <div class=\"form-group\">
                                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                                    <option value=\"anytime\">Any Time</option>
                                                                    <option value=\"morning\">Morning</option>
                                                                    <option value=\"afternoon\">Afternoon</option>
                                                                    <option value=\"evening\">Evening</option>
                                                                </select>
                                                            </div>
                                                            <div class=\"form-group\">
                                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                                            </div>                                
                                                        </div>

                                                        <div class=\"col-xs-12 col-sm-6\">
                                                            <div class=\"form-group\">
                                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                                    ";
        // line 87
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 88
            echo "                                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                                            <option value=\"";
                // line 89
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                                        ";
            } else {
                // line 91
                echo "                                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                                        ";
            }
            // line 93
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 94
        echo "                                                                </select>
                                                            </div>
                                                            <div class=\"form-group\">
                                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                                    <option value=\"\">Please Select</option>
                                                                    <option value=\"buying\">Buying</option>
                                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                                    <option value=\"refinancing\">Refinancing</option>
                                                                </select>
                                                            </div>
                                                            <div class=\"form-group\">
                                                                <br>
                                                                <input type=\"hidden\" id=\"rate-request\" value=\"";
        // line 108
        echo twig_escape_filter($this->env, (isset($context["rate"]) ? $context["rate"] : $this->getContext($context, "rate")), "html", null, true);
        echo "\"/>
                                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                                            </div>                                
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=\"modal-footer\">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        ";
        // line 128
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "

        <script>
                                                                    \$(document).ready(function () {
                                                                        if (ip2location_country_long() === 'Canada')
                                                                        {
                                                                            \$(\"#agentLocationName\").val(ip2location_city());
                                                                            \$(\"#agentLocation\").find(\"option:contains('\" + ip2location_city() + \"')\").prop(\"selected\", true);
                                                                        }
                                                                        else
                                                                        {
                                                                            \$(\"#agentLocationName\").val(\"Brampton\");
                                                                            \$(\"#agentLocation\").find(\"option:contains('Brampton')\").prop(\"selected\", true);
                                                                        }
                                                                    });

                                                                    \$('.locations').on('click', function () {

                                                                        \$('.location-name-box').toggle(500);
                                                                    });
                                                                    \$('.level1Btn').on('click', function () {
                                                                        \$('.level1 ul').toggle(500);

                                                                    });
                                                                    \$('.level2Btn').on('click', function () {
                                                                        \$('.level2 ul').toggle(500);

                                                                    });
                                                                    \$('.level3Btn').on('click', function () {
                                                                        \$('.level3 ul').toggle(500);

                                                                    });

                                                                    \$('#agentLocationName').click(function (e) {
                                                                        \$('#agentLocation').show(100);
                                                                    });
                                                                    \$('#agentLocation').blur(function (e) {
                                                                        \$(this).hide(100);
                                                                    });

                                                                    function capitalizeFirstLetter(string) {
                                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                                    }

                                                                    \$('#agentLocationName').on('input', function () {
                                                                        // Getiing option based on input value and setting it as selected
                                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                                    });

                                                                    function getPop() {

                                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                                        \$('#agentLocation').hide(100);
                                                                    }



                                                                    function validateEmail(email) {
                                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                                        return re.test(email);
                                                                    }

                                                                    \$(document).on(\"click\", \".subsc\", function (e) {
                                                                        e.preventDefault();
                                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                                        {
                                                                            \$(\"#exampleInputEmail2\").focus();
                                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                                        }
                                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                                        {
                                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                                            \$(\"#exampleInputEmail2\").focus();
                                                                        }
                                                                        else {
                                                                            \$.ajax({
                                                                                url: '";
        // line 207
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                                type: \"post\",
                                                                                async: true,
                                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                                    'name': \"testname\"},
                                                                                success: function (response) {
                                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                                    alert(response);
                                                                                },
                                                                                error: function (request, error) {
                                                                                    // alert('No data found');
                                                                                }
                                                                            });
                                                                        }
                                                                    });

                                                                    \$(document).on(\"change\", \".required\", function () {
                                                                        \$(this).css('border', '1px solid green');

                                                                        if (\$(this).val() == '')
                                                                        {
                                                                            \$(this).focus();
                                                                            \$(this).css('border', '1px solid red');
                                                                        }

                                                                        var id = \$(this).attr('id');
                                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                                        {
                                                                            \$(\"#EmailId\").focus();
                                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                                        }
                                                                    });

                                                                    \$(document).on(\"click\", \".lead-submit\", function (e) {

                                                                        if (\$(\"#urName\").val() == '')
                                                                        {
                                                                            \$(\"#urName\").focus();
                                                                            \$(\"#urName\").css('border', '1px solid red');
                                                                        }
                                                                        else if (\$(\"#EmailId\").val() == '')
                                                                        {
                                                                            \$(\"#EmailId\").focus();
                                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                                        }
                                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                                        {
                                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                                            \$(\"#EmailId\").focus();
                                                                        }
                                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                                        {
                                                                            \$(\"#phonenUmber\").focus();
                                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                                        }
                                                                        else {
                                                                            var currentRequest = null;
                                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                                            var formData = {
                                                                                fname: \$(\"#urName\").val(),
                                                                                email: \$(\"#EmailId\").val(),
                                                                                phone: \$(\"#phonenUmber\").val(),
                                                                                message: \$(\"#rate-request\").val(),
                                                                                location: \$(\"#agentLocationName\").val(),
                                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                                            };
                                                                            currentRequest = \$.ajax({
                                                                                type: \"post\",
                                                                                async: true,
                                                                                url: \"";
        // line 277
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                                data: formData,
                                                                                beforeSend: function () {
                                                                                    if (currentRequest != null) {
                                                                                        currentRequest.abort();
                                                                                    }
                                                                                },
                                                                                success: function (response) {
                                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                                    \$(\".required\").removeAttr('style');
                                                                                    \$(\"#agentModal1\").modal('hide');
                                                                                    alert(\"Thanks for appying for Mortgage. Our executive will contact you soon\");
                                                                                    window.location.href = '/thank-you';
                                                                                },
                                                                                error: function (request, error) {
                                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                                    \$(\".required\").removeAttr('style');
                                                                                    alert(\"Query Failed\");
                                                                                }
                                                                            });
                                                                        }
                                                                    });

        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:apply-now.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  382 => 277,  118 => 50,  597 => 325,  593 => 324,  589 => 323,  585 => 322,  581 => 321,  576 => 319,  572 => 318,  568 => 317,  561 => 313,  546 => 300,  540 => 299,  532 => 297,  529 => 296,  525 => 295,  517 => 289,  511 => 288,  503 => 286,  500 => 285,  496 => 284,  487 => 277,  481 => 276,  473 => 274,  470 => 273,  466 => 272,  455 => 264,  451 => 263,  447 => 262,  443 => 261,  439 => 260,  434 => 258,  426 => 256,  422 => 255,  400 => 236,  395 => 234,  114 => 19,  260 => 189,  256 => 188,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 181,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 189,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 155,  150 => 80,  146 => 79,  134 => 76,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 94,  301 => 305,  293 => 299,  113 => 70,  174 => 91,  170 => 127,  148 => 90,  77 => 30,  231 => 183,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 36,  34 => 8,  155 => 27,  310 => 239,  306 => 238,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 230,  270 => 194,  251 => 188,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 32,  167 => 89,  137 => 94,  129 => 74,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 135,  197 => 114,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 28,  53 => 11,  127 => 20,  97 => 62,  76 => 26,  58 => 11,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 257,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 207,  305 => 306,  298 => 236,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 193,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 128,  224 => 178,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 24,  135 => 77,  119 => 42,  102 => 37,  71 => 12,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 34,  171 => 31,  166 => 126,  163 => 29,  158 => 87,  156 => 100,  151 => 26,  142 => 78,  138 => 77,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 41,  89 => 20,  85 => 14,  75 => 28,  68 => 24,  56 => 21,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 29,  78 => 28,  46 => 8,  44 => 18,  27 => 7,  79 => 29,  72 => 25,  69 => 28,  47 => 12,  40 => 17,  37 => 5,  22 => 2,  246 => 188,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 63,  98 => 15,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 20,  52 => 20,  50 => 21,  43 => 11,  41 => 10,  35 => 15,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 113,  189 => 103,  187 => 35,  182 => 93,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 88,  154 => 107,  149 => 87,  147 => 25,  144 => 89,  141 => 95,  133 => 93,  130 => 71,  125 => 73,  122 => 48,  116 => 70,  112 => 69,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 30,  86 => 51,  82 => 50,  80 => 27,  73 => 29,  64 => 23,  60 => 22,  57 => 93,  54 => 92,  51 => 14,  48 => 19,  45 => 10,  42 => 22,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
