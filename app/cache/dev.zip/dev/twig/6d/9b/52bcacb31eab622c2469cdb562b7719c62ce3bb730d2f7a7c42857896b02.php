<?php

/* MainRatetradeBundle:Default:thank-you.html.twig */
class __TwigTemplate_6d9b52bcacb31eab622c2469cdb562b7719c62ce3bb730d2f7a7c42857896b02 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <meta name=\"geo.region\" content=\"CA\" />
        <title>Thank You - Ratetrade.ca</title>
 <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
        <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"https://www.ratetrade.ca/thank-you\"/>
        <script language=\"JavaScript\" 
                src=\"http://www.iplocationtools.com/iplocationtools.js?key=7b71786a7773756d6a207270\">
        </script>


    <body>
           ";
        // line 30
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
  <!-- /HEADER -->
 <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Thank You</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">Thank You</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->
        <section class=\"inner-page\">

            <div class=\"container\">
                <div class=\"row text-content\">
                    <div class=\"col-xs-12 col-sm-7 col-md-12\">
                        <div class=\"left-content\">
                          
                            <div class=\"content-boxes\">
                                <br/>
                                We have received your message and would like to thank you for writing to us. Your inquiry is very important to us, One of our staff members will contact you shortly.
                                <br/><br/>
                                Talk to you soon,<br/>
                                Ratetrade.ca
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<br/>

        </section>
        ";
        // line 69
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo " 
        <script src=\"";
        // line 70
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/bootstrap.min.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/js/menu-js.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
        <script>

            function validateEmail(email) {
                var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                return re.test(email);
            }

            \$(document).on(\"click\", \".subsc\", function(e) {
                e.preventDefault();
                \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                if (\$(\"#exampleInputEmail2\") == '')
                {
                    \$(\"#exampleInputEmail2\").focus();
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                {
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                    \$(\"#exampleInputEmail2\").focus();
                }
                else {
                    \$.ajax({
                        url: '";
        // line 95
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                        type: \"post\",
                        async: true,
                        data: {'email': \$(\"#exampleInputEmail2\").val(),
                            'name': \"testname\"},
                        success: function(response) {
                            \$(\"#exampleInputEmail2\").val('');
                            alert(response);
                        },
                        error: function(request, error) {
                            // alert('No data found');
                        }
                    });
                }
            });

            \$('.locations').on('click', function() {

                \$('.location-name-box').toggle(500);
            });
            \$('.level1Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level1 ul').toggle(500);
            });
            \$('.level2Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level2 ul').toggle(500);
            });
            \$('.level3Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level3 ul').toggle(500);
            });
        </script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:thank-you.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  858 => 576,  730 => 451,  659 => 398,  654 => 397,  590 => 339,  438 => 271,  664 => 312,  658 => 311,  650 => 396,  643 => 307,  588 => 262,  567 => 248,  345 => 151,  1594 => 1360,  1587 => 1356,  1583 => 1355,  1577 => 1352,  1573 => 1351,  1569 => 1350,  1507 => 1291,  1465 => 1252,  1456 => 1246,  1449 => 1242,  1428 => 1224,  1424 => 1223,  1420 => 1222,  1416 => 1221,  1412 => 1220,  1408 => 1219,  1404 => 1218,  1400 => 1217,  1396 => 1216,  1392 => 1215,  1388 => 1214,  860 => 695,  854 => 497,  823 => 665,  817 => 663,  791 => 642,  785 => 641,  773 => 639,  750 => 522,  634 => 305,  595 => 380,  571 => 374,  485 => 305,  297 => 203,  874 => 702,  801 => 513,  692 => 416,  688 => 415,  684 => 414,  679 => 412,  675 => 411,  671 => 410,  612 => 373,  562 => 329,  624 => 376,  545 => 371,  605 => 336,  601 => 381,  575 => 375,  488 => 209,  776 => 467,  703 => 397,  573 => 249,  557 => 276,  401 => 183,  287 => 131,  1156 => 880,  1083 => 810,  963 => 692,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 611,  830 => 605,  824 => 604,  813 => 601,  800 => 593,  794 => 592,  786 => 590,  783 => 589,  779 => 640,  768 => 580,  764 => 579,  760 => 578,  756 => 577,  752 => 576,  748 => 575,  744 => 574,  740 => 573,  732 => 571,  405 => 184,  333 => 146,  307 => 137,  299 => 186,  257 => 104,  807 => 497,  617 => 374,  611 => 311,  596 => 307,  591 => 306,  491 => 294,  431 => 187,  415 => 182,  291 => 173,  284 => 177,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 378,  582 => 396,  578 => 327,  317 => 208,  565 => 320,  468 => 284,  281 => 177,  465 => 283,  361 => 157,  332 => 173,  328 => 147,  320 => 201,  276 => 115,  272 => 124,  245 => 153,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 386,  563 => 230,  559 => 246,  550 => 290,  547 => 231,  542 => 288,  514 => 226,  492 => 252,  484 => 201,  410 => 173,  397 => 246,  388 => 169,  380 => 201,  366 => 236,  331 => 146,  323 => 139,  315 => 141,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 291,  548 => 304,  533 => 300,  528 => 216,  478 => 212,  442 => 272,  417 => 265,  372 => 199,  336 => 164,  924 => 587,  851 => 517,  826 => 532,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 378,  625 => 341,  620 => 323,  616 => 322,  555 => 266,  538 => 237,  534 => 308,  526 => 306,  509 => 245,  482 => 287,  386 => 222,  357 => 158,  353 => 156,  344 => 192,  339 => 227,  335 => 175,  329 => 145,  321 => 151,  610 => 337,  462 => 208,  394 => 224,  370 => 237,  364 => 197,  349 => 200,  340 => 175,  325 => 143,  319 => 194,  304 => 185,  295 => 174,  289 => 176,  280 => 126,  126 => 29,  845 => 613,  772 => 421,  685 => 337,  680 => 403,  676 => 334,  644 => 291,  638 => 306,  630 => 301,  618 => 298,  614 => 297,  539 => 229,  531 => 227,  516 => 319,  476 => 286,  464 => 282,  421 => 266,  343 => 228,  324 => 145,  316 => 184,  313 => 207,  303 => 131,  292 => 128,  288 => 128,  510 => 280,  506 => 298,  502 => 233,  498 => 296,  425 => 267,  419 => 198,  411 => 181,  389 => 180,  378 => 181,  311 => 139,  708 => 550,  619 => 362,  580 => 376,  558 => 306,  552 => 244,  544 => 238,  537 => 301,  523 => 233,  512 => 299,  483 => 208,  452 => 241,  448 => 206,  436 => 225,  408 => 249,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 664,  816 => 602,  812 => 642,  808 => 641,  804 => 640,  780 => 426,  418 => 177,  100 => 32,  277 => 176,  521 => 282,  513 => 280,  508 => 225,  499 => 212,  495 => 295,  489 => 306,  472 => 257,  396 => 234,  392 => 185,  377 => 219,  356 => 154,  352 => 194,  348 => 193,  192 => 112,  883 => 685,  699 => 504,  449 => 273,  432 => 222,  428 => 267,  414 => 250,  406 => 213,  403 => 179,  399 => 178,  390 => 241,  376 => 200,  373 => 238,  369 => 217,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 419,  700 => 418,  696 => 417,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 342,  570 => 321,  564 => 320,  556 => 318,  549 => 316,  541 => 310,  535 => 309,  527 => 307,  524 => 306,  520 => 305,  505 => 297,  497 => 222,  494 => 308,  479 => 302,  475 => 285,  467 => 283,  458 => 207,  454 => 206,  450 => 274,  446 => 273,  184 => 107,  180 => 106,  172 => 35,  160 => 32,  152 => 30,  937 => 686,  809 => 600,  759 => 493,  753 => 462,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 402,  670 => 419,  666 => 400,  629 => 358,  623 => 299,  615 => 355,  608 => 372,  603 => 275,  599 => 351,  553 => 317,  536 => 228,  530 => 235,  522 => 219,  519 => 304,  515 => 261,  507 => 282,  501 => 256,  493 => 221,  490 => 293,  486 => 251,  477 => 270,  471 => 237,  463 => 242,  460 => 281,  456 => 228,  445 => 272,  441 => 271,  433 => 194,  429 => 268,  424 => 266,  420 => 265,  416 => 264,  412 => 214,  385 => 179,  382 => 193,  118 => 27,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 282,  576 => 319,  572 => 318,  568 => 254,  561 => 277,  546 => 289,  540 => 309,  532 => 284,  529 => 284,  525 => 331,  517 => 281,  511 => 319,  503 => 206,  500 => 223,  496 => 220,  487 => 251,  481 => 286,  473 => 308,  470 => 210,  466 => 209,  455 => 195,  451 => 224,  447 => 247,  443 => 246,  439 => 270,  434 => 270,  426 => 200,  422 => 232,  400 => 247,  395 => 177,  114 => 26,  260 => 162,  256 => 103,  248 => 114,  266 => 124,  262 => 121,  250 => 116,  242 => 136,  234 => 185,  226 => 87,  222 => 86,  218 => 105,  279 => 142,  275 => 171,  271 => 164,  267 => 163,  263 => 123,  259 => 122,  255 => 129,  239 => 150,  81 => 53,  65 => 21,  1085 => 1059,  210 => 121,  198 => 103,  194 => 123,  190 => 57,  186 => 109,  178 => 35,  150 => 35,  146 => 34,  134 => 31,  124 => 77,  104 => 19,  391 => 176,  383 => 174,  375 => 163,  371 => 159,  367 => 161,  363 => 177,  359 => 168,  351 => 171,  347 => 153,  188 => 42,  301 => 204,  293 => 202,  113 => 90,  174 => 34,  170 => 39,  148 => 29,  77 => 52,  231 => 90,  165 => 37,  161 => 36,  153 => 97,  195 => 106,  191 => 42,  34 => 11,  155 => 30,  310 => 197,  306 => 176,  302 => 195,  290 => 180,  286 => 146,  282 => 166,  274 => 153,  270 => 194,  251 => 128,  237 => 93,  233 => 138,  225 => 127,  213 => 87,  205 => 78,  175 => 35,  167 => 33,  137 => 84,  129 => 82,  23 => 3,  223 => 119,  215 => 135,  211 => 119,  207 => 118,  202 => 118,  197 => 111,  185 => 117,  181 => 38,  70 => 20,  358 => 156,  354 => 231,  350 => 210,  346 => 229,  342 => 150,  338 => 149,  334 => 142,  330 => 163,  326 => 201,  318 => 141,  206 => 92,  244 => 112,  236 => 133,  232 => 131,  228 => 84,  216 => 96,  212 => 95,  200 => 126,  110 => 25,  90 => 34,  84 => 28,  53 => 24,  127 => 26,  97 => 62,  76 => 41,  58 => 17,  480 => 234,  474 => 211,  469 => 284,  461 => 282,  457 => 234,  453 => 206,  444 => 192,  440 => 246,  437 => 270,  435 => 269,  430 => 257,  427 => 211,  423 => 194,  413 => 234,  409 => 238,  407 => 180,  402 => 226,  398 => 211,  393 => 245,  387 => 175,  384 => 168,  381 => 240,  379 => 173,  374 => 227,  368 => 198,  365 => 189,  362 => 156,  360 => 232,  355 => 227,  341 => 156,  337 => 155,  322 => 173,  314 => 140,  312 => 136,  309 => 206,  305 => 205,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 116,  268 => 123,  264 => 122,  258 => 97,  252 => 117,  247 => 149,  241 => 94,  229 => 109,  220 => 113,  214 => 122,  177 => 103,  169 => 101,  140 => 27,  132 => 25,  128 => 85,  107 => 28,  61 => 14,  273 => 185,  269 => 110,  254 => 159,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 144,  227 => 129,  224 => 141,  221 => 98,  219 => 88,  217 => 125,  208 => 96,  204 => 83,  179 => 114,  159 => 31,  143 => 90,  135 => 70,  119 => 31,  102 => 19,  71 => 19,  67 => 29,  63 => 37,  59 => 27,  201 => 115,  196 => 113,  183 => 53,  171 => 44,  166 => 95,  163 => 32,  158 => 37,  156 => 31,  151 => 95,  142 => 33,  138 => 32,  136 => 26,  121 => 92,  117 => 73,  105 => 61,  91 => 59,  62 => 18,  49 => 14,  87 => 16,  28 => 8,  94 => 35,  89 => 30,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 12,  24 => 4,  25 => 35,  21 => 2,  31 => 11,  26 => 9,  19 => 1,  93 => 18,  88 => 56,  78 => 22,  46 => 14,  44 => 11,  27 => 7,  79 => 20,  72 => 40,  69 => 40,  47 => 21,  40 => 8,  37 => 11,  22 => 2,  246 => 96,  157 => 98,  145 => 53,  139 => 71,  131 => 69,  123 => 25,  120 => 37,  115 => 20,  111 => 29,  108 => 67,  101 => 18,  98 => 36,  96 => 31,  83 => 27,  74 => 21,  66 => 19,  55 => 26,  52 => 12,  50 => 15,  43 => 23,  41 => 12,  35 => 12,  32 => 12,  29 => 9,  209 => 132,  203 => 94,  199 => 93,  193 => 47,  189 => 109,  187 => 41,  182 => 108,  176 => 36,  173 => 102,  168 => 34,  164 => 33,  162 => 38,  154 => 36,  149 => 69,  147 => 28,  144 => 28,  141 => 85,  133 => 44,  130 => 30,  125 => 93,  122 => 28,  116 => 21,  112 => 65,  109 => 68,  106 => 41,  103 => 20,  99 => 26,  95 => 60,  92 => 57,  86 => 15,  82 => 17,  80 => 20,  73 => 14,  64 => 12,  60 => 15,  57 => 16,  54 => 16,  51 => 11,  48 => 11,  45 => 10,  42 => 13,  39 => 10,  36 => 10,  33 => 8,  30 => 10,);
    }
}
