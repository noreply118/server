<?php

/* AcmeDemoBundle:Demo:refinance-penalty.html.twig */
class __TwigTemplate_391abe80dfd8f335b713c5230057a751d200e973b6cfe9a3a1aa67be0999edea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0;\">
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>Mortgage Penalty to Refinance</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/emicalculator.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery-ui.css"), "html", null, true);
        echo "\">
    </head>
    <body>
        <div class=\"header\">
            <div class=\"wrapper\"> <a href=\"#\" onclick=\"window.history.back();\" class=\"home-ico\">
                    <img src=\"/symfonyratetrade/web/bundles/acmedemo/images/back.png\">
                </a> 
                <span class=\"page-name\">Penalty Calculator</span> </div>
        </div>
        <div class=\"headerfix\"></div>
        <div class=\"wrapper bodywrapper\">
            <div class=\"left-nav\"> 
                <a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">EMI Calculator</a>
                <a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">CHMC Calculator</a>
                <a href=\"";
        // line 26
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a>
                <a href=\"";
        // line 27
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a>
                <a href=\"";
        // line 28
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\" class=\"selected\">Refinance Penalty</a>
            </div>
            <div class=\"right-details\">
                <div class=\"right-inner\">
                    <div class=\"inner\">
                        <form class=\"imageform\">
                            <div class=\"entry-content\">
                                <div id=\"emicalcalulatorinnerform\">
                                    <div class=\"lamount\">
                                        <label for=\"loanamount\"><strong>Remaining Balance on Mortgage</strong> </label>
                                        <span><img class=\"num-icon\" src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/us-dollar-xxl.png"), "html", null, true);
        echo "\"></span>
                                        <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />

                                    </div>
                                    <div id=\"loanamountslider\"></div>
                                    <div id=\"loanamountsteps\" class=\"steps\">
                                        <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                        <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">2.5L</span></span>
                                        <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5L</span></span>
                                        <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">7.5L</span></span>
                                        <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10L</span></span>
                                    </div>
                                </div>
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Mortgage Start Date</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"date\" style=\"width:30%;\"><option value=\"1\">1</option><option value=\"2\">2</option><option value=\"3\">3</option><option value=\"4\">4</option><option value=\"5\">5</option><option value=\"6\">6</option><option value=\"7\">7</option><option value=\"8\">8</option><option value=\"9\">9</option><option value=\"10\">10</option><option value=\"11\">11</option><option value=\"12\">12</option><option value=\"13\">13</option><option value=\"14\">14</option><option value=\"15\">15</option><option value=\"16\">16</option><option value=\"17\">17</option><option value=\"18\">18</option><option value=\"19\">19</option><option value=\"20\">20</option><option value=\"21\">21</option><option value=\"22\">22</option><option value=\"23\">23</option><option value=\"24\">24</option><option value=\"25\">25</option><option value=\"26\">26</option><option value=\"27\">27</option><option value=\"28\">28</option><option value=\"29\">29</option><option value=\"30\">30</option></select>
                                &nbsp;
                                <select id=\"month\" style=\"width:30%;\">
                                    <option value=\"1\">January</option>
                                    <option value=\"2\">February</option>
                                    <option value=\"3\">March</option>
                                    <option value=\"4\">April</option>
                                    <option value=\"5\">May</option>
                                    <option value=\"6\">June</option>
                                    <option value=\"7\">July</option>
                                    <option value=\"8\">August</option>
                                    <option value=\"9\">September</option>
                                    <option value=\"10\">October</option>
                                    <option value=\"11\">November</option>
                                    <option value=\"12\">December</option>
                                </select>
                                &nbsp;
                                <select id=\"year\" style=\"width:30%;\"><option value=\"2000\">2000</option><option value=\"2001\">2001</option><option value=\"2002\">2002</option><option value=\"2003\">2003</option><option value=\"2004\">2004</option><option value=\"2005\">2005</option><option value=\"2006\">2006</option><option value=\"2007\">2007</option><option value=\"2008\">2008</option><option value=\"2009\">2009</option><option value=\"2010\">2010</option><option value=\"2011\">2011</option><option value=\"2012\">2012</option><option value=\"2013\">2013</option><option value=\"2014\">2014</option><option value=\"2015\">2015</option><option value=\"2016\" selected>2016</option></select>
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Mortgage Original Term</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"mort-term\" style=\"width:30%;\">
                                    <option>Select Term</option>
                                    <option>1</option>
                                    <option selected>3</option>
                                    <option>5</option>
                                    <option>10</option>
                                </select></div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Type of Existing Mortgage</strong>
                            </label>
                            <div class=\"fields\">
                                <input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"variable\" checked=\"checked\"/> Variable
                                &nbsp;&nbsp;<input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"fixed\" /> Fixed   
                            </div>

                            <div style=\"clear:both\"></div>
                             <div class=\"sep lint\">
                                    <label for=\"loaninterest\"><strong>Existing Mortgage Rate</strong> </label>
                                    <span><img class=\"num-icon\" src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/128.png"), "html", null, true);
        echo "\"></span>
                                    <input id=\"loaninterest\" name=\"loaninterest\" value=\"10.5\" type=\"text\" />
                                </div>
                                <div id=\"loaninterestslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">7.5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">12.5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">15</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">17.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">20</span></span>
                                </div>
                               <div style=\"clear:both\"></div>  
                               <div class=\"sep lint\">
                                    <label for=\"newloaninterest\"><strong>New Mortgage Rate</strong> </label>
                                    <span><img class=\"num-icon\" src=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/128.png"), "html", null, true);
        echo "\"></span>
                                    <input id=\"newloaninterest\" name=\"newloaninterest\" value=\"10.5\" type=\"text\" />
                                </div>
                                <div id=\"newloaninterestslider\"></div>
                                <div id=\"loanintereststeps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">5</span></span>
                                    <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">7.5</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">10</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">12.5</span></span>
                                    <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">15</span></span>\t\t\t\t            
                                    <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">17.5</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">20</span></span>
                                </div>
                             <div style=\"clear:both\"></div>
                            <label>
                                <strong>Province</strong>
                            </label>
                            <div class=\"fields\">
                            <select id=\"province\" name=\"province\" >
\t\t                <option value=\"AL\">Alberta</option>
\t\t                <option value=\"BC\">British Columbia</option>
                                <option value=\"MA\">Manitoba</option>
                                <option value=\"NB\">New Brunswick</option>
                                <option value=\"NE\">Newfoundland</option>
\t\t\t\t<option value=\"NS\">Nova Scotia</option>
                                <option value=\"NT\">Northwest Territories</option>
\t\t\t\t<option value=\"NU\">Nunavut</option>
                                <option value=\"ON\" selected=\"selected\">Ontario</option>
                                <option value=\"PE\">Prince Edward Island</option>
                                <option value=\"QU\">Quebec</option>
\t\t\t\t<option value=\"SK\">Saskatchewan</option>
\t\t\t\t<option value=\"YU\">Yukon</option>\t\t\t\t
\t\t\t    </select>    
                            </div>
                            <div style=\"clear:both\"></div>
                            <label>
                                <strong>Mortgage Original Term</strong>
                            </label>
                            <div class=\"fields\">
                                <select id=\"provider\" name=\"provider\" >
\t\t                <option value=\"hsbc\">HSBC</option>
                                <option value=\"rbc\">RBC</option>
                                <option value=\"bmo\">BMO</option>
\t\t\t    </select>
                            </div>
                              

                            <div style=\"clear:both\"></div>  
                            <br/><br/>
                            <table>
                                <tr>
                                    <th>Provider Dishcharge Fee</th>
                                    <th>&nbsp;</th>
                                    <th>Mortgage Penalty</th>
                                </tr>
                                <tr>
                                    <th>
                                        <input id=\"discharge-fee\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"text-align:center;color:#000;\"/>
                                    </th>
                                    <th>&nbsp;</th>
                                    <th>
                                        <input id=\"mortgage-penalty\" value=\"\" type=\"text\" disabled=\"disabled\" style=\"text-align:center;color:#000;\"/>
                                    </th>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script type=\"text/javascript\" src=\"";
        // line 186
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 187
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery_ss.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 188
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/superfish.js"), "html", null, true);
        echo "\"></script>

        <script type=\"text/javascript\" src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>

        <script type=\"text/javascript\" src=\"";
        // line 195
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 196
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/penalty.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 198
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 199
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.datepicker.min.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:refinance-penalty.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 189,  256 => 188,  248 => 186,  266 => 193,  262 => 192,  250 => 189,  242 => 187,  234 => 185,  226 => 183,  222 => 182,  218 => 181,  279 => 195,  275 => 194,  271 => 193,  267 => 192,  263 => 191,  259 => 190,  255 => 189,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 155,  150 => 80,  146 => 79,  134 => 76,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 128,  170 => 127,  148 => 90,  77 => 30,  231 => 183,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 198,  286 => 197,  282 => 196,  274 => 230,  270 => 194,  251 => 188,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 116,  167 => 105,  137 => 94,  129 => 74,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 135,  197 => 114,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 199,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 191,  252 => 187,  247 => 187,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 193,  269 => 94,  254 => 190,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 154,  224 => 178,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 108,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 27,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 109,  171 => 106,  166 => 126,  163 => 104,  158 => 94,  156 => 100,  151 => 81,  142 => 78,  138 => 77,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 41,  89 => 20,  85 => 32,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 29,  72 => 38,  69 => 28,  47 => 12,  40 => 6,  37 => 5,  22 => 2,  246 => 188,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 20,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 147,  193 => 113,  189 => 103,  187 => 144,  182 => 130,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 125,  154 => 107,  149 => 87,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 71,  125 => 73,  122 => 48,  116 => 70,  112 => 69,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 50,  80 => 30,  73 => 29,  64 => 13,  60 => 6,  57 => 93,  54 => 92,  51 => 14,  48 => 10,  45 => 8,  42 => 22,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
