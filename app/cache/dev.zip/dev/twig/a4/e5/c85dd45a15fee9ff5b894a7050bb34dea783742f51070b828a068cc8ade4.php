<?php

/* MainRatetradeBundle:Default:mortgage-refinance-city.html.twig */
class __TwigTemplate_a4e5c85dd45a15fee9ff5b894a7050bb34dea783742f51070b828a068cc8ade4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <meta name=\"geo.region\" content=\"CA\" />
        <title>Mortgage Refinance in ";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</title>
          <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
    

          ";
        // line 27
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
      <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Costs of Refinancing in ";
        // line 36
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "?</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">Costs of Refinancing in ";
        // line 40
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "?</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->
</strong></h1>

 <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
                                <p><strong>How Much Will it Cost to Refinance in ";
        // line 61
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "?</strong></p>
                                <p>Refinancing is often chosen as alternative by borrowers to either get a lower interest rate or access the equity out of their home. It is essential to know the cost of refinancing to take a calculated decision for refinancing.</p>
                                <p>Refinancing allows borrowers to access up to 80% of their home’s value less the outstanding balance of their mortgage. For instance, if your home is valued at \$300,000 and you have an outstanding mortgage of \$100,000, then available equity will be 1, 40,000</p>
                                <p>There are mainly two kinds of refinancing viz. refinancing within your term and refinancing at the end of your term. When you choose for refinancing within your term, you can get mortgage at lower rate or can take equity out of your home. If you refinance at the end of the term it would allow you to access equity out of your home. There are several kinds of fees involved in both kinds of refinancing methods such as mortgage payment penalty, mortgage discharge fee, mortgage registration fee, legal fees etc.</p>
                                <p><strong>Mortgage Pre-payment Penalty Charges in ";
        // line 65
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>If refinancing allow you to pay your mortgage before your term is up for renewal, you’ll have to pay a mortgage prepayment penalty fees along with other fees associated with refinancing mortgage. However, if you are refinancing when your mortgage term is up for renewal, you don’t need to bear prepayment penalty. In case of fixed rate mortgage, prepayment penalty will be the greater of: Three months’ interest or the interest rate differential (IRD). In case of variable rate mortgage, your penalty will be interest paid for three months.</p>
                                <p><strong>Mortgage Discharge Fees in ";
        // line 67
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>In case you decide to leave your current lender, you will have to pay a fee to discharge your mortgage from your current lender. Each lender sets his own fee rates, however mortgage discharge fees in Canada typically varies between \$200 and \$350.</p>
                                <p><strong>Mortgage Registration Fees in ";
        // line 69
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>While setting up your loan, your lender will secure it by registering a “charge” against your property. Whether you are leaving or staying with current lender, you will have to pay registration charges in both cases. There are two kinds of charges that can be registered against property; standard and collateral. Mortgage registration fee is usually governed by your provincial government.</p>
                                <p><strong>Legal Fees in ";
        // line 71
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>In order to refinance your mortgage, you need to consult with a proficient lawyer to provide you with right guidance as well as to facilitate the entire transaction. Such lawyer will review the mortgage and its terms and conditions before registering the new mortgage. He will also carry out a title search to assure that there are no leans made against your property. Legal fees for a refinance typically range between \$700 and \$1,000. If you are switching lenders and your mortgage balance is more than \$200,000, your new lender might pay legal fees on your behalf.</p>
                            
                        ";
        // line 74
        if ((twig_length_filter($this->env, (isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities"))) > 0)) {
            echo "<div class=\"reproc\">
                            <h3>Mortgage Refinance in your City</h3>
                      
                                 ";
            // line 77
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities")));
            foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
                // line 78
                echo "                                        <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_refinance", array("city" => $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"))), "html", null, true);
                echo "\">
                                            ";
                // line 79
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "
                                        </a>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 82
            echo "                                 ";
        }
        // line 83
        echo "                    </div></div></div>

                        </div>
                    <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                               
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
  ";
        // line 98
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "6")) {
            // line 99
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 101
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 103
        echo "                                    
                                        
                                                         
                                                            ";
        // line 106
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 107
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 108
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 109
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 111
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 113
                echo "                                                                    ";
            }
            // line 114
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                             ";
        // line 121
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "18")) {
            // line 122
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 124
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 126
        echo "                                    
                                        
                                        ";
        // line 128
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 129
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 130
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 131
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 133
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 135
                echo "                                                                    ";
            }
            // line 136
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 137
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    ";
        // line 142
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "1")) {
            // line 143
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 145
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 147
        echo "                                    
                                        
                                       ";
        // line 149
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 150
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 151
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 152
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 154
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 156
                echo "                                                                    ";
            }
            // line 157
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 158
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Mortgage Information</a>
                             ";
        // line 163
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "47")) {
            // line 164
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 166
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 168
        echo "                                    
                                        
                                       ";
        // line 170
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 171
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "47")) {
                // line 172
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 173
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 175
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 177
                echo "                                                                    ";
            }
            // line 178
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 179
        echo "                                    </ul>
                                </li>


                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
                                                     </aside>
                    <!-- /SIDEBAR -->
</div></div></section>
                     <!-- FOOTER -->
      ";
        // line 191
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo " 

        <script>

            function validateEmail(email) {
                var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                return re.test(email);
            }

            \$(document).on(\"click\", \".subsc\", function(e) {
                e.preventDefault();
                \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                if (\$(\"#exampleInputEmail2\") == '')
                {
                    \$(\"#exampleInputEmail2\").focus();
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                {
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                    \$(\"#exampleInputEmail2\").focus();
                }
                else {
                    \$.ajax({
                        url: '";
        // line 216
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                        type: \"post\",
                        async: true,
                        data: {'email': \$(\"#exampleInputEmail2\").val(),
                            'name': \"testname\"},
                        success: function(response) {
                            \$(\"#exampleInputEmail2\").val('');
                            alert(response);
                        },
                        error: function(request, error) {
                            // alert('No data found');
                        }
                    });
                }
            });

            \$('.locations').on('click', function() {

                \$('.location-name-box').toggle(500);
            });
            \$('.level1Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level1 ul').toggle(500);
            });
            \$('.level2Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level2 ul').toggle(500);
            });
            \$('.level3Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level3 ul').toggle(500);
            });
        </script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:mortgage-refinance-city.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  465 => 216,  361 => 157,  332 => 149,  328 => 147,  320 => 143,  276 => 128,  272 => 126,  245 => 113,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 231,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 210,  492 => 203,  484 => 201,  410 => 173,  397 => 165,  388 => 170,  380 => 166,  366 => 157,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 199,  442 => 237,  417 => 178,  372 => 159,  336 => 150,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 255,  509 => 207,  482 => 240,  386 => 195,  357 => 182,  353 => 180,  344 => 199,  339 => 151,  335 => 175,  329 => 174,  321 => 171,  610 => 410,  462 => 192,  394 => 239,  370 => 186,  364 => 204,  349 => 212,  340 => 143,  325 => 172,  319 => 194,  304 => 185,  295 => 179,  289 => 176,  280 => 129,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 228,  531 => 226,  516 => 319,  476 => 204,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 128,  303 => 123,  292 => 127,  288 => 114,  510 => 235,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 196,  411 => 194,  389 => 184,  378 => 181,  311 => 137,  708 => 448,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 252,  483 => 226,  452 => 227,  448 => 226,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 41,  277 => 141,  521 => 214,  513 => 253,  508 => 216,  499 => 248,  495 => 247,  489 => 229,  472 => 203,  396 => 202,  392 => 171,  377 => 188,  356 => 202,  352 => 201,  348 => 149,  192 => 74,  883 => 685,  699 => 504,  449 => 239,  432 => 222,  428 => 180,  414 => 177,  406 => 175,  403 => 244,  399 => 203,  390 => 216,  376 => 164,  373 => 191,  369 => 158,  265 => 161,  261 => 104,  253 => 161,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 263,  535 => 227,  527 => 313,  524 => 298,  520 => 254,  505 => 250,  497 => 301,  494 => 231,  479 => 239,  475 => 238,  467 => 288,  458 => 196,  454 => 208,  450 => 194,  446 => 238,  184 => 82,  180 => 106,  172 => 104,  160 => 74,  152 => 30,  937 => 621,  809 => 496,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 218,  530 => 292,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 295,  477 => 270,  471 => 289,  463 => 242,  460 => 191,  456 => 228,  445 => 257,  441 => 268,  433 => 203,  429 => 185,  424 => 254,  420 => 228,  416 => 252,  412 => 251,  385 => 233,  382 => 277,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 297,  529 => 295,  525 => 215,  517 => 254,  511 => 304,  503 => 206,  500 => 205,  496 => 243,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 276,  451 => 224,  447 => 185,  443 => 192,  439 => 260,  434 => 231,  426 => 214,  422 => 178,  400 => 242,  395 => 172,  114 => 37,  260 => 189,  256 => 103,  248 => 114,  266 => 193,  262 => 121,  250 => 189,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 111,  275 => 194,  271 => 193,  267 => 137,  263 => 191,  259 => 158,  255 => 155,  239 => 185,  81 => 22,  65 => 18,  1085 => 1059,  210 => 101,  198 => 103,  194 => 133,  190 => 41,  186 => 131,  178 => 35,  150 => 41,  146 => 79,  134 => 24,  124 => 72,  104 => 67,  391 => 164,  383 => 214,  375 => 313,  371 => 159,  367 => 158,  363 => 157,  359 => 156,  351 => 179,  347 => 153,  188 => 36,  301 => 173,  293 => 151,  113 => 90,  174 => 34,  170 => 78,  148 => 29,  77 => 21,  231 => 130,  165 => 106,  161 => 105,  153 => 92,  195 => 96,  191 => 95,  34 => 8,  155 => 27,  310 => 188,  306 => 145,  302 => 135,  290 => 126,  286 => 131,  282 => 143,  274 => 153,  270 => 194,  251 => 139,  237 => 111,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 79,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 107,  215 => 151,  211 => 124,  207 => 58,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 152,  350 => 154,  346 => 220,  342 => 152,  338 => 165,  334 => 142,  330 => 163,  326 => 165,  318 => 142,  206 => 99,  244 => 174,  236 => 133,  232 => 85,  228 => 84,  216 => 79,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 25,  53 => 15,  127 => 33,  97 => 62,  76 => 19,  58 => 26,  480 => 162,  474 => 198,  469 => 284,  461 => 155,  457 => 241,  453 => 186,  444 => 184,  440 => 224,  437 => 191,  435 => 186,  430 => 257,  427 => 260,  423 => 179,  413 => 226,  409 => 132,  407 => 205,  402 => 130,  398 => 173,  393 => 197,  387 => 215,  384 => 168,  381 => 182,  379 => 230,  374 => 163,  368 => 205,  365 => 189,  362 => 156,  360 => 203,  355 => 215,  341 => 105,  337 => 103,  322 => 214,  314 => 177,  312 => 136,  309 => 135,  305 => 136,  298 => 172,  294 => 133,  285 => 89,  283 => 130,  278 => 195,  268 => 124,  264 => 122,  258 => 97,  252 => 187,  247 => 88,  241 => 159,  229 => 109,  220 => 81,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 28,  61 => 17,  273 => 140,  269 => 94,  254 => 115,  243 => 86,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 106,  217 => 122,  208 => 165,  204 => 98,  179 => 33,  159 => 139,  143 => 37,  135 => 35,  119 => 31,  102 => 34,  71 => 12,  67 => 29,  63 => 22,  59 => 27,  201 => 77,  196 => 75,  183 => 100,  171 => 31,  166 => 77,  163 => 29,  158 => 30,  156 => 100,  151 => 26,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 67,  91 => 24,  62 => 27,  49 => 14,  87 => 16,  28 => 8,  94 => 35,  89 => 27,  85 => 14,  75 => 31,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 56,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 32,  72 => 13,  69 => 19,  47 => 24,  40 => 10,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 92,  139 => 65,  131 => 34,  123 => 32,  120 => 71,  115 => 30,  111 => 29,  108 => 40,  101 => 36,  98 => 36,  96 => 37,  83 => 33,  74 => 30,  66 => 28,  55 => 26,  52 => 12,  50 => 24,  43 => 23,  41 => 12,  35 => 8,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 44,  189 => 103,  187 => 83,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 92,  162 => 50,  154 => 71,  149 => 69,  147 => 25,  144 => 67,  141 => 91,  133 => 95,  130 => 23,  125 => 93,  122 => 39,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 27,  99 => 26,  95 => 25,  92 => 57,  86 => 33,  82 => 32,  80 => 20,  73 => 20,  64 => 20,  60 => 19,  57 => 16,  54 => 25,  51 => 25,  48 => 11,  45 => 13,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
