<?php

/* MainRatetradeBundle:Default:header.html.twig */
class __TwigTemplate_4db1ef72cefbf495cb17bf9be6fc7d02213f6c4b3e373ed384d37eff93571ba6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<meta name=\"google-site-verification\" content=\"zx9fSFiZQfKEzrajSkrtYFWSUyLVyHgogGpE0bpWCmo\" />
<!-- Global site tag (gtag.js) - Google Analytics -->
";
        // line 8
        echo "
";
        // line 11
        echo "
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src=\"https://www.googletagmanager.com/gtag/js?id=G-DCHW5GT57B\"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-DCHW5GT57B');
</script>

<script type=\"application/ld+json\">
{ \"@context\" : \"http://schema.org\",
  \"@type\" : \"RateTrade.ca\",
  \"name\" : \"RateTrade\",
  \"url\" : \"https://www.ratetrade.ca/\",
  \"sameAs\" : [\"https://www.facebook.com/ratetrade\",
    \"https://twitter.com/ratetrade\",
    \"https://www.linkedin.com/company/ratetrade\"]
}
</script>
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js\"></script>
 <meta http-equiv=\"Cache-control\" content=\"public\">
</head>
<body id=\"home\" class=\"wide\">

<!-- WRAPPER -->
<div class=\"wrapper\">
<div class=\"topbbar\"> <ul class=\"social-icons\">
                                        
                                    </ul></div>
    <!-- HEADER -->
    <header class=\"header fixed\">
        <div class=\"header-wrapper\">
            <div class=\"container\">

                <!-- Logo -->
                <div class=\"logo\">
                    <a href=\"https://www.ratetrade.ca\"><img src=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/img/logo.png"), "html", null, true);
        echo "\" alt=\"Ratetrade Mortgage Rates in Canada\"/></a>
                </div>
                <!-- /Logo -->

                <!-- Mobile menu toggle button -->
                <a href=\"#\" class=\"menu-toggle btn ripple-effect btn-theme-transparent\"><i class=\"fa fa-bars\"></i></a>
                <!-- /Mobile menu toggle button -->

                <!-- Navigation -->
                <nav class=\"navigation closed clearfix\">
                    <div class=\"swiper-wrapper\">
                        <div class=\"swiper-slide\">
                            <!-- navigation menu -->
                            <a href=\"#\" class=\"menu-toggle-close btn\"><i class=\"fa fa-times\"></i></a>
                            <ul class=\"nav sf-menu\">
                                <li class=\"active\"><a href=\"https://www.ratetrade.ca\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a></li>
                                <li><a href=\"#\"><i class=\"fa fa-calculator\" aria-hidden=\"true\"></i> Mortgage</a>
                                   <ul>
<li><a href=\"https://ratetrade.ca/bank-mortgage-rates\"><i class=\"fa fa-university\" aria-hidden=\"true\"></i> Bank Mortgage Rates</a></li>
                                     <li><a href=\"#\"><i class=\"fa fa-calculator\" aria-hidden=\"true\"></i> Calculators</a>
                                          <ul>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-payment-calculator\">Mortgage Payment</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/payment-analyzer-calculator\">Payment Analyzer</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/income-calculator\">Income Calculator</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-affordability\">Mortgage Affordability</a></li>
                                        
                                             <li><a href=\"https://www.ratetrade.ca/land-transfer-tax\">Land Transfer Tax</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-refinance-calculator\">Refinance Calculator</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-refinance-equity\">Refinance Equity</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-refinance-penalty\">Refinance Penalty</a></li>
                                             
                                          </ul>
                                     </li>   
                                
        \t\t\t     <li><a href=\"https://www.ratetrade.ca/buying-home-canada\"><i class=\"fa fa-book\"></i> Home Buying Process</a>
                                          <ul>
    <li><a href=\"https://www.ratetrade.ca/creditworthiness\">Credit Worthiness</a></li>
     <li><a href=\"https://www.ratetrade.ca/mortgage-affordability-rules\">Mortgage Affordability Rules</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-down-payment\">Mortgage Down Payment</a></li>

 <li><a href=\"https://www.ratetrade.ca/mortgage-default-insurance\">Mortgage Default Insurance</a></li>
   <li><a href=\"https://www.ratetrade.ca/mortgage-payment-frequency\">Mortgage Payment Frequency</a></li>

 <li><a href=\"#\">Steps to get the key to your dream house</a>
<ul>
<li><a href=\"https://www.ratetrade.ca/tax-credit-first-time-home-buyers\">First Time Home Buyers</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/home-buying-process\">Home Buying Process</a></li>
</ul>
</li>

  <li><a href=\"https://www.ratetrade.ca/land-transfer-tax-rebate\">Land Transfer Tax Rebate</a>
<ul>
<li><a href=\"https://www.ratetrade.ca/closing-cost-overview\">Closing Cost</a></li>
</ul>

</li> 
     <li><a href=\"https://www.ratetrade.ca/registered-requirement-saving-plan\">R R S P</a></li>
                                             
                                     
                                          </ul>
                                     </li>  
 
        \t\t\t     <li><a href=\"https://www.ratetrade.ca/renewing-guide\"><i class=\"fa fa-book\"></i> Renewing Your Mortgage</a>
                                          <ul>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-renewal-process\">Mortgage Renewal Process</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/early-mortgage-renewal\">Early Mortgage Renewal</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/mortgage-renewal-denial-situations-impact\">Renewal Denial Situations</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/switching-lenders\">Switching Lenders</a></li>
                                          </ul>
                                     </li>   
        \t\t\t     <li><a href=\"https://www.ratetrade.ca/mortgage-refinancing-guide\"><i class=\"fa fa-book\"></i> Mortgage Refinancing Guide</a>
                                          <ul>
                                             <li><a href=\"https://www.ratetrade.ca/reasons-to-refinance\">Reasons to Refinance</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/blended-mortgage\">Blended Mortgage</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/home-equity-line-of-credit\">Home Equity Line of Credit</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/cost-to-refinance\">Cost to Refinance?</a></li>
                                             <li><a href=\"https://www.ratetrade.ca/disadvantages-of-mortgage-refinancing\">Disadvantages</a></li>
                                          </ul>
                                     </li>
<li><a href=\"https://www.ratetrade.ca/mortgage-information-center\"><i class=\"fa fa-book\"></i> Mortgage Information Center</a>
                                          <ul>
                                                <li><a href=\"https://www.ratetrade.ca/gross-debt-ratio\">Gross Debt Ratio</a></li>
                                            </ul>
                                     </li>     
                                   </ul>    
                                </li>
                                <li><a href=\"#\"><i class=\"fa fa-podcast\" aria-hidden=\"true\"></i> Insurance</a>
                               </li>                                           
                            </ul>
                            <!-- /navigation menu -->
                        </div>
                    </div>
                    <!-- Add Scroll Bar -->
                    <div class=\"swiper-scrollbar\"></div>
                </nav>
                <!-- /Navigation -->

            </div>
        </div>

    </header>
    <!-- /HEADER -->";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 49,  26 => 11,  23 => 8,  19 => 1,);
    }
}
