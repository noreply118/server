<?php

/* AcmeDemoBundle:Demo:affordability-ca-oldl.html.twig */
class __TwigTemplate_7cced225b6e77db3d667c27f7c4b7dc610513fb8ff6fa570ec114e1da075dcb7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<html>
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/aff-cal.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/aff-style.css"), "html", null, true);
        echo "\">
<div id=\"affordability-calc\" class=\"mortgage-calc\">
<div class=\"mr-calc-wrapper\">
\t<div class=\"mr-calc-tabs\">
\t\t<div class=\"mr-holder first selected\">
\t\t\t<h2><a class=\"input\" href=\"#\">Inputs</a></h2>
\t\t</div>
\t\t<div class=\"mr-holder\">
\t\t\t<h2><a class=\"output\" href=\"#\">Affordability</a></h2>
\t\t</div>
\t\t<span class=\"social-icons affordability-calc\">
\t\t</span>
\t</div>
\t<div class=\"mr-calc-block\">
\t\t<form style=\"display: block;\" class=\"ng-pristine ng-valid\" id=\"afford-input\">
\t\t<!--
\t\t\t<div class=\"how-much\">How much can I afford?</div>
\t\t\t<div class=\"how-much-desc\">Enter your personal financial information in the fields below.</div>
\t\t -->
\t\t<table>
\t\t\t<tbody>
                                    <tr>
\t\t\t\t\t<th colspan=\"3\"><h3>Annual Income</h3></th>
\t\t\t\t\t<th colspan=\"3\"><h3>Monthly Living Costs</h3></th>
\t\t\t\t\t<th class=\"estimate\">Estimate for me</th>
\t\t\t\t    </tr>
\t\t\t\t<tr>
\t\t\t\t\t<td><label for=\"annual_income\">Annual Income:</label><br><span class=\"clarification\">Before Tax</span></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"annual_income\" tabindex=\"1\" type=\"text\"></td>

\t\t\t\t\t<td><label for=\"prop_tax\">Property Tax:</label></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"prop_tax\" tabindex=\"6\" type=\"text\"></td>
\t\t\t\t\t<td class=\"estimate\"><input id=\"est_prop_tax\" type=\"checkbox\"></td>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<td><label for=\"co_income\">Co-Applicant Income:</label><br><span class=\"clarification\">Before Tax</span></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"co_income\" tabindex=\"2\" type=\"text\"></td>

\t\t\t\t\t<td><label for=\"condo_fees\">Condo Fees:</label></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"condo_fees\" tabindex=\"7\" type=\"text\"></td>
\t\t\t\t\t<td class=\"estimate\"><input id=\"est_condo_fees\" type=\"checkbox\"></td>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<td colspan=\"3\"></td>

\t\t\t\t\t<td><label for=\"heating\">Heating Costs:</label></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"heating\" tabindex=\"8\" type=\"text\"></td>
\t\t\t\t\t<td class=\"estimate\"><input id=\"est_heating\" type=\"checkbox\"></td>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<th colspan=\"3\"><h3>Monthly debt payments</h3></th>
                                        <th colspan=\"2\"><h3>Profile</h3></th>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<td><label for=\"credit_card\">Credit Card:</label></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"credit_card\" tabindex=\"3\" type=\"text\"></td>
                                        <td></td>
                                        <td>
                                            <select id=\"province\" name=\"province\" >
\t\t                                  <option value=\"AL\">Alberta</option>
\t\t                                  <option value=\"BC\">British Columbia</option>
                                                  <option value=\"MA\">Manitoba</option>
                                                  <option value=\"NB\">New Brunswick</option>
                                                  <option value=\"NE\">Newfoundland</option>
\t\t\t\t                  <option value=\"NS\">Nova Scotia</option>
                                                  <option value=\"NT\">Northwest Territories</option>
\t\t\t\t                  <option value=\"NU\">Nunavut</option>
                                                  <option value=\"ON\" selected=\"selected\">Ontario</option>
                                                  <option value=\"PE\">Prince Edward Island</option>
                                                  <option value=\"QU\">Quebec</option>
\t\t\t\t                  <option value=\"SK\">Saskatchewan</option>
\t\t\t\t                  <option value=\"YU\">Yukon</option>\t\t\t\t
\t\t\t                    </select>
                                        </td>
                                        <td>
                                            <select id=\"city\">
                                                <option value=\"select\">Select City</option>
                                            </select>
                                        </td>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<td><label for=\"car_payment\">Car Payment:</label></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"car_payment\" tabindex=\"4\" type=\"text\"></td>
                                        <td class=\"afford-submit\" colspan=\"4\" rowspan=\"2\">
\t\t\t\t\t\t<a href=\"#\" tabindex=\"9\" ><span>How much can I afford?</span></a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t<tr>
\t\t\t\t\t<td><label for=\"loans\">Other Loan Expenses:</label></td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td><input class=\"text\" id=\"loans\" tabindex=\"5\" type=\"text\"></td>
\t\t\t\t</tr>
\t\t\t</tbody>
                    </table>
\t\t</form>
\t\t
            <form class=\"ng-pristine ng-valid\" id=\"afford-output\" style=\"display: none;\">
\t\t\t<table class=\"mr-calc-main\">
\t\t\t\t<thead>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td colspan=\"3\"></td>
\t\t\t\t\t\t<th class=\"max-afford\">Max. Affordability&nbsp;  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Maximum Affordability      </span>
      <span class=\"rh-content\">
This is the maximum home price you can afford based on your income (or combined income) and expenses. Your maximum affordability is also constrained by the Qualifying Mortgage Rate set by the Bank of Canada. The Qualifying rate requires you to qualify for a 5-year fixed mortgage rate if you seek a variable mortgage or a mortgage with a lesser term. This is mandated to ease affordability concerns if interest rates rise in the future.      </span>
  </span>

</th>
\t\t\t\t\t\t<th class=\"build-own\">Build Your Own&nbsp;  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Build Your Own      </span>
      <span class=\"rh-content\">
Modify the inputs below to see how your affordability changes with a different down payment amount, amortization period and/or mortgage rate.      </span>
  </span>

</th>
\t\t\t\t\t\t<th class=\"tips\">Tips</th>
\t\t\t\t\t</tr>
\t\t\t\t</thead>
\t\t\t\t<tbody class=\"purchase\" style=\"\">
\t\t\t\t\t<tr class=\"home-price\">
\t\t\t\t\t\t<td class=\"col01\" colspan=\"2\">
\t\t\t\t\t\t\t<h3>Home Price</h3>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t<td class=\"col4\">\$6,375,374</td>
\t\t\t\t\t\t<td class=\"col4\">\$-</td>
\t\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t\t<div></div>
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr class=\"downpayment percent\">
\t\t\t\t\t\t<td class=\"col1\" rowspan=\"2\"><strong>Down payment</strong></td>
\t\t\t\t\t\t<td class=\"col2\" rowspan=\"2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Down payment      </span>
      <span class=\"rh-content\">
The amount of money you pay up front to obtain a mortgage. The minimum down payment in Canada is 5%. For down payments of less than 20%, home buyers are required to purchase mortgage default insurance, commonly referred to as CMHC insurance.      </span>
  </span>

</td>
\t\t\t\t\t\t<td class=\"col3\"></td>
\t\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t\t<input name=\"dp_pc[]\" value=\"20 %\" type=\"hidden\">
\t\t\t\t\t\t\t<div class=\"text\">20 %</div>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t\t<input name=\"dp_pc[]\" value=\"\" type=\"hidden\">
\t\t\t\t\t\t\t<div class=\"text\"></div>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td class=\"col5\" rowspan=\"2\">
\t\t\t\t\t\t\t<div><a href=\"#\" id=\"QuickTip_CTv6a\" class=\"money-tip cboxElement\"><img src=\"http://www.mortgage.ca/images/money-tip.png\"></a>
<div style=\"display:none\">
\t<div id=\"hbp-tip\" class=\"mortgage quick-tip-dialog\">
\t\t<h3><span class=\"quick-tip\">Quick Tip</span>Put Your RRSP Towards Your Down Payment</h3>
<hr>
<div class=\"tip-section\">
<h4>Canada's Home Buyers' plan allows you to put \$25,000 from your RRSP towards your down payment, tax-free!</h4>
<ul>
<li>You must be a first time home buyer </li>
<li>You must pay it back over 15 years</li>
<li>If you are purchasing the house with a co-applicant, each of you can withdraw \$25,000 for a total of \$50,000.</li>
</ul>
</div>
<div class=\"tip-section\">
<h4>Down payment basics</h4>
<ul>
<li>Minimum down payment in Canada is 5%</li>
<li>Down payments between 5% to 19.99% incur CMHC insurance</li>
</ul>
</div>
<div class=\"tip-section\">
<h4>How do larger down payments save you money?</h4>
<ul>
<li>Lowers CMHC insurance</li>
<li>Decreases total interest paid over the life of your mortgage</li>
</ul>
</div>
\t</div>
</div>

</div>
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr class=\"downpayment alt\">
\t\t\t\t\t\t<td class=\"col3\"><span class=\"ico-minus\">minus</span></td>
\t\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t\t<input name=\"dp_dol[]\" value=\"\$1,275,075\" type=\"hidden\">
\t\t\t\t\t\t\t<div class=\"text\">\$1,275,075</div>
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t\t<label for=\"dp_dol2\" class=\"accessible\">Down payment (\$)</label>
\t\t\t\t\t\t\t<input id=\"dp_dol2\" name=\"dp_dol[]\" class=\"text\" type=\"text\">
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr class=\"cmhc\">
\t\t\t\t\t\t<td class=\"col1\"><strong>CMHC insurance</strong></td>
\t\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
CMHC insurance      </span>
      <span class=\"rh-content\">
Mortgage default insurance, commonly referred to as CMHC insurance, protects the lender in the case the borrower defaults on the mortgage. Mortgage default insurance is required on all mortgages with down payments of less than 20%, which are known as high ratio mortgages. Mortgage default insurance is calculated as a percentage applied to your mortgage amount.      </span>
  </span>

</td>
\t\t\t\t\t\t<td class=\"col3\"><span class=\"ico-plus\">plus</span></td>
\t\t\t\t\t\t<td class=\"col4\">\$0</td>
\t\t\t\t\t\t<td class=\"col4\"></td>
\t\t\t\t\t\t<td class=\"col5\"><a href=\"#\" id=\"QuickTip_n9IHt\" class=\"money-tip cboxElement\"><img src=\"http://www.mortgage.ca/images/money-tip.png\"></a>
<div style=\"display:none\">
\t<div id=\"cmhc-tip\" class=\"mortgage quick-tip-dialog\">
\t\t<h3><span class=\"quick-tip\">Quick Tip</span>Determining Your Mortgage Default Insurance Percentage</h3>
<hr>
<div style=\"float: left; width: 49%;\">
<div class=\"tip-section\">
<h4>What is mortgage default insurance?</h4>
<p>Mortgage default insurance is mandatory in Canada for down payments between 5%, the  minimum in Canada and 19.99%. Mortgage default  insurance, or CMHC insurance, protects lenders if a home owner defaults on their mortgage.</p>
</div>
</div>
<div style=\"float: right; width: 49%;\">
<div class=\"tip-section\">
<h4>Mortgage default insurance facts</h4>
<ul>
<li>Mandatory for down payments of less than 20%</li>
<li>Decreases with a larger down payment</li>
<li>Maximum amortization period on an insured mortgage is 25 years</li>
</ul>
</div>
</div>
<table class=\"cmhc-table\" cellspacing=\"0\">
<tbody>
<tr>
</tr>
<tr>
<th rowspan=\"2\">Amortization period</th> <th style=\"width: 16%; text-align: center;\" colspan=\"4\">Down payment (% of home)</th>
</tr>
<tr>
<td style=\"width: 16%; text-align: center;\"><strong>5% - 9.99%</strong></td>
<td style=\"width: 16%; text-align: center;\"><strong>10% - 14.99%</strong></td>
<td style=\"width: 16%; text-align: center;\"><strong>15% - 19.99%</strong></td>
<td style=\"width: 16%; text-align: center;\"><strong>20% +</strong></td>
</tr>
<tr class=\"alternate\">
<th>25 years or less</th>
<td style=\"text-align: right;\">2.75%</td>
<td style=\"text-align: right;\">2.00%</td>
<td style=\"text-align: right;\">1.75%</td>
<td style=\"text-align: right;\">0.00%</td>
</tr>
</tbody>
</table>
\t</div>
</div>

</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr class=\"total\">
\t\t\t\t\t\t<td class=\"rh-col\" colspan=\"2\"><strong>Total Mortgage Required</strong></td>
\t\t\t\t\t\t<td class=\"col3\"><span class=\"ico-well\">equals</span></td>
\t\t\t\t\t\t<td class=\"col4\">\$5,100,299</td>
\t\t\t\t\t\t<td class=\"col4 last\">\$-</td>
\t\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t\t<div></div>
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t</tbody>
\t\t\t\t<tbody><tr class=\"amortization\">
\t\t\t\t\t<td class=\"col1\"><strong>Amortization period</strong></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Amortization period      </span>
      <span class=\"rh-content\">
The length of time it will take a homeowner to pay off his/her mortgage. In Canada, the maximum amortization period is 25 years. Longer amortization periods allow homeowners to make smaller monthly payments, but equate to more interest paid over the life of the mortgage.      </span>
  </span>

</td>
\t\t\t\t\t<td class=\"col3\">&nbsp;</td>
\t\t\t\t\t<td class=\"col4\"><input name=\"amort[]\" value=\"30\" type=\"hidden\">30 years</td>
\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t<label for=\"amort2\" class=\"accessible\">Amortization period</label>
\t\t\t\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 112px;\" id=\"s2id_amort2\" class=\"select2-container\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-1\" class=\"select2-chosen\">
\t\t\t\tSelect\t\t\t</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen1\" class=\"select2-offscreen\">Amortization period</label><input id=\"s2id_autogen1\" aria-labelledby=\"select2-chosen-1\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"><div class=\"select2-drop select2-display-none\">   <div class=\"select2-search select2-search-hidden select2-offscreen\">       <label for=\"s2id_autogen1_search\" class=\"select2-offscreen\">Amortization period</label>       <input placeholder=\"\" id=\"s2id_autogen1_search\" aria-owns=\"select2-results-1\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" class=\"select2-input\" role=\"combobox\" aria-expanded=\"true\" aria-autocomplete=\"list\" type=\"text\">   </div>   <ul id=\"select2-results-1\" class=\"select2-results\" role=\"listbox\">   </ul></div></div><select class=\"select2-offscreen\" title=\"Amortization period\" tabindex=\"-1\" id=\"amort2\" name=\"amort[]\">
\t\t\t<option value=\"\" selected=\"selected\">
\t\t\t\tSelect\t\t\t</option>
\t\t\t\t\t<option value=\"5\">5 years</option>
\t\t\t\t<option value=\"10\">10 years</option>
\t\t\t\t<option value=\"15\">15 years</option>
\t\t\t\t<option value=\"20\">20 years</option>
\t\t\t\t<option value=\"25\">25 years</option>
\t\t\t\t<option value=\"30\">30 years</option>
\t\t\t\t<option value=\"35\">35 years</option>
\t\t\t\t<option value=\"other\">Other</option>
\t\t\t\t</select></span>

\t\t

\t\t
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t<a href=\"#\" id=\"QuickTip_8yilt\" class=\"money-tip cboxElement\"><img src=\"http://www.mortgage.ca/images/money-tip.png\"></a>
<div style=\"display:none\">
\t<div id=\"amortization-tip\" class=\"mortgage quick-tip-dialog\">
\t\t<h3><span class=\"quick-tip\">Quick Tip</span>Maximum Amortization Period 25 Years in Canada</h3>
<hr>
<div class=\"tip-section\">
<h4>What is the difference between term and amortization?</h4>
<ul>
<li>Term is the length of time you commit to the mortgage rate, lender, and associated mortgage terms and conditions</li>
<li>Amortization period is the length of time it will take you to pay off your entire mortgage </li>
</ul>
</div>
<div class=\"tip-section\">
<table style=\"width: 33%; float: right;\" cellspacing=\"0\">
<thead> 
<tr>
<th style=\"text-align: left;\">Amortization</th><th style=\"text-align: right;\">% of Mortgages</th>
</tr>
</thead> 
<tbody>
<tr class=\"alternate\">
<th style=\"text-align: left;\">25 years or less<br></th>
<td style=\"text-align: right;\">58%</td>
</tr>
<tr>
<th style=\"text-align: left;\">30 years<br></th>
<td style=\"text-align: right;\">12%</td>
</tr>
<tr class=\"alternate\">
<th style=\"text-align: left;\">35 years<br></th>
<td style=\"text-align: right;\">30%</td>
</tr>
</tbody>
</table>
<h4>What is the maximum amortization period in Canada?</h4>
<ul>
<li>The maximum amortization period, when purchasing a house with less than 20% down, is 25 years</li>
<li>If purchasing a house with a down payment of 20% of more, some lenders may approve an amortization period of more than 25 years </li>
</ul>
</div>
\t</div>
</div>


\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"mortgage-rate\">
\t\t\t\t\t<td class=\"col1\"><strong>Mortgage rate</strong></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Mortgage rate      </span>
      <span class=\"rh-content\">
The rate of interest you will pay on the outstanding balance of your mortgage. This is determined by the mortgage type and mortgage provider. To see how rates vary by type and provider, click on \"Select Rate\" link on the right.      </span>
  </span>

</td>
\t\t\t\t\t<td class=\"col3\">&nbsp;<br>&nbsp;</td>
\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t<span class=\"rate-value\">2.36 %</span>
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col4\"><span class=\"rate-value\"></span><div class=\"details\"><a class=\"rate-selector\" href=\"#\">Select Rate</a></div></td>
\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t<a href=\"#\" id=\"QuickTip_XrHw7\" class=\"money-tip cboxElement\"><img src=\"http://www.mortgage.ca/images/money-tip.png\"></a>
<div style=\"display:none\">
\t<div id=\"rate-tip\" class=\"mortgage quick-tip-dialog\">
\t\t<h3><span class=\"quick-tip\">Quick Tip</span>Variable vs. Fixed Mortgage Rates</h3>
<hr>
<div class=\"tip-section\">
<h4>Fixed Mortgage Rates</h4>
<p>With a fixed mortgage rate, the mortgage rate and payment you make each  month will stay constant over your mortgage term. 66% of Canadians choose a fixed mortgage rate.</p>
</div>
<div class=\"tip-section\">
<h4>Variable Mortgage Rates</h4>
<p>With a variable mortgage rate, the interest rate you pay will fluctuate with the  prime lending rate as  set by the Bank of Canada. A variable rate will  be quoted as Prime +/- a specificied amount, such a  Prime - 0.85%.  Though the prime rate will fluctuate, the relationship  to prime will  stay constant over your term.</p>
</div>
<p></p><div class=\"chart-wrapper five-year-fixed\">
\t\t\t\t\t\t<h2>Historical variable vs fixed mortgage rates\t\t\t\t\t\t</h2>
\t\t\t\t<div id=\"Chart_lMfNQ\" class=\"rh-chart\" style=\"width:695pxpx;height:330pxpx;\"></div>
\t\t\t<span class=\"caption\">Source: mortgage.ca Mortgage Brokers</span>
\t</div>
<p></p>
\t</div>
</div>


\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"mortgage-type\">
\t\t\t\t\t<td class=\"col1\"><strong>Mortgage type</strong></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Mortgage type      </span>
      <span class=\"rh-content\">
The mortgage type includes the term of the mortgage, between 1-10 years, and the rate type, variable or fixed. The mortgage term is the length of time you commit to the terms, conditions and mortgage rate with a specific lender. The mortgage rate type can be fixed for the duration of the term or variable, fluctuating with the prime rate. Fixed rates are most popular in Canada and represent 66% of all mortgages, according to the Canadian Association of Accredited Mortgage Professionals (CAAMP).      </span>
  </span>

</td>
\t\t\t\t\t<td class=\"col3\">&nbsp;</td>
\t\t\t\t\t<td class=\"col4\">5-Year Fixed</td>
\t\t\t\t\t<td class=\"col4\">&nbsp;</td>
\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t<a href=\"#\" id=\"QuickTip_Tj6RY\" class=\"money-tip cboxElement\"><img src=\"http://www.mortgage.ca/images/money-tip.png\"></a>
<div style=\"display:none\">
\t<div id=\"term-tip\" class=\"mortgage quick-tip-dialog\">
\t\t<h3><span class=\"quick-tip\">Quick Tip</span>5-year Term Most Popular in Canada</h3>
<hr>
<div class=\"tip-section\">
<h4>What is a mortgage term?</h4>
<p>The mortgage term is the length of time you commit to the mortgage rate, lender, and associated mortgage terms and conditions. When the term  is up, you must renew your mortgage on the remaining principle, at a  new rate available at the end of the term.</p>
</div>
<div class=\"tip-section\">
<h4>How does the term influence your mortgage rate?</h4>
<p>The term you choose will have a direct effect on your mortgage rate,  with short terms historically proven to be lower than long-term mortgage  rates. The term acts like a 'reset' button on a mortgage.</p>
</div>
<p></p><div class=\"chart-wrapper \">
\t\t\t\t\t\t<h2>Short term vs long term mortgage rates\t\t\t\t\t\t</h2>
\t\t\t\t<div id=\"Chart_FQDl0\" class=\"rh-chart\" style=\"width:695pxpx;height:400pxpx;\"></div>
\t\t\t<span class=\"caption\">Source: Bank of Canada, 5-year mortgage rate</span>
\t</div>
<p></p>
\t</div>
</div>


\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"total-mortgage-payment\">
\t\t\t\t\t<td colspan=\"1\" class=\"rh-col\"><h4>Total Mortgage Payment</h4></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Mortgage payment      </span>
      <span class=\"rh-content\">
The monthly mortgage payment is calculated based on the inputs you provided: the mortgage amount, rate type (fixed or variable), term, amortization period, and payment frequency. A general affordability rule, as outlined by the Canada Mortgage and Housing Corporation, is that your monthly housing costs should not exceed 32% of your gross household monthly income.      </span>
  </span>

</td>
\t\t\t\t\t<td></td>
\t\t\t\t\t<td class=\"col4\" rowspan=\"1\">
\t\t\t\t\t\t<a href=\"http://www.mortgage.ca/best-ontario-mortgage-rate/5-year/fixed/canwise-financial\" class=\"details active\">
\t\t\t\t\t\t\t<span class=\"amount\">\$19,753</span>
\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t\t<span class=\"get-details\">Pre-approval</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col4\" rowspan=\"1\">
\t\t\t\t\t\t<a class=\"details simple\">
\t\t\t\t\t\t\t<span class=\"amount\">\$-</span>
\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t\t<span class=\"get-details\">Pre-approval</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t<div></div>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t<!--
\t\t\t\t<tr class=\"payment-freq\">
\t\t\t\t\t<td class=\"col1\">
\t\t\t\t\t\t<label for=\"freq\">Frequency</label>
\t\t\t\t\t\t<select id=\"freq\" name=\"freq\">
\t\t\t\t\t\t\t<option value=\"12,1\">Monthly</option>
\t\t\t\t\t\t\t<option value=\"26,1\">Bi-weekly</option>
\t\t\t\t\t\t\t<option value=\"12,2\">Accelerated Bi-weekly</option>
\t\t\t\t\t\t</select>
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col2\"></td>
\t\t\t\t\t<td class=\"col3\"></td>
\t\t\t\t\t<td class=\"col5\">
\t\t\t\t\t\t<div></div>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t-->
\t\t\t\t</tbody><tbody class=\"land-transfer-tax\" style=\"\">
\t\t\t\t<tr class=\"first\">
\t\t\t\t\t<td class=\"rh-col\" colspan=\"3\">
\t\t\t\t\t\t<strong>Land Transfer Tax:</strong>
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col4\">\$247,215</td>
\t\t\t\t\t<td class=\"col4\">
\t\t\t\t\t\t<span>\$-</span>
\t\t\t\t\t</td>
\t\t\t\t\t<td></td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"ltt provincial\">
\t\t\t\t\t<td class=\"col1\"><strong>Provincial:</strong></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Provincial      </span>
      <span class=\"rh-content\">
Land transfer tax (LTT), typically calculated as a percentage of the purchase price of a home, is required when purchasing a home in Canada. All provinces have a LTT, and the amount varies in each province.       </span>
  </span>

</td>
\t\t\t\t\t<td class=\"col3\"><span class=\"ico-plus\">plus</span></td>
\t\t\t\t\t<td class=\"col4\">\$123,982</td>
\t\t\t\t\t<td class=\"col4\"><div>&nbsp;</div></td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"ltt municipal\">
\t\t\t\t\t<td class=\"col1\"><strong>Municipal:</strong></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Municipal      </span>
      <span class=\"rh-content\">
Some municipalities, like Toronto, levy an additional LTT, which is similarly calculated as a percentage of the purchase price of a home.      </span>
  </span>

</td>
\t\t\t\t\t<td class=\"col3\"><span class=\"ico-plus\">plus</span></td>
\t\t\t\t\t<td class=\"col4\">\$123,232</td>
\t\t\t\t\t<td class=\"col4\"><div>&nbsp;</div></td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"ltt rebate\">
\t\t\t\t\t<td class=\"col1\"><strong>Rebate:</strong></td>
\t\t\t\t\t<td class=\"col2\">  <span class=\"mr-tooltip-container top-right\">
    <a title=\"\" data-original-title=\"\" class=\"mr-tooltip\" data-trigger=\"hover\" data-placement=\"top\"><span class=\"fa-stack no-hover\">
      <i class=\"fa fa-circle-thin fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-stack-1x\"></i>
    </span><span class=\"fa-stack is-hover\">
      <i class=\"fa fa-circle fa-stack-2x\"></i>
      <i class=\"fa fa-question fa-inverse fa-stack-1x\"></i>
    </span></a>
      <span class=\"rh-title\">
Rebate      </span>
      <span class=\"rh-content\">
If you are a first-time home buyer in British Columbia or Ontario, you will be eligible for LTT rebates, equal to the value of the LTT up to a maximum amount set by the province.      </span>
  </span>

</td>
\t\t\t\t\t<td class=\"col3\"><span class=\"ico-minus\">minus</span></td>
\t\t\t\t\t<td class=\"col4\">\$0</td>
\t\t\t\t\t<td class=\"col4\"><div>&nbsp;</div></td>
\t\t\t\t</tr>
\t\t\t\t<tr class=\"ltt fees\">
\t\t\t\t\t<td style=\"display: none;\" colspan=\"5\" class=\"col1\"></td>
\t\t\t\t</tr>\t\t\t\t
\t\t\t\t</tbody>
\t\t\t</table>
\t\t\t<table class=\"profile\">
\t\t\t\t<tbody><tr>
\t\t\t\t\t<th>My Profile</th>
\t\t\t\t\t<td>
\t\t\t\t\t\t<label for=\"province\">Province:&nbsp;</label><br>
\t\t\t\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 112px;\" id=\"s2id_mr-calc-province\" class=\"select2-container\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-2\" class=\"select2-chosen\">Ontario</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen2\" class=\"select2-offscreen\"></label><input id=\"s2id_autogen2\" aria-labelledby=\"select2-chosen-2\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"><div class=\"select2-drop select2-display-none select2-with-searchbox\">   <div class=\"select2-search\">       <label for=\"s2id_autogen2_search\" class=\"select2-offscreen\"></label>       <input placeholder=\"\" id=\"s2id_autogen2_search\" aria-owns=\"select2-results-2\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" class=\"select2-input\" role=\"combobox\" aria-expanded=\"true\" aria-autocomplete=\"list\" type=\"text\">   </div>   <ul id=\"select2-results-2\" class=\"select2-results\" role=\"listbox\">   </ul></div></div><select class=\"select2-offscreen\" title=\"\" tabindex=\"-1\" id=\"mr-calc-province\" name=\"province\">
\t\t\t<option value=\"\">
\t\t\t\tPlease select\t\t\t</option>
\t\t\t\t\t<option value=\"BC\">British Columbia</option>
\t\t\t\t<option value=\"AB\">Alberta</option>
\t\t\t\t<option value=\"SK\">Saskatchewan</option>
\t\t\t\t<option value=\"MB\">Manitoba</option>
\t\t\t\t<option value=\"ON\" selected=\"selected\">Ontario</option>
\t\t\t\t<option value=\"QC\">Quebec</option>
\t\t\t\t<option value=\"NB\">New Brunswick</option>
\t\t\t\t<option value=\"NS\">Nova Scotia</option>
\t\t\t\t<option value=\"PE\">Prince Edward Island</option>
\t\t\t\t<option value=\"NL\">Newfoundland</option>
\t\t\t\t<option value=\"YK\">Yukon</option>
\t\t\t\t<option value=\"NT\">Northwest Territories</option>
\t\t\t\t<option value=\"NU\">Nunavut</option>
\t\t\t\t</select></span>
\t\t
\t\t
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<label for=\"city\">City:&nbsp;</label><br>
\t\t\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 112px;\" id=\"s2id_mr-calc-city\" class=\"select2-container\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-3\" class=\"select2-chosen\">Toronto</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen3\" class=\"select2-offscreen\"></label><input id=\"s2id_autogen3\" aria-labelledby=\"select2-chosen-3\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"><div class=\"select2-drop select2-display-none select2-with-searchbox\">   <div class=\"select2-search\">       <label for=\"s2id_autogen3_search\" class=\"select2-offscreen\"></label>       <input placeholder=\"\" id=\"s2id_autogen3_search\" aria-owns=\"select2-results-3\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" class=\"select2-input\" role=\"combobox\" aria-expanded=\"true\" aria-autocomplete=\"list\" type=\"text\">   </div>   <ul id=\"select2-results-3\" class=\"select2-results\" role=\"listbox\">   </ul></div></div><select title=\"\" tabindex=\"-1\" id=\"mr-calc-city\" name=\"\" class=\"select2-offscreen\"><option value=\"\">Please select</option><option value=\"aberarder\">Aberarder</option><option value=\"abitibi-canyon\">Abitibi Canyon</option><option value=\"acton\">Acton</option><option value=\"adolphustown\">Adolphustown</option><option value=\"ailsa-craig\">Ailsa Craig</option><option value=\"ajax\">Ajax</option><option value=\"alban\">Alban</option><option value=\"alderville-first-nation\">Alderville First Nation</option><option value=\"alexandria\">Alexandria</option><option value=\"alfred\">Alfred</option><option value=\"algoma-mills\">Algoma Mills</option><option value=\"alliston\">Alliston</option><option value=\"almonte\">Almonte</option><option value=\"alvinston\">Alvinston</option><option value=\"amherstburg\">Amherstburg</option><option value=\"ancaster\">Ancaster</option><option value=\"angus\">Angus</option><option value=\"apsley\">Apsley</option><option value=\"arden\">Arden</option><option value=\"arkell\">Arkell</option><option value=\"arkona\">Arkona</option><option value=\"armstrong\">Armstrong</option><option value=\"arnprior\">Arnprior</option><option value=\"arthur\">Arthur</option><option value=\"athens\">Athens</option><option value=\"atikokan\">Atikokan</option><option value=\"attawapiskat\">Attawapiskat</option><option value=\"atwood\">Atwood</option><option value=\"auburn\">Auburn</option><option value=\"aurora\">Aurora</option><option value=\"avonmore\">Avonmore</option><option value=\"aylmer\">Aylmer</option><option value=\"ayr\">Ayr</option><option value=\"ayton\">Ayton</option><option value=\"azilda\">Azilda</option><option value=\"baden\">Baden</option><option value=\"bailieboro\">Bailieboro</option><option value=\"bala\">Bala</option><option value=\"balmertown\">Balmertown</option><option value=\"baltimore\">Baltimore</option><option value=\"bancroft\">Bancroft</option><option value=\"barrie\">Barrie</option><option value=\"barrys-bay\">Barry's Bay</option><option value=\"barwick\">Barwick</option><option value=\"batawa\">Batawa</option><option value=\"batchawana-bay\">Batchawana Bay</option><option value=\"bath\">Bath</option><option value=\"bayfield\">Bayfield</option><option value=\"baysville\">Baysville</option><option value=\"beachburg\">Beachburg</option><option value=\"beachville\">Beachville</option><option value=\"beamsville\">Beamsville</option><option value=\"beardmore\">Beardmore</option><option value=\"bearskin-lake\">Bearskin Lake</option><option value=\"bearskin-lake-first-nation\">Bearskin Lake First Nation</option><option value=\"bears-passage\">Bear's Passage</option><option value=\"beaverton\">Beaverton</option><option value=\"beeton\">Beeton</option><option value=\"belle-river\">Belle River</option><option value=\"belleville\">Belleville</option><option value=\"belmont\">Belmont</option><option value=\"bethany\">Bethany</option><option value=\"bethesda\">Bethesda</option><option value=\"big-trout-lake\">Big Trout Lake</option><option value=\"binbrook\">Binbrook</option><option value=\"birch-island\">Birch Island</option><option value=\"biscotasing\">Biscotasing</option><option value=\"blackstock\">Blackstock</option><option value=\"blenheim\">Blenheim</option><option value=\"blezard-valley\">Blezard Valley</option><option value=\"blind-river\">Blind River</option><option value=\"bloomfield\">Bloomfield</option><option value=\"blyth\">Blyth</option><option value=\"bobcaygeon\">Bobcaygeon</option><option value=\"bolton\">Bolton</option><option value=\"bonfield\">Bonfield</option><option value=\"borden\">Borden</option><option value=\"bothwell\">Bothwell</option><option value=\"bourget\">Bourget</option><option value=\"bowmanville\">Bowmanville</option><option value=\"bracebridge\">Bracebridge</option><option value=\"bradford\">Bradford</option><option value=\"bradford-west-gwillimbury\">Bradford West Gwillimbury</option><option value=\"braeside\">Braeside</option><option value=\"brampton\">Brampton</option><option value=\"brantford\">Brantford</option><option value=\"brechin\">Brechin</option><option value=\"breslau\">Breslau</option><option value=\"bridgenorth\">Bridgenorth</option><option value=\"brigden\">Brigden</option><option value=\"bright\">Bright</option><option value=\"brighton\">Brighton</option><option value=\"brights-grove\">Brights Grove</option><option value=\"britt\">Britt</option><option value=\"brockville\">Brockville</option><option value=\"brooklin\">Brooklin</option><option value=\"brownsville\">Brownsville</option><option value=\"bruce-mines\">Bruce Mines</option><option value=\"brussels\">Brussels</option><option value=\"buckhorn\">Buckhorn</option><option value=\"burford\">Burford</option><option value=\"burgessville\">Burgessville</option><option value=\"burks-falls\">Burk's Falls</option><option value=\"burleigh-falls\">Burleigh Falls</option><option value=\"burlington\">Burlington</option><option value=\"cache-bay\">Cache Bay</option><option value=\"calabogie\">Calabogie</option><option value=\"caledon\">Caledon</option><option value=\"caledon-east\">Caledon East</option><option value=\"caledonia\">Caledonia</option><option value=\"callander\">Callander</option><option value=\"calstock\">Calstock</option><option value=\"cambray\">Cambray</option><option value=\"cambridge\">Cambridge</option><option value=\"cameron\">Cameron</option><option value=\"camlachie\">Camlachie</option><option value=\"campbellford\">Campbellford</option><option value=\"campbellville\">Campbellville</option><option value=\"cannington\">Cannington</option><option value=\"capreol\">Capreol</option><option value=\"caradoc-first-nation\">Caradoc First Nation</option><option value=\"caramat\">Caramat</option><option value=\"cardiff\">Cardiff</option><option value=\"cardinal\">Cardinal</option><option value=\"cargill\">Cargill</option><option value=\"carleton-place\">Carleton Place</option><option value=\"carnarvon\">Carnarvon</option><option value=\"carp\">Carp</option><option value=\"cartier\">Cartier</option><option value=\"casselman\">Casselman</option><option value=\"castlemore\">Castlemore</option><option value=\"castleton\">Castleton</option><option value=\"cat-lake\">Cat Lake</option><option value=\"cavan\">Cavan</option><option value=\"cayuga\">Cayuga</option><option value=\"centralia\">Centralia</option><option value=\"chalk-river\">Chalk River</option><option value=\"chapleau\">Chapleau</option><option value=\"charlton\">Charlton</option><option value=\"chatham\">Chatham</option><option value=\"chatsworth\">Chatsworth</option><option value=\"chelmsford\">Chelmsford</option><option value=\"chesley\">Chesley</option><option value=\"chesterville\">Chesterville</option><option value=\"chiefs-point-first-nation\">Chiefs Point First Nation</option><option value=\"chippewas-of-kettle-stony-poin\">Chippewas of Kettle/Stony Poin</option><option value=\"chippewas-of-sarnia-first-nati\">Chippewas Of Sarnia First Nati</option><option value=\"christian-island\">Christian Island</option><option value=\"claremont\">Claremont</option><option value=\"clarence-creek\">Clarence Creek</option><option value=\"clarence-rockland\">Clarence-Rockland</option><option value=\"clarington\">Clarington</option><option value=\"clarkson\">Clarkson</option><option value=\"clearwater-bay\">Clearwater Bay</option><option value=\"clifford\">Clifford</option><option value=\"clinton\">Clinton</option><option value=\"cloud-bay\">Cloud Bay</option><option value=\"cobalt\">Cobalt</option><option value=\"cobden\">Cobden</option><option value=\"coboconk\">Coboconk</option><option value=\"cobourg\">Cobourg</option><option value=\"cochenour\">Cochenour</option><option value=\"cochrane\">Cochrane</option><option value=\"coe-hill\">Coe Hill</option><option value=\"colborne\">Colborne</option><option value=\"colchester\">Colchester</option><option value=\"cold-springs\">Cold Springs</option><option value=\"coldwater\">Coldwater</option><option value=\"collingwood\">Collingwood</option><option value=\"comber\">Comber</option><option value=\"concord\">Concord</option><option value=\"coniston\">Coniston</option><option value=\"connaught\">Connaught</option><option value=\"constance-bay\">Constance Bay</option><option value=\"constance-lake-first-nation\">Constance Lake First Nation</option><option value=\"cookstown\">Cookstown</option><option value=\"cooksville\">Cooksville</option><option value=\"cornwall\">Cornwall</option><option value=\"corunna\">Corunna</option><option value=\"cottam\">Cottam</option><option value=\"courtice\">Courtice</option><option value=\"courtright\">Courtright</option><option value=\"crediton\">Crediton</option><option value=\"creemore\">Creemore</option><option value=\"crysler\">Crysler</option><option value=\"crystal-beach\">Crystal Beach</option><option value=\"cumberland\">Cumberland</option><option value=\"dashwood\">Dashwood</option><option value=\"deep-river\">Deep River</option><option value=\"deerbrook\">Deerbrook</option><option value=\"deer-lake\">Deer Lake</option><option value=\"delaware-of-the-thames-moravia\">Delaware of the Thames(Moravia</option><option value=\"delhi\">Delhi</option><option value=\"delta\">Delta</option><option value=\"denbigh\">Denbigh</option><option value=\"desbarats\">Desbarats</option><option value=\"deseronto\">Deseronto</option><option value=\"deux-rivieres\">Deux Rivières</option><option value=\"devlin\">Devlin</option><option value=\"dokis\">Dokis</option><option value=\"dokis-first-nation\">Dokis First Nation</option><option value=\"dorchester\">Dorchester</option><option value=\"dorion\">Dorion</option><option value=\"dorset\">Dorset</option><option value=\"douglas\">Douglas</option><option value=\"douglastown\">Douglastown</option><option value=\"drayton\">Drayton</option><option value=\"dresden\">Dresden</option><option value=\"drumbo\">Drumbo</option><option value=\"dryden\">Dryden</option><option value=\"dublin\">Dublin</option><option value=\"dubreuilville\">Dubreuilville</option><option value=\"dunchurch\">Dunchurch</option><option value=\"dundalk\">Dundalk</option><option value=\"dundas\">Dundas</option><option value=\"dungannon\">Dungannon</option><option value=\"dunnville\">Dunnville</option><option value=\"dunsford\">Dunsford</option><option value=\"durham\">Durham</option><option value=\"dutton\">Dutton</option><option value=\"dwight\">Dwight</option><option value=\"dyers-bay\">Dyer's Bay</option><option value=\"eagle-lake-first-nation\">Eagle Lake First Nation</option><option value=\"eagle-river\">Eagle River</option><option value=\"ear-falls\">Ear Falls</option><option value=\"earlton\">Earlton</option><option value=\"east-gwillimbury\">East Gwillimbury</option><option value=\"eastwood\">Eastwood</option><option value=\"east-york\">East York</option><option value=\"echo-bay\">Echo Bay</option><option value=\"eganville\">Eganville</option><option value=\"elgin\">Elgin</option><option value=\"elizabethtown\">Elizabethtown</option><option value=\"elk-lake\">Elk Lake</option><option value=\"elliot-lake\">Elliot Lake</option><option value=\"elmira\">Elmira</option><option value=\"elmvale\">Elmvale</option><option value=\"elora\">Elora</option><option value=\"embro\">Embro</option><option value=\"embrun\">Embrun</option><option value=\"emeryville\">Emeryville</option><option value=\"emo\">Emo</option><option value=\"emsdale\">Emsdale</option><option value=\"englehart\">Englehart</option><option value=\"enterprise\">Enterprise</option><option value=\"erin\">Erin</option><option value=\"espanola\">Espanola</option><option value=\"essex\">Essex</option><option value=\"estaire\">Estaire</option><option value=\"etobicoke\">Etobicoke</option><option value=\"eugenia\">Eugenia</option><option value=\"exeter\">Exeter</option><option value=\"fauquier\">Fauquier</option><option value=\"fenelon-falls\">Fenelon Falls</option><option value=\"fenwick\">Fenwick</option><option value=\"fergus\">Fergus</option><option value=\"feversham\">Feversham</option><option value=\"field\">Field</option><option value=\"finch\">Finch</option><option value=\"fingal\">Fingal</option><option value=\"fisherville\">Fisherville</option><option value=\"flamborough\">Flamborough</option><option value=\"flanders\">Flanders</option><option value=\"flesherton\">Flesherton</option><option value=\"foley\">Foley</option><option value=\"foleyet\">Foleyet</option><option value=\"forest\">Forest</option><option value=\"fort-albany\">Fort Albany</option><option value=\"fort-erie\">Fort Erie</option><option value=\"fort-frances\">Fort Frances</option><option value=\"fort-hope\">Fort Hope</option><option value=\"fort-severn\">Fort Severn</option><option value=\"fort-severn-first-nation\">Fort Severn First Nation</option><option value=\"fort-william-first-nation\">Fort William First Nation</option><option value=\"foxboro\">Foxboro</option><option value=\"foymount\">Foymount</option><option value=\"frankford\">Frankford</option><option value=\"freelton\">Freelton</option><option value=\"french-river-first-nation\">French River First Nation</option><option value=\"galt\">Galt</option><option value=\"gananoque\">Gananoque</option><option value=\"garden-hill\">Garden Hill</option><option value=\"garden-river-first-nation\">Garden River First Nation</option><option value=\"garson\">Garson</option><option value=\"georgetown\">Georgetown</option><option value=\"georgina\">Georgina</option><option value=\"geraldton\">Geraldton</option><option value=\"gilmour\">Gilmour</option><option value=\"glencoe\">Glencoe</option><option value=\"glen-robertson\">Glen Robertson</option><option value=\"glen-water\">Glen Water</option><option value=\"glen-williams\">Glen Williams</option><option value=\"gloucester\">Gloucester</option><option value=\"goderich\">Goderich</option><option value=\"gogama\">Gogama</option><option value=\"golden-lake\">Golden Lake</option><option value=\"gooderham\">Gooderham</option><option value=\"gore-bay\">Gore Bay</option><option value=\"gormley\">Gormley</option><option value=\"gorrie\">Gorrie</option><option value=\"goulais-river\">Goulais River</option><option value=\"gowganda\">Gowganda</option><option value=\"grafton\">Grafton</option><option value=\"grand-bend\">Grand Bend</option><option value=\"grand-valley\">Grand Valley</option><option value=\"granton\">Granton</option><option value=\"grassy-narrows\">Grassy Narrows</option><option value=\"grassy-narrows-first-nation\">Grassy Narrows First Nation</option><option value=\"gravenhurst\">Gravenhurst</option><option value=\"greensville\">Greensville</option><option value=\"grimsby\">Grimsby</option><option value=\"guelph\">Guelph</option><option value=\"gull-bay\">Gull Bay</option><option value=\"gull-bay-first-nation\">Gull Bay First Nation</option><option value=\"hagersville\">Hagersville</option><option value=\"haileybury\">Haileybury</option><option value=\"haldimand\">Haldimand</option><option value=\"haliburton\">Haliburton</option><option value=\"halton-hills\">Halton Hills</option><option value=\"hamilton\">Hamilton</option><option value=\"hampton\">Hampton</option><option value=\"hanmer\">Hanmer</option><option value=\"hanover\">Hanover</option><option value=\"harrietsville\">Harrietsville</option><option value=\"harriston\">Harriston</option><option value=\"harrow\">Harrow</option><option value=\"harrowsmith\">Harrowsmith</option><option value=\"hastings\">Hastings</option><option value=\"havelock\">Havelock</option><option value=\"hawkesbury\">Hawkesbury</option><option value=\"hawk-junction\">Hawk Junction</option><option value=\"hearst\">Hearst</option><option value=\"hemlo\">Hemlo</option><option value=\"hensall\">Hensall</option><option value=\"henvey-inlet-first-nation\">Henvey Inlet First Nation</option><option value=\"hepworth\">Hepworth</option><option value=\"hespeler\">Hespeler</option><option value=\"hickson\">Hickson</option><option value=\"highgate\">Highgate</option><option value=\"hillsburgh\">Hillsburgh</option><option value=\"holland-landing\">Holland Landing</option><option value=\"holstein\">Holstein</option><option value=\"honey-harbour\">Honey Harbour</option><option value=\"hornepayne\">Hornepayne</option><option value=\"hudson\">Hudson</option><option value=\"humphrey\">Humphrey</option><option value=\"huntsville\">Huntsville</option><option value=\"ignace\">Ignace</option><option value=\"ilderton\">Ilderton</option><option value=\"ingersoll\">Ingersoll</option><option value=\"ingleside\">Ingleside</option><option value=\"innerkip\">Innerkip</option><option value=\"innisfil\">Innisfil</option><option value=\"inverary\">Inverary</option><option value=\"inwood\">Inwood</option><option value=\"iron-bridge\">Iron Bridge</option><option value=\"iroquois\">Iroquois</option><option value=\"iroquois-falls\">Iroquois Falls</option><option value=\"jaffray-melick\">Jaffray Melick</option><option value=\"jarvis\">Jarvis</option><option value=\"jasper\">Jasper</option><option value=\"jellicoe\">Jellicoe</option><option value=\"jockvale\">Jockvale</option><option value=\"johnstown\">Johnstown</option><option value=\"jordan\">Jordan</option><option value=\"kaministiquia\">Kaministiquia</option><option value=\"kamiskotia\">Kamiskotia</option><option value=\"kanata\">Kanata</option><option value=\"kapuskasing\">Kapuskasing</option><option value=\"kasabonika-first-nation\">Kasabonika First Nation</option><option value=\"kashechewan-first-nation\">Kashechewan First Nation</option><option value=\"kearney\">Kearney</option><option value=\"keene\">Keene</option><option value=\"keewatin\">Keewatin</option><option value=\"kemptville\">Kemptville</option><option value=\"kenora\">Kenora</option><option value=\"kent-centre\">Kent Centre</option><option value=\"kerwood\">Kerwood</option><option value=\"keswick\">Keswick</option><option value=\"killaloe\">Killaloe</option><option value=\"killarney\">Killarney</option><option value=\"kincardine\">Kincardine</option><option value=\"king-city\">King City</option><option value=\"kingfisher-lake\">Kingfisher Lake</option><option value=\"kingfisher-lake-first-nation\">Kingfisher Lake First Nation</option><option value=\"kingston\">Kingston</option><option value=\"kingsville\">Kingsville</option><option value=\"kinmount\">Kinmount</option><option value=\"kintore\">Kintore</option><option value=\"kirkfield\">Kirkfield</option><option value=\"kirkland-lake\">Kirkland Lake</option><option value=\"kirkton\">Kirkton</option><option value=\"kitchener\">Kitchener</option><option value=\"kleinburg\">Kleinburg</option><option value=\"lac-la-croix\">Lac la Croix</option><option value=\"lac-seul-first-nation\">Lac Seul First Nation</option><option value=\"lafontaine\">Lafontaine</option><option value=\"lagoon-city\">Lagoon City</option><option value=\"lakefield\">Lakefield</option><option value=\"lambeth\">Lambeth</option><option value=\"lanark\">Lanark</option><option value=\"lancaster\">Lancaster</option><option value=\"langton\">Langton</option><option value=\"lansdowne\">Lansdowne</option><option value=\"lansdowne-house\">Lansdowne House</option><option value=\"larder-lake\">Larder Lake</option><option value=\"lasalle\">LaSalle</option><option value=\"latchford\">Latchford</option><option value=\"leamington\">Leamington</option><option value=\"lefroy\">Lefroy</option><option value=\"levack\">Levack</option><option value=\"lincoln\">Lincoln</option><option value=\"lindsay\">Lindsay</option><option value=\"linwood\">Linwood</option><option value=\"lions-head\">Lion's Head</option><option value=\"listowel\">Listowel</option><option value=\"little-britain\">Little Britain</option><option value=\"little-current\">Little Current</option><option value=\"lively\">Lively</option><option value=\"lombardy\">Lombardy</option><option value=\"london\">London</option><option value=\"longlac\">Longlac</option><option value=\"long-lac\">Long Lac</option><option value=\"long-lake-first-nation\">Long Lake First Nation</option><option value=\"long-point\">Long Point</option><option value=\"long-sault\">Long Sault</option><option value=\"lorignal\">L'Orignal</option><option value=\"lorne\">Lorne</option><option value=\"lucan\">Lucan</option><option value=\"lucknow\">Lucknow</option><option value=\"lyn\">Lyn</option><option value=\"lynden\">Lynden</option><option value=\"maberly\">Maberly</option><option value=\"macdiarmid\">Macdiarmid</option><option value=\"mactier\">MacTier</option><option value=\"madoc\">Madoc</option><option value=\"madsen\">Madsen</option><option value=\"magnetawan\">Magnetawan</option><option value=\"magnetawan-first-nation\">Magnetawan First Nation</option><option value=\"maidstone\">Maidstone</option><option value=\"maitland\">Maitland</option><option value=\"mallorytown\">Mallorytown</option><option value=\"malton\">Malton</option><option value=\"manitouwadge\">Manitouwadge</option><option value=\"manitowaning\">Manitowaning</option><option value=\"manotick\">Manotick</option><option value=\"maple\">Maple</option><option value=\"marathon\">Marathon</option><option value=\"markdale\">Markdale</option><option value=\"markham\">Markham</option><option value=\"markstay\">Markstay</option><option value=\"marmora\">Marmora</option><option value=\"marten-falls-first-nation\">Marten Falls First Nation</option><option value=\"marten-river\">Marten River</option><option value=\"martintown\">Martintown</option><option value=\"massey\">Massey</option><option value=\"matachewan\">Matachewan</option><option value=\"matheson\">Matheson</option><option value=\"mattawa\">Mattawa</option><option value=\"mattice\">Mattice</option><option value=\"maxville\">Maxville</option><option value=\"maynooth\">Maynooth</option><option value=\"mcdonalds-corners\">McDonalds Corners</option><option value=\"mcgregor\">McGregor</option><option value=\"mchigeeng\">M'Chigeeng</option><option value=\"mckellar\">McKellar</option><option value=\"meaford\">Meaford</option><option value=\"melbourne\">Melbourne</option><option value=\"merlin\">Merlin</option><option value=\"merrickville\">Merrickville</option><option value=\"metcalfe\">Metcalfe</option><option value=\"midland\">Midland</option><option value=\"mildmay\">Mildmay</option><option value=\"milford-bay\">Milford Bay</option><option value=\"millbrook\">Millbrook</option><option value=\"millhaven\">Millhaven</option><option value=\"milton\">Milton</option><option value=\"milverton\">Milverton</option><option value=\"minaki\">Minaki</option><option value=\"mindemoya\">Mindemoya</option><option value=\"minden\">Minden</option><option value=\"mine-centre\">Mine Centre</option><option value=\"missanabie\">Missanabie</option><option value=\"mississauga\">Mississauga</option><option value=\"mitchell\">Mitchell</option><option value=\"mohawks-of-the-bay-of-quinte-f\">Mohawks Of The Bay of Quinte F</option><option value=\"monkton\">Monkton</option><option value=\"moonbeam\">Moonbeam</option><option value=\"moonstone\">Moonstone</option><option value=\"mooretown\">Mooretown</option><option value=\"moose-creek\">Moose Creek</option><option value=\"moose-factory\">Moose Factory</option><option value=\"moosonee\">Moosonee</option><option value=\"morrisburg\">Morrisburg</option><option value=\"morson\">Morson</option><option value=\"mount-albert\">Mount Albert</option><option value=\"mount-brydges\">Mount Brydges</option><option value=\"mount-forest\">Mount Forest</option><option value=\"mount-hope\">Mount Hope</option><option value=\"mount-pleasant\">Mount Pleasant</option><option value=\"muskoka\">Muskoka</option><option value=\"muskoka-falls\">Muskoka Falls</option><option value=\"muskrat-dam\">Muskrat Dam</option><option value=\"muskrat-dam-first-nation\">Muskrat Dam First Nation</option><option value=\"nairn\">Nairn</option><option value=\"naiscoutaing-first-nation\">Naiscoutaing First Nation</option><option value=\"nakina\">Nakina</option><option value=\"nanticoke\">Nanticoke</option><option value=\"napanee\">Napanee</option><option value=\"navan\">Navan</option><option value=\"nepean\">Nepean</option><option value=\"nephton\">Nephton</option><option value=\"nestor-falls\">Nestor Falls</option><option value=\"neustadt\">Neustadt</option><option value=\"newburgh\">Newburgh</option><option value=\"newcastle\">Newcastle</option><option value=\"new-dundee\">New Dundee</option><option value=\"new-hamburg\">New Hamburg</option><option value=\"new-liskeard\">New Liskeard</option><option value=\"newmarket\">Newmarket</option><option value=\"new-tecumseth\">New Tecumseth</option><option value=\"newtonville\">Newtonville</option><option value=\"niagara-falls\">Niagara Falls</option><option value=\"niagara-on-the-lake\">Niagara-on-the-Lake</option><option value=\"nickel-centre\">Nickel Centre</option><option value=\"nipigon\">Nipigon</option><option value=\"nipissing-first-nation\">Nipissing First Nation</option><option value=\"nobel\">Nobel</option><option value=\"nobleton\">Nobleton</option><option value=\"noelville\">Noelville</option><option value=\"north-augusta\">North Augusta</option><option value=\"north-bay\">North Bay</option><option value=\"northbrook\">Northbrook</option><option value=\"north-gower\">North Gower</option><option value=\"north-spirit-lake\">North Spirit Lake</option><option value=\"north-york\">North York</option><option value=\"norval\">Norval</option><option value=\"norwich\">Norwich</option><option value=\"norwood\">Norwood</option><option value=\"oak-ridges\">Oak Ridges</option><option value=\"oakville\">Oakville</option><option value=\"oakwood\">Oakwood</option><option value=\"oba\">Oba</option><option value=\"odessa\">Odessa</option><option value=\"ogoki\">Ogoki</option><option value=\"ohsweken\">Ohsweken</option><option value=\"oil-springs\">Oil Springs</option><option value=\"ojibways-of-hiawatha-first-nat\">Ojibways of Hiawatha First Nat</option><option value=\"ojibways-of-walpole-island-fir\">Ojibways of Walpole Island Fir</option><option value=\"omemee\">Omemee</option><option value=\"onaping-falls\">Onaping Falls</option><option value=\"oneida-first-nation\">Oneida First Nation</option><option value=\"opasatika\">Opasatika</option><option value=\"ophir\">Ophir</option><option value=\"orangeville\">Orangeville</option><option value=\"orillia\">Orillia</option><option value=\"orleans\">Orleans</option><option value=\"oro\">Oro</option><option value=\"orono\">Orono</option><option value=\"orrville\">Orrville</option><option value=\"osgoode\">Osgoode</option><option value=\"oshawa\">Oshawa</option><option value=\"ottawa\">Ottawa</option><option value=\"otterville\">Otterville</option><option value=\"owen-sound\">Owen Sound</option><option value=\"oxdrift\">Oxdrift</option><option value=\"oxford-mills\">Oxford Mills</option><option value=\"paisley\">Paisley</option><option value=\"pakenham\">Pakenham</option><option value=\"palgrave\">Palgrave</option><option value=\"palmer-rapids\">Palmer Rapids</option><option value=\"palmerston\">Palmerston</option><option value=\"paquette-corner\">Paquette Corner</option><option value=\"parham\">Parham</option><option value=\"paris\">Paris</option><option value=\"parkhill\">Parkhill</option><option value=\"parry-sound\">Parry Sound</option><option value=\"pass-lake\">Pass Lake</option><option value=\"peawanuck\">Peawanuck</option><option value=\"pefferlaw\">Pefferlaw</option><option value=\"pelee-island\">Pelee Island</option><option value=\"pelham\">Pelham</option><option value=\"pembroke\">Pembroke</option><option value=\"penetanguishene\">Penetanguishene</option><option value=\"perrault-falls\">Perrault Falls</option><option value=\"perth\">Perth</option><option value=\"petawawa\">Petawawa</option><option value=\"peterborough\">Peterborough</option><option value=\"petrolia\">Petrolia</option><option value=\"pickering\">Pickering</option><option value=\"pickle-lake\">Pickle Lake</option><option value=\"picton\">Picton</option><option value=\"pikangikum-first-nation\">Pikangikum First Nation</option><option value=\"pineal-lake\">Pineal Lake</option><option value=\"plantagenet\">Plantagenet</option><option value=\"plattsville\">Plattsville</option><option value=\"pleasant-park\">Pleasant Park</option><option value=\"plevna\">Plevna</option><option value=\"pointe-au-baril\">Pointe au Baril</option><option value=\"point-grondine-first-nation\">Point Grondine First Nation</option><option value=\"point-pelee\">Point Pelee</option><option value=\"port-burwell\">Port Burwell</option><option value=\"port-carling\">Port Carling</option><option value=\"port-colborne\">Port Colborne</option><option value=\"port-credit\">Port Credit</option><option value=\"port-cunnington\">Port Cunnington</option><option value=\"port-dover\">Port Dover</option><option value=\"port-elgin\">Port Elgin</option><option value=\"port-franks\">Port Franks</option><option value=\"port-hope\">Port Hope</option><option value=\"port-lambton\">Port Lambton</option><option value=\"portland\">Portland</option><option value=\"port-loring\">Port Loring</option><option value=\"port-mcnicoll\">Port McNicoll</option><option value=\"port-perry\">Port Perry</option><option value=\"port-robinson\">Port Robinson</option><option value=\"port-rowan\">Port Rowan</option><option value=\"port-stanley\">Port Stanley</option><option value=\"port-sydney\">Port Sydney</option><option value=\"powassan\">Powassan</option><option value=\"prescott\">Prescott</option><option value=\"preston\">Preston</option><option value=\"princeton\">Princeton</option><option value=\"puce\">Puce</option><option value=\"queenston\">Queenston</option><option value=\"queensville\">Queensville</option><option value=\"rainy-lake-first-nation\">Rainy Lake First Nation</option><option value=\"rainy-river\">Rainy River</option><option value=\"raith\">Raith</option><option value=\"ramore\">Ramore</option><option value=\"rayside-balfour\">Rayside-Balfour</option><option value=\"redbridge\">Redbridge</option><option value=\"redditt\">Redditt</option><option value=\"red-lake\">Red Lake</option><option value=\"red-rock\">Red Rock</option><option value=\"renfrew\">Renfrew</option><option value=\"restoule\">Restoule</option><option value=\"richmond\">Richmond</option><option value=\"richmond-hill\">Richmond Hill</option><option value=\"ridgetown\">Ridgetown</option><option value=\"ridgeway\">Ridgeway</option><option value=\"ripley\">Ripley</option><option value=\"rockland\">Rockland</option><option value=\"rockwood\">Rockwood</option><option value=\"rodney\">Rodney</option><option value=\"rolphton\">Rolphton</option><option value=\"rondeau\">Rondeau</option><option value=\"roseneath\">Roseneath</option><option value=\"rosseau\">Rosseau</option><option value=\"russell\">Russell</option><option value=\"ruthven\">Ruthven</option><option value=\"sachigo-first-nation-reserve-1\">Sachigo First Nation Reserve 1</option><option value=\"saint-clair-beach\">Saint Clair Beach</option><option value=\"salem\">Salem</option><option value=\"sandwich\">Sandwich</option><option value=\"sandy-cove-acres\">Sandy Cove Acres</option><option value=\"sandy-lake\">Sandy Lake</option><option value=\"sandy-lake-first-nation\">Sandy Lake First Nation</option><option value=\"sapawe\">Sapawe</option><option value=\"sarnia\">Sarnia</option><option value=\"sauble-beach\">Sauble Beach</option><option value=\"saugeen-first-nation\">Saugeen First Nation</option><option value=\"sault-ste-marie\">Sault Ste. Marie</option><option value=\"savant-lake\">Savant Lake</option><option value=\"scarborough\">Scarborough</option><option value=\"schomberg\">Schomberg</option><option value=\"schreiber\">Schreiber</option><option value=\"scotland\">Scotland</option><option value=\"seaforth\">Seaforth</option><option value=\"searchmont\">Searchmont</option><option value=\"sebright\">Sebright</option><option value=\"sebringville\">Sebringville</option><option value=\"seeleys-bay\">Seeleys Bay</option><option value=\"selby\">Selby</option><option value=\"selkirk\">Selkirk</option><option value=\"serpent-river-first-nation\">Serpent River First Nation</option><option value=\"severn-bridge\">Severn Bridge</option><option value=\"shakespeare\">Shakespeare</option><option value=\"shannonville\">Shannonville</option><option value=\"sharbot-lake\">Sharbot Lake</option><option value=\"shawanaga-first-nation\">Shawanaga First Nation</option><option value=\"shebandowan\">Shebandowan</option><option value=\"shedden\">Shedden</option><option value=\"shelburne\">Shelburne</option><option value=\"silver-water\">Silver Water</option><option value=\"simcoe\">Simcoe</option><option value=\"sioux-lookout\">Sioux Lookout</option><option value=\"sioux-narrows\">Sioux Narrows</option><option value=\"six-nations-of-the-grand-river\">Six Nations of the Grand River</option><option value=\"smiths-falls\">Smiths Falls</option><option value=\"smithville\">Smithville</option><option value=\"smooth-rock-falls\">Smooth Rock Falls</option><option value=\"snelgrove\">Snelgrove</option><option value=\"sombra\">Sombra</option><option value=\"southampton\">Southampton</option><option value=\"south-mountain\">South Mountain</option><option value=\"south-river\">South River</option><option value=\"spanish\">Spanish</option><option value=\"sparta\">Sparta</option><option value=\"spencerville\">Spencerville</option><option value=\"sprucedale\">Sprucedale</option><option value=\"stayner\">Stayner</option><option value=\"st-catharines\">St. Catharines</option><option value=\"st-charles\">St. Charles</option><option value=\"st-clements\">St. Clements</option><option value=\"st-davids\">St. Davids</option><option value=\"st-eugene\">St-Eugene</option><option value=\"stevensville\">Stevensville</option><option value=\"stewarttown\">Stewarttown</option><option value=\"st-george\">St. George</option><option value=\"stirling\">Stirling</option><option value=\"st-isidore-de-prescott\">St. Isidore de Prescott</option><option value=\"st-jacobs\">St. Jacobs</option><option value=\"st-marys\">St. Mary's</option><option value=\"stokes-bay\">Stoke's Bay</option><option value=\"stoney-creek\">Stoney Creek</option><option value=\"stoney-point\">Stoney Point</option><option value=\"stouffville\">Stouffville</option><option value=\"straffordville\">Straffordville</option><option value=\"stratford\">Stratford</option><option value=\"strathroy\">Strathroy</option><option value=\"stratton\">Stratton</option><option value=\"streetsville\">Streetsville</option><option value=\"st-regis\">St. Regis</option><option value=\"stroud\">Stroud</option><option value=\"st-thomas\">St. Thomas</option><option value=\"sturgeon-falls\">Sturgeon Falls</option><option value=\"sudbury\">Sudbury</option><option value=\"sultan\">Sultan</option><option value=\"summer-beaver\">Summer Beaver</option><option value=\"sunderland\">Sunderland</option><option value=\"sundridge\">Sundridge</option><option value=\"sutton\">Sutton</option><option value=\"swastika\">Swastika</option><option value=\"sydenham\">Sydenham</option><option value=\"tamworth\">Tamworth</option><option value=\"tara\">Tara</option><option value=\"tavistock\">Tavistock</option><option value=\"taylor-corners\">Taylor Corners</option><option value=\"tecumseh\">Tecumseh</option><option value=\"teeswater\">Teeswater</option><option value=\"temagami\">Temagami</option><option value=\"terrace-bay\">Terrace Bay</option><option value=\"thamesford\">Thamesford</option><option value=\"thamesville\">Thamesville</option><option value=\"thedford\">Thedford</option><option value=\"the-eabametoong-fort-hope-fi\">The Eabametoong (Fort Hope) Fi</option><option value=\"thessalon\">Thessalon</option><option value=\"thessalon-first-nation\">Thessalon First Nation</option><option value=\"thornbury\">Thornbury</option><option value=\"thorndale\">Thorndale</option><option value=\"thorne\">Thorne</option><option value=\"thornhill\">Thornhill</option><option value=\"thorold\">Thorold</option><option value=\"thunder-bay\">Thunder Bay</option><option value=\"thurlow\">Thurlow</option><option value=\"tilbury\">Tilbury</option><option value=\"tillsonburg\">Tillsonburg</option><option value=\"timmins\">Timmins</option><option value=\"tiverton\">Tiverton</option><option value=\"tobermory\">Tobermory</option><option value=\"toledo\">Toledo</option><option value=\"toronto\">Toronto</option><option value=\"tottenham\">Tottenham</option><option value=\"trenton\">Trenton</option><option value=\"trout-creek\">Trout Creek</option><option value=\"trowbridge\">Trowbridge</option><option value=\"tweed\">Tweed</option><option value=\"udora\">Udora</option><option value=\"uniondale\">Uniondale</option><option value=\"unionville\">Unionville</option><option value=\"upsala\">Upsala</option><option value=\"utterson\">Utterson</option><option value=\"uxbridge\">Uxbridge</option><option value=\"valley-east\">Valley East</option><option value=\"vanier\">Vanier</option><option value=\"vankleek-hill\">Vankleek Hill</option><option value=\"vaughan\">Vaughan</option><option value=\"vermilion-bay\">Vermilion Bay</option><option value=\"verner\">Verner</option><option value=\"verona\">Verona</option><option value=\"victoria\">Victoria</option><option value=\"vineland\">Vineland</option><option value=\"virginiatown\">Virginiatown</option><option value=\"wabigoon\">Wabigoon</option><option value=\"wainfleet\">Wainfleet</option><option value=\"walden\">Walden</option><option value=\"walkerton\">Walkerton</option><option value=\"wallaceburg\">Wallaceburg</option><option value=\"wapekeka-first-nation\">Wapekeka First Nation</option><option value=\"wardsville\">Wardsville</option><option value=\"warkworth\">Warkworth</option><option value=\"warren\">Warren</option><option value=\"wasaga-beach\">Wasaga Beach</option><option value=\"waterdown\">Waterdown</option><option value=\"waterford\">Waterford</option><option value=\"waterloo\">Waterloo</option><option value=\"watford\">Watford</option><option value=\"waubaushene\">Waubaushene</option><option value=\"wawa\">Wawa</option><option value=\"webbwood\">Webbwood</option><option value=\"webequie\">Webequie</option><option value=\"welcome\">Welcome</option><option value=\"welland\">Welland</option><option value=\"wellandport\">Wellandport</option><option value=\"wellesley\">Wellesley</option><option value=\"wellington\">Wellington</option><option value=\"west-guilford\">West Guilford</option><option value=\"west-lincoln\">West Lincoln</option><option value=\"west-lorne\">West Lorne</option><option value=\"westmeath\">Westmeath</option><option value=\"westport\">Westport</option><option value=\"westree\">Westree</option><option value=\"wheatley\">Wheatley</option><option value=\"whitby\">Whitby</option><option value=\"whitchurch-stouffville\">Whitchurch-Stouffville</option><option value=\"whitefish\">Whitefish</option><option value=\"whitefish-falls\">Whitefish Falls</option><option value=\"whitefish-river-first-nation\">Whitefish River First Nation</option><option value=\"white-river\">White River</option><option value=\"whitney\">Whitney</option><option value=\"wiarton\">Wiarton</option><option value=\"wikwemikong\">Wikwemikong</option><option value=\"wilberforce\">Wilberforce</option><option value=\"williamsburg\">Williamsburg</option><option value=\"winchester\">Winchester</option><option value=\"windermere\">Windermere</option><option value=\"windsor\">Windsor</option><option value=\"wingham\">Wingham</option><option value=\"winona\">Winona</option><option value=\"woodbridge\">Woodbridge</option><option value=\"woodstock\">Woodstock</option><option value=\"woodville\">Woodville</option><option value=\"wooler\">Wooler</option><option value=\"wunnummin-lake\">Wunnummin Lake</option><option value=\"wyoming\">Wyoming</option><option value=\"yarker\">Yarker</option><option value=\"york\">York</option><option value=\"zurich\">Zurich</option></select></span>

\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<label for=\"fthb\">First-time home buyer</label>
\t\t\t\t\t\t\t<span class=\"rh-checkbox-container\"><div style=\"position: relative;\" class=\"icheckbox\"><input style=\"position: absolute; opacity: 0;\" class=\"checkbox\" id=\"fthb\" name=\"fthb\" type=\"checkbox\"><i class=\"fa fa-square\"></i><i class=\"fa fa-check-square\"></i><ins style=\"position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;\" class=\"iCheck-helper\"></ins></div></span>
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t</tbody></table>

\t\t\t\t<input value=\"Calculate\" style=\"position: absolute; width:10px; left:-999em;\" type=\"submit\">

\t\t\t<div id=\"calc_extension\">
\t<div class=\"content-page cash-needed\">
\t\t<h3 class=\"section-header\">
\t\t\t<a href=\"#\">
\t\t\t\t<span class=\"section-title\">Cash Needed</span><span class=\"collapse-section\"></span><div class=\"section-desc\">How much extra cash will I need when my house closes?</div>
\t\t\t</a>
\t\t</h3>
\t\t<div style=\"display: block;\" class=\"section-content\">
\t\t\t<p>When you purchase a house, there are a number of costs you'll need to put cash aside for in addition to your down payment. These costs depend on a number of factors including things like what kind of home you are buying (i.e. house vs. condo) and where the home is located.</p>
\t\t\t<p>Our tool will help you calculate these costs, so you know how much you'll need to save.</p>

\t\t\t<label for=\"home_type\">Type of home:</label>
\t\t\t<span class=\"rh-select\"><div style=\"width: 160px;\" id=\"s2id_home_type\" class=\"select2-container\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-4\" class=\"select2-chosen\">House</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen4\" class=\"select2-offscreen\">Type of home:</label><input id=\"s2id_autogen4\" aria-labelledby=\"select2-chosen-4\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"></div><select class=\"select2-offscreen\" title=\"Type of home:\" tabindex=\"-1\" id=\"home_type\">
\t\t\t\t<option value=\"house\">House</option>
\t\t\t\t<option value=\"condo\">Condominium</option>
\t\t\t</select></span>

\t\t\t<div class=\"ledger-header\">
\t\t\t\t<h4>Required Cash Expenditures</h4>
\t\t\t\t<div class=\"ledger-values\">
\t\t\t\t<label for=\"scenario\">Scenario:</label>
\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 160px;\" id=\"s2id_scenario\" class=\"select2-container\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-5\" class=\"select2-chosen\">Max. Affordability</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen5\" class=\"select2-offscreen\">Scenario:</label><input id=\"s2id_autogen5\" aria-labelledby=\"select2-chosen-5\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"></div><select class=\"select2-offscreen\" title=\"Scenario:\" tabindex=\"-1\" id=\"scenario\">
\t\t\t\t\t\t<option value=\"0\">Max. Affordability</option>
\t\t\t\t\t\t<option value=\"1\">Build Your Own</option>
\t\t\t\t\t</select></span>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<ul class=\"ledger-items\">
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-dp\">
\t\t\t\t\t\t<span class=\"item-name\">Down payment</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$1,275,075</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-cmhc-pst\">
\t\t\t\t\t\t<span class=\"item-name\">PST on mortgage insurance</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$0</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-ltt\">
\t\t\t\t\t\t<span class=\"item-name\">Land Transfer Tax</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$247,215</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-lawyer\">
\t\t\t\t\t\t<span class=\"item-name\">Lawyer fees</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$1,000</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-title\">
\t\t\t\t\t\t<span class=\"item-name\">Title insurance</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$6,375</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li style=\"display: none;\" class=\"ledger-cert\">
\t\t\t\t\t<div class=\"ledger-item\">
\t\t\t\t\t\t<span class=\"item-name\">Estoppel certificate fee</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$100</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item highlight ledger-cash-req\">
\t\t\t\t\t\t<span class=\"item-name\">Total Cash Required</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$1,529,665</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>

\t\t\t</ul>

\t\t\t<div class=\"ledger-header\">
\t\t\t\t<h4>Other Cash Considerations</h4>
\t\t\t</div>
\t\t\t<ul class=\"ledger-items\">
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-inspect\">
\t\t\t\t\t\t<span class=\"item-name\">Home inspection fees</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$300 - \$500</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-appraisal\">
\t\t\t\t\t\t<span class=\"item-name\">Appraisal fees</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$300</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t</ul>
\t\t</div>
\t</div>

\t<div class=\"content-page monthly-expenses\">
\t\t<h3 class=\"section-header\">
\t\t\t<a href=\"#\">
\t\t\t\t<span class=\"section-title\">Monthly Expenses</span><span class=\"expand-section\"></span><div class=\"section-desc\">Can I afford my monthly expenses &amp; mortgage payments?</div>
\t\t\t</a>
\t\t</h3>
\t\t<div style=\"display: none;\" class=\"section-content\">
<!--
\t\t\t<div class=\"ledger-header\">
\t\t\t\t<h4>Income</h4>
\t\t\t\t<div class=\"ledger-values\">
\t\t\t\t\t<h5>Max. Affordability</h5>
\t\t\t\t\t<h5>Build Your Own</h5>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<ul class=\"ledger-items\">
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-income\">
\t\t\t\t\t\t<span class=\"item-name\">Total</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$-</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item indent ledger-income-tax\">
\t\t\t\t\t\t<span class=\"item-name\">Less: Income tax</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$-</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item highlight ledger-net-income\">
\t\t\t\t\t\t<span class=\"item-name\">Net income</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$-</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t</ul>
-->
\t\t\t<div class=\"ledger-header\">
\t\t\t\t<h4>Expenses</h4>
\t\t\t\t<div class=\"ledger-values\">
\t\t\t\t\t<label for=\"scen_2\">Scenario:</label>
\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 160px;\" id=\"s2id_scen_2\" class=\"select2-container scenario\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-6\" class=\"select2-chosen\">Max. Affordability</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen6\" class=\"select2-offscreen\">Scenario:</label><input id=\"s2id_autogen6\" aria-labelledby=\"select2-chosen-6\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"><div class=\"select2-drop select2-display-none\">   <div class=\"select2-search select2-search-hidden select2-offscreen\">       <label for=\"s2id_autogen6_search\" class=\"select2-offscreen\">Scenario:</label>       <input placeholder=\"\" id=\"s2id_autogen6_search\" aria-owns=\"select2-results-6\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" class=\"select2-input\" role=\"combobox\" aria-expanded=\"true\" aria-autocomplete=\"list\" type=\"text\">   </div>   <ul id=\"select2-results-6\" class=\"select2-results\" role=\"listbox\">   </ul></div></div><select title=\"Scenario:\" tabindex=\"-1\" id=\"scen_2\" class=\"scenario select2-offscreen\">
\t\t\t\t\t\t<option value=\"0\">Max. Affordability</option>
\t\t\t\t\t\t<option value=\"1\">Build Your Own</option>
\t\t\t\t\t</select></span>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<ul class=\"ledger-items\">
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-mtg-payment\">
\t\t\t\t\t\t<span class=\"item-name\">Mortgage payment</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$19,753</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li class=\"ledger-prop-tax\">
\t\t\t\t\t<div class=\"ledger-item\">
\t\t\t\t\t\t<span class=\"item-name\">Property Tax</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t<span class=\"item-val first\">\$6,482</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-debt\">
\t\t\t\t\t\t<span class=\"item-name\">Monthly debt payments</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t\t\t<span class=\"item-val first\">\$0</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-utils\">
\t\t\t\t\t\t<span class=\"item-name\">Utilities</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t\t\t<span class=\"item-val first\">\$300</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li style=\"display: none;\" class=\"ledger-condo\">
\t\t\t\t\t<div class=\"ledger-item\">
\t\t\t\t\t\t<span class=\"item-name\">Condo Fees</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t\t\t<span class=\"item-val first\">\$300</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-prop-ins\">
\t\t\t\t\t\t<span class=\"item-name\">Property insurance</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<input pattern=\"[0-9]*\" class=\"item-val first input-number\" value=\"\$50\">
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-phone\">
\t\t\t\t\t\t<span class=\"item-name\">Phone</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<input pattern=\"[0-9]*\" class=\"item-val first input-number\" value=\"\$40\">
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-cable\">
\t\t\t\t\t\t<span class=\"item-name\">Cable</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<input pattern=\"[0-9]*\" class=\"item-val first input-number\" value=\"\$60\">
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-internet\">
\t\t\t\t\t\t<span class=\"item-name\">Internet</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<input pattern=\"[0-9]*\" class=\"item-val first input-number\" value=\"\$45\">
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item highlight ledger-expenses\">
\t\t\t\t\t\t<span class=\"item-name\">Total</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first input-number\">\$26,729</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t</ul>
\t\t</div>
\t</div>

\t<div class=\"content-page rate-risk\">
\t\t<h3 class=\"section-header\">
\t\t\t<a href=\"#\">
\t\t\t\t<span class=\"section-title\">Interest Rate Risk</span><span class=\"expand-section\"></span><div class=\"section-desc\">What would my payment be at higher interest rates?</div>
\t\t\t</a>
\t\t</h3>
\t\t<div style=\"display: none;\" class=\"section-content\">
\t\t\t<p>When determining the size of home you can afford, it's important to look at the long term horizon. The mortgage rate you pay today could be substantially different from the mortgage rates available when the time comes to renew your mortgage.</p>
\t\t\t<p>The calculation below shows how much of your mortgage principal will be left at the end of the term.</p>

\t\t\t<div class=\"ledger-header\">
\t\t\t\t<h4>Mortgage Amount</h4>
\t\t\t\t<div class=\"ledger-values\">
\t\t\t\t\t<label for=\"scen_3\">Scenario:</label>
\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 160px;\" id=\"s2id_scen_3\" class=\"select2-container scenario\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-7\" class=\"select2-chosen\">Max. Affordability</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen7\" class=\"select2-offscreen\">Scenario:</label><input id=\"s2id_autogen7\" aria-labelledby=\"select2-chosen-7\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"><div class=\"select2-drop select2-display-none\">   <div class=\"select2-search select2-search-hidden select2-offscreen\">       <label for=\"s2id_autogen7_search\" class=\"select2-offscreen\">Scenario:</label>       <input placeholder=\"\" id=\"s2id_autogen7_search\" aria-owns=\"select2-results-7\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" class=\"select2-input\" role=\"combobox\" aria-expanded=\"true\" aria-autocomplete=\"list\" type=\"text\">   </div>   <ul id=\"select2-results-7\" class=\"select2-results\" role=\"listbox\">   </ul></div></div><select title=\"Scenario:\" tabindex=\"-1\" id=\"scen_3\" class=\"scenario select2-offscreen\">
\t\t\t\t\t\t<option value=\"0\">Max. Affordability</option>
\t\t\t\t\t\t<option value=\"1\">Build Your Own</option>
\t\t\t\t\t</select></span>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<ul class=\"ledger-items\">
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item ledger-mtg-today\">
\t\t\t\t\t\t<span class=\"item-name\">Mortgage amount today</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$5,100,299</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item indent ledger-mtg-paid\">
\t\t\t\t\t\t<span class=\"item-name\">Less: Principal paid off over term</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">(\$621,439)</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<div class=\"ledger-item highlight ledger-mtg-eot\">
\t\t\t\t\t\t<span class=\"item-name\">Mortgage remaining at end of term:</span>
\t\t\t\t\t\t<span class=\"ledger-values\">
\t\t\t\t\t\t\t<span class=\"item-val first\">\$4,478,860</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"ledger-line\"></span>
\t\t\t\t\t</div>
\t\t\t\t</li>
\t\t\t</ul>
\t\t\t<p class=\"first\">Using this amount, below we calculate the corresponding mortgage payments at a variety of interest rates:</p>
\t\t\t<table>
\t\t\t\t<thead>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<th colspan=\"2\">Interest Rate</th>
\t\t\t\t\t\t<th class=\"payment\">Payment<br><span class=\"sub-head\">Selected Scenario</span></th>
\t\t\t\t\t</tr>
\t\t\t\t</thead>
\t\t\t\t<tbody>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>Selected Rate</td>
\t\t\t\t\t\t<td class=\"rate-value\">2.36 %</td>

\t\t\t\t\t\t<td class=\"payment first\">\$19,753</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>Average 5-year Fixed Rates (2000 - 2010)</td>
\t\t\t\t\t\t<td class=\"rate-value\">3.89%</td>

\t\t\t\t\t\t<td class=\"payment first\">\$23,293</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>Average 5-year Fixed Rates (1990 - 2000)</td>
\t\t\t\t\t\t<td class=\"rate-value\">7.23%</td>

\t\t\t\t\t\t<td class=\"payment first\">\$32,009</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>Average 5-year Fixed Rates (1980 - 1990)</td>
\t\t\t\t\t\t<td class=\"rate-value\">11.92%</td>

\t\t\t\t\t\t<td class=\"payment first\">\$45,967</td>
\t\t\t\t\t</tr>
\t\t\t\t</tbody>
\t\t\t</table>
\t\t\t<p>Below is a graph that displays the approximate values of competitive 5-year fixed mortgage rates since 2006.</p>
\t\t\t<div class=\"chart-wrapper chart-center\">
\t\t\t\t\t\t<h2>5-year Fixed Mortgage Rates\t\t\t\t\t\t</h2>
\t\t\t\t<div id=\"Chart_oMksO\" class=\"rh-chart\"></div>
\t</div>

\t\t</div>
\t</div>
\t<div class=\"content-page amortization\">
\t\t<h3 class=\"section-header\">
\t\t\t<a href=\"#\">
\t\t\t\t<span class=\"section-title\">Amortization Schedule</span><span class=\"expand-section\"></span><div class=\"section-desc\">What do my payments look like over time?</div>
\t\t\t</a>
\t\t</h3>
\t\t<div style=\"display: none;\" class=\"section-content\">
\t\t\t<div class=\"ledger-values\">
\t\t\t\t<label for=\"scen_4\">Scenario:</label>
\t\t\t\t\t<span class=\"rh-select\"><div style=\"width: 160px;\" id=\"s2id_scen_4\" class=\"select2-container scenario\"><a href=\"javascript:void(0)\" class=\"select2-choice\" tabindex=\"-1\">   <span id=\"select2-chosen-8\" class=\"select2-chosen\">Max. Affordability</span><abbr class=\"select2-search-choice-close\"></abbr>   <span class=\"select2-arrow\" role=\"presentation\"><b role=\"presentation\"></b></span></a><label for=\"s2id_autogen8\" class=\"select2-offscreen\">Scenario:</label><input id=\"s2id_autogen8\" aria-labelledby=\"select2-chosen-8\" class=\"select2-focusser select2-offscreen\" aria-haspopup=\"true\" role=\"button\" type=\"text\"><div class=\"select2-drop select2-display-none\">   <div class=\"select2-search select2-search-hidden select2-offscreen\">       <label for=\"s2id_autogen8_search\" class=\"select2-offscreen\">Scenario:</label>       <input placeholder=\"\" id=\"s2id_autogen8_search\" aria-owns=\"select2-results-8\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" class=\"select2-input\" role=\"combobox\" aria-expanded=\"true\" aria-autocomplete=\"list\" type=\"text\">   </div>   <ul id=\"select2-results-8\" class=\"select2-results\" role=\"listbox\">   </ul></div></div><select title=\"Scenario:\" tabindex=\"-1\" id=\"scen_4\" class=\"scenario select2-offscreen\">
\t\t\t\t\t\t<option value=\"0\">Max. Affordability</option>
\t\t\t\t\t\t<option value=\"1\">Build Your Own</option>
\t\t\t\t\t</select></span>
\t\t\t</div>

\t\t\t\t<div id=\"extension-amort\">
\t\t<div id=\"extension-amort_chart\" style=\"overflow:hidden;\"></div>
\t\t<table class=\"amort-sched\">
\t\t\t<thead>
\t\t\t\t<tr><th class=\"year\">Year</th>
\t\t\t\t<th>Total Paid</th>
\t\t\t\t<th>Principal Paid</th>
\t\t\t\t<th>Interest Paid</th>
\t\t\t\t<th>Balance</th>
\t\t\t</tr></thead>
\t\t\t<tbody><tr class=\"end-of-term\"><td colspan=\"5\">Globalize.localize(\"please-complete-the-input-for-the-selected-scenario-in-order-to-continue\")</td></tr></tbody>
\t\t</table>
\t</div>
\t

\t\t</div>
\t</div>
</div>


\t\t</form>
\t</div>
</div>
     <script type=\"text/javascript\" src=\"http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 1059
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/afford.js"), "html", null, true);
        echo "\"></script>
</div>
</html>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:affordability-ca-oldl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1085 => 1059,  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 155,  150 => 80,  146 => 79,  134 => 76,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 128,  170 => 127,  148 => 90,  77 => 39,  231 => 155,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 107,  167 => 105,  137 => 94,  129 => 74,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 135,  197 => 114,  185 => 102,  181 => 101,  70 => 37,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 154,  224 => 169,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 108,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 27,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 109,  171 => 106,  166 => 126,  163 => 104,  158 => 94,  156 => 66,  151 => 81,  142 => 78,  138 => 77,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 4,  79 => 29,  72 => 38,  69 => 25,  47 => 15,  40 => 6,  37 => 5,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 43,  108 => 68,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 24,  55 => 20,  52 => 14,  50 => 21,  43 => 12,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 147,  193 => 113,  189 => 103,  187 => 144,  182 => 130,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 125,  154 => 107,  149 => 97,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 75,  125 => 73,  122 => 48,  116 => 70,  112 => 69,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 50,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 13,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
