<?php

/* AcmeDemoBundle:Demo:debt-console.html.twig */
class __TwigTemplate_4f7dadd518721c22f069d3175196b09dadf9ebc8ad3901a46bdc8912690804dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <title>Debt Consolidation Calculator</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/max-equity-cal.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/common.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/products.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/add-product.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/admin-manager.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/emicalculator.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery-ui.css"), "html", null, true);
        echo "\">
    </head>

    <body>   <div class=\"debt-left-details\">
            <form class=\"imageform\">
                <div class=\"fields\" style=\"padding:0px;\">
                    <div class=\"box-debt\">
                        Type
                    </div>
                    <div class=\"box-debt\">
                        Debt Outstanding
                    </div>
                    <div class=\"box-debt\">
                        Annual Interest
                    </div>
                    <div class=\"box-debt\">
                        Min Monthly Payment
                    </div>
                </div>
                <div class=\"fields\" style=\"padding:0px;\">
                    <div class=\"box-debt\">
                        <select>
                            <option selected>Credit Card</option>
                            <option>Automobile</option>
                            <option>Line Of Credit</option>
                            <option>Second Mortgage</option>
                            <option>New Debt</option>
                        </select>
                    </div>
                    <div class=\"box-debt\">
                        <input type=\"text\" class=\"debt-outstand\" value=\"5,000\" placeholder=\"\$\"/>
                    </div>
                    <div class=\"box-debt\">
                        <input type=\"text\" class=\"annual-interest\" placeholder=\"%\"/>
                    </div>
                    <div class=\"box-debt\">
                        <input type=\"text\" class=\"min-month\" placeholder=\"\$\"/>
                    </div>
                </div>
                <div class=\"fields debt-div\" style=\"padding:0px;\">
                    <div class=\"box-debt\">
                        <select>
                            <option>Credit Card</option>
                            <option>Automobile</option>
                            <option>Line Of Credit</option>
                            <option>Second Mortgage</option>
                            <option selected>New Debt</option>
                        </select>
                    </div>
                    <div class=\"box-debt\">
                        <input type=\"text\" class=\"debt-outstand\" value=\"10,000\" placeholder=\"\$\"/>
                    </div>
                    <div class=\"box-debt\">
                        <input type=\"text\" class=\"annual-interest\" placeholder=\"%\"/>
                    </div>
                    <div class=\"box-debt\">
                        <input type=\"text\" class=\"min-month\" placeholder=\"\$\"/>
                    </div>
                </div>
                <hr>
                <div class=\"box-debt headdebt\">
                    <a href=\"#\" class=\"add-debt\">Add New Debt</a>
                </div>
                <div style=\"clear:both\"></div>
                <div class=\"entry-content\">
                    <div id=\"emicalcalulatorinnerform\" style=\"padding: 0px 0px 10px;\">
                        <div class=\"pbox\">
                            <div class=\"lamount\">
                                <label for=\"loanamount\" class=\"orange\"><strong>Current Property Value (\$)</strong> </label>
                                <span></span></div>
                            <div class=\"datafeild\">
                                <input id=\"loanamount\" name=\"loanamount\" value=\"\" type=\"text\" />
                                <div id=\"loanamountslider\" style=\"margin-top: 45px;\"></div>
                                <div id=\"loanamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$250,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$750,000</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                </div></div></div>
                        <div class=\"pbox\">
                            <div class=\"lamount\">
                                <label for=\"leftamount\" class=\"orange\"><strong>Remaining Balance on Mortgage (\$)</strong> </label>
                                <span></span></div>
                            <div class=\"datafeild\">
                                <input id=\"leftamount\" name=\"leftamount\" value=\"\" type=\"text\" />
                                <div id=\"leftamountslider\" style=\"margin-top: 45px;\"></div>
                                <div id=\"leftamountsteps\" class=\"steps\">
                                    <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                    <span class=\"tick\" style=\"left: 25%;\">|<br/><span class=\"marker\">\$250,000</span></span>
                                    <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">\$500,000</span></span>
                                    <span class=\"tick\" style=\"left: 75%;\">|<br/><span class=\"marker\">\$750,000</span></span>
                                    <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">\$1M</span></span>
                                </div></div></div>
                    </div>
                </div>
                <div style=\"clear:both\"></div>  
                <div style=\"text-align: center;\" class=\"datadebts\">
                    <label id=\"msg\" style=\"padding: 10px;border: 1px solid;\">Equity Not Avilable</label>
                </div>
                <br/>
                <div class=\"pbox\">
                    <div class=\"lamount\">
                        <label for=\"equityamount\" class=\"orange\"><strong>How much Equity want to access? (\$)</strong> </label>
                        <span></span></div>
                    <div class=\"datafeild\">
                        <input id=\"equityamount\" name=\"equityamount\" value=\"15,000\" type=\"text\" disabled=\"disabled\"/>
                        <div id=\"equityamountslider\" style=\"margin-top: 45px;\"></div>
                        <div id=\"equityamountsteps\" class=\"steps\">
                            <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                            <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">Max Equity</span></span>
                        </div></div></div>
                <div style=\"clear:both\"></div>
                <div style=\"text-align: center;\" class=\"datadebts\">
                    <label style=\"padding: 10px;border: 1px solid;\">New Mortgage Amount = <input id=\"new-mort\" value=\"\" type=\"text\" disabled=\"disabled\"/></label>
                </div>
                <div class=\"refdetail\">
                    <h2 style=\"text-align: center;\"> Estimate Penalty </h2>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\"> 
                            <label class=\"orange\">
                                <strong>Current Mortgage Payment (\$)</strong>
                            </label></div>
                        <div class=\"datafeild\">
                            <div class=\"fields\">
                                <input id=\"cur-mort\" value=\"1,250\" type=\"text\" style=\"width:50%;\"/>
                            </div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>How offen do you make payment?</strong>
                            </label></div>
                        <div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"month\" style=\"width:50%;\">
                                    <option value=\"monthly\">Monthly</option>
                                    <option value=\"semi_monthly\">Semi Monthly</option>
                                    <option value=\"acc_bi_weekly\">Accelerated Bi-Weekly</option>
                                    <option value=\"weekly\">Weekly</option>
                                </select>
                            </div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Mortgage Start Date</strong>
                            </label></div>
                        <div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"date\" style=\"width:30%;\"><option value=\"1\">1</option><option value=\"2\">2</option><option value=\"3\">3</option><option value=\"4\">4</option><option value=\"5\">5</option><option value=\"6\">6</option><option value=\"7\">7</option><option value=\"8\">8</option><option value=\"9\">9</option><option value=\"10\">10</option><option value=\"11\">11</option><option value=\"12\">12</option><option value=\"13\">13</option><option value=\"14\">14</option><option value=\"15\">15</option><option value=\"16\">16</option><option value=\"17\">17</option><option value=\"18\">18</option><option value=\"19\">19</option><option value=\"20\">20</option><option value=\"21\">21</option><option value=\"22\">22</option><option value=\"23\">23</option><option value=\"24\">24</option><option value=\"25\">25</option><option value=\"26\">26</option><option value=\"27\">27</option><option value=\"28\">28</option><option value=\"29\">29</option><option value=\"30\">30</option></select>
                                &nbsp;
                                <select id=\"month\" style=\"width:30%;\">
                                    <option value=\"1\">January</option>
                                    <option value=\"2\">February</option>
                                    <option value=\"3\">March</option>
                                    <option value=\"4\">April</option>
                                    <option value=\"5\">May</option>
                                    <option value=\"6\">June</option>
                                    <option value=\"7\">July</option>
                                    <option value=\"8\">August</option>
                                    <option value=\"9\">September</option>
                                    <option value=\"10\">October</option>
                                    <option value=\"11\">November</option>
                                    <option value=\"12\">December</option>
                                </select>
                                &nbsp;
                                <select id=\"year\" style=\"width:30%;\"><option value=\"2000\">2000</option><option value=\"2001\">2001</option><option value=\"2002\">2002</option><option value=\"2003\">2003</option><option value=\"2004\">2004</option><option value=\"2005\">2005</option><option value=\"2006\">2006</option><option value=\"2007\">2007</option><option value=\"2008\">2008</option><option value=\"2009\">2009</option><option value=\"2010\">2010</option><option value=\"2011\">2011</option><option value=\"2012\">2012</option><option value=\"2013\">2013</option><option value=\"2014\">2014</option><option value=\"2015\">2015</option><option value=\"2016\" selected>2016</option></select>
                            </div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Mortgage Original Term</strong>
                            </label></div>
                        <div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"mort-term\" style=\"width:30%;\">
                                    <option>Select Term</option>
                                    <option>1</option>
                                    <option selected>3</option>
                                    <option>5</option>
                                    <option>10</option>
                                </select></div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Type of Existing Mortgage</strong>
                            </label></div>
                        <div class=\"datafeild\">
                            <div class=\"fields\">
                                <input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"variable\" checked=\"checked\"/> Variable
                                &nbsp;&nbsp;<input type=\"radio\" name=\"mort-type\" class=\"mort-type\" value=\"fixed\" /> Fixed   
                            </div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"sep lint\">
                            <label for=\"loaninterest\" class=\"orange\"><strong>Existing Mortgage Rate (%)</strong> </label>
                            <span style=\"height: 41px;\"></span></div> <div class=\"datafeild\">
                            <input id=\"loaninterest\" name=\"loaninterest\" value=\"2.99\" type=\"text\" />
                            <div id=\"loaninterestslider\"></div>
                            <div id=\"loanintereststeps\" class=\"steps\">
                                <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                            </div>
                        </div></div>
                    <div style=\"clear:both\"></div>  
                    <div class=\"pbox\"> 
                        <div class=\"sep lint\">
                            <label for=\"newloaninterest\" class=\"orange\"><strong>New Mortgage Rate (%)</strong> </label>
                            <span style=\"height: 41px;\"></span></div> <div class=\"datafeild\">
                            <input id=\"newloaninterest\" name=\"newloaninterest\" value=\"1.99\" type=\"text\" />
                            <div id=\"newloaninterestslider\"></div>
                            <div id=\"loanintereststeps\" class=\"steps\">
                                <span class=\"tick\" style=\"left: 0%;\">|<br/><span class=\"marker\">0</span></span>
                                <span class=\"tick\" style=\"left: 16.67%;\">|<br/><span class=\"marker\">1.75</span></span>\t\t\t\t            
                                <span class=\"tick\" style=\"left: 33.34%;\">|<br/><span class=\"marker\">3.5</span></span>
                                <span class=\"tick\" style=\"left: 50%;\">|<br/><span class=\"marker\">5</span></span>
                                <span class=\"tick\" style=\"left: 66.67%;\">|<br/><span class=\"marker\">6.75</span></span>\t\t\t\t            
                                <span class=\"tick\" style=\"left: 83.34%;\">|<br/><span class=\"marker\">8.5</span></span>
                                <span class=\"tick\" style=\"left: 100%;\">|<br/><span class=\"marker\">10</span></span>
                            </div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Province</strong>
                            </label></div> <div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"province\" name=\"province\" >
                                    <option value=\"AL\">Alberta</option>
                                    <option value=\"BC\">British Columbia</option>
                                    <option value=\"MA\">Manitoba</option>
                                    <option value=\"NB\">New Brunswick</option>
                                    <option value=\"NE\">Newfoundland</option>
                                    <option value=\"NS\">Nova Scotia</option>
                                    <option value=\"NT\">Northwest Territories</option>
                                    <option value=\"NU\">Nunavut</option>
                                    <option value=\"ON\" selected=\"selected\">Ontario</option>
                                    <option value=\"PE\">Prince Edward Island</option>
                                    <option value=\"QU\">Quebec</option>
                                    <option value=\"SK\">Saskatchewan</option>
                                    <option value=\"YU\">Yukon</option>\t\t\t\t
                                </select>    
                            </div></div></div>
                    <div style=\"clear:both\"></div>
                    <div class=\"pbox\">
                        <div class=\"lamount\">
                            <label class=\"orange\">
                                <strong>Mortgage Provider</strong>
                            </label></div> <div class=\"datafeild\">
                            <div class=\"fields\">
                                <select id=\"provider\" name=\"provider\" style=\"width:50%;\">
                                    <option value=\"hsbc\">HSBC</option>
                                    <option value=\"rbc\">RBC</option>
                                    <option value=\"bmo\">BMO</option>
                                    <option value=\"other\">Other</option>
                                </select>
                            </div></div></div></div>   
                <div class=\"headdebt\"><h2 style=\"text-align: center;\">Debt Consolidation</h2></div>
                <div id=\"consolid\">
                    <div class=\"con-box-debt\" style=\"width:99%;color: #5CB426;border: none;\">Yes! You can consolidate debt through a mortgage refinance.</div>
                    <div class=\"con-box-debt\">&nbsp;</div>
                    <div class=\"con-box-debt\"><b>Current Status</b></div>
                    <div class=\"con-box-debt\"><b>After Consolidation</b></div>
                    <div class=\"con-box-debt\">Non Mortgage Debt</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"non-mort-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-non-mort-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Penalty</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"mortgage-penalty\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Mortgage Debt</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"mort-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-mort-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><b>Total Debt</b></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"total-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-total-debt\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Existing Rate</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"exist-rate\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-rate\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\">Mortagage Payment</div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"old-pay\" disabled=\"disabled\"/></div>
                    <div class=\"con-box-debt\"><input type=\"text\" value=\"\" id=\"new-pay\" disabled=\"disabled\"/></div>
                </div>
                <div id=\"non-consolid\" style=\"height: 400px;\">
                    <div class=\"con-box-debt\" style=\"width:99%;color: #E45630;border: none;\">No! You can't consolidate debt through a mortgage refinance.</div>
                </div>
            </form>
        </div>
        <script type=\"text/javascript\" src=\"";
        // line 306
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 307
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery_ss.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 308
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.widget.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 309
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.accordion.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 310
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.tabs.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 311
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/superfish.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 312
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.loadmask.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 313
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/globalize.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 314
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/debt.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 315
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.mouse.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 316
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.slider.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 317
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.ui.datepicker.min.js"), "html", null, true);
        echo "\"></script>
        <script>
            \$(\".add-debt\").click(function (e) {
                e.preventDefault();
                \$(\".debt-div:last\").clone().insertAfter(\".debt-div:last\");
            });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:debt-console.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 98,  170 => 97,  148 => 90,  77 => 39,  231 => 155,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 107,  167 => 105,  137 => 94,  129 => 92,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 128,  197 => 114,  185 => 102,  181 => 101,  70 => 37,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 154,  224 => 169,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 108,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 27,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 109,  171 => 106,  166 => 96,  163 => 104,  158 => 94,  156 => 66,  151 => 81,  142 => 59,  138 => 54,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 5,  94 => 34,  89 => 20,  85 => 32,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 29,  72 => 38,  69 => 25,  47 => 15,  40 => 8,  37 => 5,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 47,  96 => 37,  83 => 33,  74 => 27,  66 => 24,  55 => 20,  52 => 14,  50 => 21,  43 => 12,  41 => 10,  35 => 9,  32 => 6,  29 => 3,  209 => 117,  203 => 148,  199 => 147,  193 => 113,  189 => 103,  187 => 144,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 95,  154 => 107,  149 => 97,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 75,  125 => 73,  122 => 48,  116 => 41,  112 => 42,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 42,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 10,  36 => 7,  33 => 4,  30 => 10,);
    }
}
