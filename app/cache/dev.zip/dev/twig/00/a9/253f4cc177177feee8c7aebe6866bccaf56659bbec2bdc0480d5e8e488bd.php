<?php

/* AcmeDemoBundle:Demo:chmc-insurance.html_1.twig */
class __TwigTemplate_00a9253f4cc177177feee8c7aebe6866bccaf56659bbec2bdc0480d5e8e488bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <title>CHMC Insurance Calculator</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/calculators.css"), "html", null, true);
        echo "\">
    </head>
<body><div id=\"main\">
    <h1 align=\"center\">Mortgage Insurance Calculator</h1>
    
      <div class=\"askp\" ><h3 style=\"display:inline;\">Property Value</h3>
    &nbsp;&nbsp;<input type=\"text\" value=\"\" id=\"askprice\"/>
    &nbsp;&nbsp;<input type=\"button\" value=\"GO\" id=\"go\"/>
    <br /><br /></div>
    
     <div class=\"calc\">
         <table class=\"tablem\" cellspacing=\"0\" style=\"background-color:#Fff\">
        <tr>
            <td rowspan=\"2\" style=\"background:#FCFCFC;color:#000;\">Down Payment <img src=\"http://newhopephysio.com/down.png\"></td>
            <td>
                <input type=\"text\" class=\"downtext\" value=\"5%\" />
                <input type=\"text\" class=\"downtext1\" value=\"20%\" style=\"display: none;\"/>
            </td>
            <td>
                <input type=\"text\" class=\"downtext\" value=\"10%\" />
                <input type=\"text\" class=\"downtext1\" value=\"25%\" style=\"display: none;\"/>
            </td>
            <td>
                <input type=\"text\" class=\"downtext\" value=\"15%\" />
                <input type=\"text\" class=\"downtext1\" value=\"30%\" style=\"display: none;\"/>
            </td>
            <td>
                <input type=\"text\" class=\"downtext\" value=\"20%\" />
                <input type=\"text\" class=\"downtext1\" value=\"35%\" style=\"display: none;\"/>
            </td>
        </tr>
        <tr>
            <td class=\"downpayment 0\"></td>
            <td class=\"downpayment 1\"></td>
            <td class=\"downpayment 2\"></td>
            <td class=\"downpayment 3\"></td>
        </tr>
        <tr>
            <td style=\"background:#FCFCFC;color:#000;\">Amortization period</td>
            <td>
                <select id=\"ammort\" class=\"ammort\">
                   <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30' disabled=\"disabled\">30 years</option>
                    <option value='35' disabled=\"disabled\">35 years</option>
                </select>
                <select id=\"ammort1\" class=\"ammort1\" style=\"display: none;\">
                   <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30'>30 years</option>
                    <option value='35'>35 years</option>
                </select>
            </td>
            <td>
                <select class=\"ammort\">
                    <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30' disabled=\"disabled\">30 years</option>
                    <option value='35' disabled=\"disabled\">35 years</option>
                </select>
                <select class=\"ammort1\" style=\"display: none;\">
                   <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30'>30 years</option>
                    <option value='35'>35 years</option>
                </select>
            </td>
            <td>
                <select class=\"ammort\">
                    <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30' disabled=\"disabled\">30 years</option>
                    <option value='35' disabled=\"disabled\">35 years</option>
                </select>
                <select class=\"ammort1\" style=\"display: none;\">
                   <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30'>30 years</option>
                    <option value='35'>35 years</option>
                </select>
            </td>
            <td>
                <select class=\"ammort\">
                    <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30'>30 years</option>
                    <option value='35'>35 years</option>
                </select>
                <select class=\"ammort1\" style=\"display: none;\">
                   <option value='0'>Select</option>
                    <option value='5'>5 years</option>
                    <option value='10'>10 years</option>
                    <option value='15'>15 years</option>
                    <option value='20'>20 years</option>
                    <option value='25'>25 years</option>
                    <option value='30'>30 years</option>
                    <option value='35'>35 years</option>
                </select>
            </td>
        </tr>
        <tr>
            <td style=\"background:#FCFCFC;color:#000; height:55px;\">Mortgage Insurance <img src=\"http://newhopephysio.com/plus.png\"></td>
            <td class=\"insurance 0\"></td>
            <td class=\"insurance 1\"></td>
            <td class=\"insurance 2\"></td>
            <td class=\"insurance 3\"></td>
        </tr>
        <tr style=\"background:#FCFCFC;\">
            <td style=\"color:#000; background-color: #FCFCFC;\">Total Mortgage Required <img src=\"http://newhopephysio.com/equal.png\"></td>
            <td class=\"reqdmortgage 0\"></td>
            <td class=\"reqdmortgage 1\"></td>
            <td class=\"reqdmortgage 2\"></td>
            <td class=\"reqdmortgage 3\"></td>
        </tr> 
    </table>
     </div>
<div style=\"clear:both;\"></div>
    
  </div>
</body>
</html>


  <script type=\"text/javascript\" src=\"";
        // line 155
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script>
        
        function formatdollor(n, currency) {
          return currency + \" \" + n.toFixed(1).replace(/(\\d)(?=(\\d{3})+\\.)/g, \"\$1,\").replace(\".0\",\"\");
        }
        
        \$(document).on(\"change\",\"#ammort\",function(){
            \$(\".ammort\").each(function(){
              \$(this).val(\$(\"#ammort\").val());
            });
        });
        
        \$(document).on(\"change\",\"#ammort1\",function(){
            \$(\".ammort1\").each(function(){
             \$(this).val(\$(\"#ammort1\").val());
            });
        });
        
        \$(document).on(\"keydown\",\"#askprice\",function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if (\$.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    
    \$(\"#askprice\").blur(function(){
        var num=parseInt(\$(this).val().replace(/[^0-9-.]/g, ''));
        \$(this).val(formatdollor(num,\"\$\"));
        ajax_call();
    });
    
    \$(\".downtext\").blur(function(){
        ajax_call();
    });
       
       \$(document).on(\"click\",\"#go\",function(){
          ajax_call();
       });
        
       function ajax_call()
       {
          
        if(\$(\"#askprice\").val() === '')
        {
          alert('enter asking price');
          \$(\"#askprice\").focus();
        }
        else{
        var downpays = [];
        var downpaycheck=0;
         
         if(parseInt(\$(\"#askprice\").val().replace(/[^0-9-.]/g, '')) >= 1000000)
         {
             \$(\".downtext\").hide();
             \$(\".downtext1\").show();
             \$(\".ammort1\").show();
             \$(\".ammort\").hide();
             \$(\".downtext1\").each(function(){             
             if(parseInt(\$(this).val()) < 5)
             { downpaycheck = 1;}
             else{
             downpays.push(\$(this).val());
             }
             });
         }
         else
         {
            \$(\".downtext1\").hide();
            \$(\".downtext\").show();
            \$(\".ammort\").show();
            \$(\".ammort1\").hide();
            \$(\".downtext\").each(function(){
             
             if(parseInt(\$(this).val()) < 5)
             { downpaycheck = 1;}
             else{
             downpays.push(\$(this).val());
             }
             }); 
         }
         
        var downpays_str = downpays.join('|');
        
        if(downpaycheck === 0)
        {
        \$.ajax({
                  type: \"post\",
                  url: \"/get-mortgage\",
                  async: true,
                  data : {'askprice' : parseInt(\$(\"#askprice\").val().replace(/[^0-9-.]/g, '')),'downpays':downpays_str},
                  success: function(response){ 
                     var data=JSON.parse(response);
                    
                     for(var key in data) 
                     {
                        \$(\".downpayment.\"+key).html(formatdollor(data[key]['downpayment'],\"\$\"));
                        \$(\".insurance.\"+key).html(formatdollor(data[key]['insurance'],\"\$\"));
                        \$(\".reqdmortgage.\"+key).html(formatdollor(data[key]['reqdmortgage'],\"\$\"));
                     }
                  },
                  error: function (request,error) {
                     alert('No data');
                }
        }); 
        }
        else{
           alert('Down payment not allowed below 5%');
         }
        } 
       }
        
    </script>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:chmc-insurance.html_1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 137,  198 => 134,  194 => 133,  190 => 132,  186 => 131,  178 => 155,  150 => 80,  146 => 79,  134 => 76,  124 => 72,  104 => 67,  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 128,  170 => 127,  148 => 90,  77 => 39,  231 => 155,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 107,  167 => 105,  137 => 94,  129 => 74,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 135,  197 => 114,  185 => 102,  181 => 101,  70 => 37,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 136,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 138,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 154,  224 => 169,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 108,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 27,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 109,  171 => 106,  166 => 126,  163 => 104,  158 => 94,  156 => 66,  151 => 81,  142 => 78,  138 => 77,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 29,  72 => 38,  69 => 25,  47 => 15,  40 => 6,  37 => 5,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 71,  115 => 44,  111 => 43,  108 => 68,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 24,  55 => 20,  52 => 14,  50 => 21,  43 => 12,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 147,  193 => 113,  189 => 103,  187 => 144,  182 => 130,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 125,  154 => 107,  149 => 97,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 75,  125 => 73,  122 => 48,  116 => 70,  112 => 69,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 50,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 13,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
