<?php

/* MainRatetradeBundle:Default:ParentGuide.html.twig */
class __TwigTemplate_8d70de0b517edb0f6143307eda1b957716e74aa6b2cc315f63ddfd2097c7804f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title>";
        // line 4
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "category"), "html", null, true);
        }
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"";
        // line 10
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "category"), "html", null, true);
        }
        echo "\">
        <meta name=\"description\" content=\"";
        // line 11
        echo (isset($context["mdesc"]) ? $context["mdesc"] : $this->getContext($context, "mdesc"));
        echo "\"> 
        <meta name=\"keyword\" content=\"";
        // line 12
        if (((isset($context["mkeywords"]) ? $context["mkeywords"] : $this->getContext($context, "mkeywords")) != "")) {
            echo (isset($context["mkeywords"]) ? $context["mkeywords"] : $this->getContext($context, "mkeywords"));
        } else {
            echo twig_escape_filter($this->env, (isset($context["mkeywords"]) ? $context["mkeywords"] : $this->getContext($context, "mkeywords")), "html", null, true);
        }
        echo "\">
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"";
        // line 14
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "category"), "html", null, true);
        }
        echo "\">
        <meta name=\"og:description\" content=\"";
        // line 15
        echo (isset($context["mdesc"]) ? $context["mdesc"] : $this->getContext($context, "mdesc"));
        echo "\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"";
        // line 19
        echo (isset($context["mdesc"]) ? $context["mdesc"] : $this->getContext($context, "mdesc"));
        echo "\">
        <meta name=\"twitter:title\" content=\"";
        // line 20
        if (((isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle")) != "")) {
            echo (isset($context["pgtitle"]) ? $context["pgtitle"] : $this->getContext($context, "pgtitle"));
        } else {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "category"), "html", null, true);
        }
        echo "\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" /> 
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
       
<style>
.content-boxes{
  border:none!important;
}
</style>
    

   
          ";
        // line 47
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
        <!-- /HEADER -->
    <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">";
        // line 56
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "category"), "html", null, true);
        echo "</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">";
        // line 60
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "category"), "html", null, true);
        echo "</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->

        <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes parentinfo\">
                            <div class=\"left-content\">

                                ";
        // line 82
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationdata"]) ? $context["educationdata"] : $this->getContext($context, "educationdata")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 83
            echo "
                                   <a href=\"";
            // line 84
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "pageUrl"))), "html", null, true);
            echo "\"><div class=\"tab-boxes\"><div class=\"boxinside\"></div>
                                        <div class=\"row\">
                                       
                                                 <img src=\"";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "image"), "html", null, true);
            echo "\" alt=\"No image Avilable\" class=\"img-responsive tabbox-img\"> <h3 class=\"education-heading\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "category"), "html", null, true);
            echo "</h3>
                                                <p>";
            // line 88
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "parentPageContent"), "html", null, true);
            echo ".....</p>
                                              
                                        </div>
                                    </div></a>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "                            </div>
                        </div>
<div class=\"clear\"></div>
    </div>
                      </article>  </div>











<!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children\">
                                                <li><a href=\"";
        // line 121
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 122
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 123
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 124
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                                <li><a href=\"";
        // line 125
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 126
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 127
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 128
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 129
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 130
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                     ";
        // line 136
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "6")) {
            // line 137
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 139
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 141
        echo "                                                         
                                                     ";
        // line 142
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 143
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 144
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 146
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 147
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    ";
        // line 153
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "18")) {
            // line 154
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 156
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 158
        echo "                                   
                                                            ";
        // line 159
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 160
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 161
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 163
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 164
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                      ";
        // line 169
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "1")) {
            // line 170
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 172
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 174
        echo "                                         ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 175
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 176
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 178
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 179
        echo "                                    </ul>
                                </li>
                                

  <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Mortgage Information</a>
                                      ";
        // line 186
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "47")) {
            // line 187
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 189
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 191
        echo "                                         ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 192
            echo "                                                                    ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "47")) {
                // line 193
                echo "                                                                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                                        ";
            }
            // line 195
            echo "                                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 196
        echo "                                    </ul>
                                </li>


 ";
        // line 200
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "39")) {
            echo "<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Auto Insurance</a>
                                      ";
            // line 203
            if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "39")) {
                // line 204
                echo "                                                        <ul class=\"children active\">
                                                        ";
            } else {
                // line 206
                echo "                                                           <ul class=\"children\"> 
                                                            ";
            }
            // line 208
            echo "                                         ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
            foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                // line 209
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "39")) {
                    // line 210
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 212
                echo "                                                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 213
            echo "                                    </ul>
                                </li>

";
        }
        // line 217
        echo "

 ";
        // line 219
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "44")) {
            echo "<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Insurance</a>
                                      ";
            // line 222
            if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "44")) {
                // line 223
                echo "                                                        <ul class=\"children active\">
                                                        ";
            } else {
                // line 225
                echo "                                                           <ul class=\"children\"> 
                                                            ";
            }
            // line 227
            echo "                                         ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
            foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                // line 228
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "44")) {
                    // line 229
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 231
                echo "                                                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 232
            echo "                                    </ul>
                                </li>

";
        }
        // line 236
        echo "



                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
                   
                                 </aside>
                    <!-- /SIDEBAR -->
</div></div></section>


        ";
        // line 250
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo " 
  
        <script>

            function validateEmail(email) {
                var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                return re.test(email);
            }

            \$(document).on(\"click\", \".subsc\", function(e) {
                e.preventDefault();
                \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                if (\$(\"#exampleInputEmail2\") == '')
                {
                    \$(\"#exampleInputEmail2\").focus();
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                {
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                    \$(\"#exampleInputEmail2\").focus();
                }
                else {
                    \$.ajax({
                        url: '";
        // line 275
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                        type: \"post\",
                        async: true,
                        data: {'email': \$(\"#exampleInputEmail2\").val(),
                            'name': \"testname\"},
                        success: function(response) {
                            \$(\"#exampleInputEmail2\").val('');
                            alert(response);
                        },
                        error: function(request, error) {
                            // alert('No data found');
                        }
                    });
                }
            });

            \$('.locations').on('click', function(e) {
                e.preventDefault();
                \$('.location-name-box').toggle(500);
            });
            \$('.level1Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level1 ul').toggle(200);

            });
            \$('.level2Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level2 ul').toggle(200);

            });
            \$('.level3Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level3 ul').toggle(200);

            });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:ParentGuide.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  575 => 250,  488 => 209,  776 => 467,  703 => 397,  573 => 280,  557 => 276,  401 => 183,  287 => 131,  1156 => 880,  1083 => 810,  963 => 692,  957 => 691,  949 => 689,  942 => 687,  933 => 685,  887 => 642,  859 => 616,  853 => 615,  842 => 612,  838 => 611,  830 => 605,  824 => 604,  813 => 601,  800 => 593,  794 => 592,  786 => 590,  783 => 589,  779 => 588,  768 => 580,  764 => 579,  760 => 578,  756 => 577,  752 => 576,  748 => 575,  744 => 574,  740 => 573,  732 => 571,  405 => 184,  333 => 146,  307 => 137,  299 => 152,  257 => 136,  807 => 497,  617 => 312,  611 => 311,  596 => 307,  591 => 306,  491 => 210,  431 => 187,  415 => 196,  291 => 149,  284 => 127,  736 => 572,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 283,  582 => 328,  578 => 327,  317 => 150,  565 => 320,  468 => 219,  281 => 177,  465 => 216,  361 => 157,  332 => 173,  328 => 147,  320 => 143,  276 => 125,  272 => 124,  245 => 131,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 278,  563 => 230,  559 => 236,  550 => 223,  547 => 231,  542 => 219,  514 => 281,  492 => 252,  484 => 201,  410 => 173,  397 => 182,  388 => 169,  380 => 219,  366 => 214,  331 => 141,  323 => 139,  315 => 141,  300 => 131,  296 => 130,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 249,  442 => 237,  417 => 178,  372 => 159,  336 => 164,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 249,  509 => 245,  482 => 217,  386 => 194,  357 => 158,  353 => 156,  344 => 176,  339 => 147,  335 => 175,  329 => 153,  321 => 151,  610 => 410,  462 => 192,  394 => 172,  370 => 215,  364 => 160,  349 => 154,  340 => 175,  325 => 144,  319 => 194,  304 => 185,  295 => 150,  289 => 176,  280 => 126,  126 => 79,  845 => 613,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 229,  531 => 227,  516 => 319,  476 => 233,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 149,  303 => 154,  292 => 129,  288 => 128,  510 => 280,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 198,  411 => 194,  389 => 180,  378 => 181,  311 => 139,  708 => 550,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 223,  512 => 246,  483 => 208,  452 => 241,  448 => 206,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 602,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 32,  277 => 176,  521 => 222,  513 => 271,  508 => 216,  499 => 212,  495 => 247,  489 => 261,  472 => 257,  396 => 234,  392 => 185,  377 => 177,  356 => 179,  352 => 178,  348 => 177,  192 => 112,  883 => 685,  699 => 504,  449 => 250,  432 => 222,  428 => 180,  414 => 178,  406 => 176,  403 => 175,  399 => 204,  390 => 170,  376 => 164,  373 => 176,  369 => 175,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 262,  535 => 296,  527 => 225,  524 => 298,  520 => 248,  505 => 213,  497 => 245,  494 => 231,  479 => 206,  475 => 204,  467 => 200,  458 => 253,  454 => 207,  450 => 205,  446 => 204,  184 => 86,  180 => 106,  172 => 104,  160 => 101,  152 => 57,  937 => 686,  809 => 600,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 334,  603 => 275,  599 => 351,  553 => 232,  536 => 228,  530 => 294,  522 => 219,  519 => 289,  515 => 219,  507 => 282,  501 => 214,  493 => 208,  490 => 219,  486 => 251,  477 => 270,  471 => 247,  463 => 242,  460 => 191,  456 => 228,  445 => 205,  441 => 268,  433 => 203,  429 => 186,  424 => 254,  420 => 179,  416 => 192,  412 => 229,  385 => 179,  382 => 193,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 282,  576 => 319,  572 => 318,  568 => 254,  561 => 277,  546 => 300,  540 => 302,  532 => 284,  529 => 295,  525 => 215,  517 => 272,  511 => 217,  503 => 206,  500 => 205,  496 => 220,  487 => 207,  481 => 200,  473 => 203,  470 => 196,  466 => 194,  455 => 195,  451 => 224,  447 => 193,  443 => 237,  439 => 191,  434 => 245,  426 => 200,  422 => 232,  400 => 235,  395 => 172,  114 => 19,  260 => 121,  256 => 103,  248 => 114,  266 => 124,  262 => 121,  250 => 116,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 142,  275 => 141,  271 => 140,  267 => 137,  263 => 123,  259 => 122,  255 => 129,  239 => 185,  81 => 53,  65 => 21,  1085 => 1059,  210 => 121,  198 => 103,  194 => 133,  190 => 101,  186 => 103,  178 => 35,  150 => 55,  146 => 27,  134 => 24,  124 => 38,  104 => 33,  391 => 231,  383 => 214,  375 => 163,  371 => 159,  367 => 161,  363 => 177,  359 => 168,  351 => 171,  347 => 153,  188 => 87,  301 => 185,  293 => 149,  113 => 90,  174 => 76,  170 => 33,  148 => 29,  77 => 52,  231 => 110,  165 => 106,  161 => 78,  153 => 92,  195 => 106,  191 => 42,  34 => 8,  155 => 93,  310 => 197,  306 => 196,  302 => 195,  290 => 126,  286 => 146,  282 => 128,  274 => 153,  270 => 194,  251 => 128,  237 => 127,  233 => 138,  225 => 135,  213 => 87,  205 => 78,  175 => 60,  167 => 96,  137 => 84,  129 => 94,  23 => 3,  223 => 119,  215 => 110,  211 => 124,  207 => 84,  202 => 118,  197 => 88,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 211,  350 => 210,  346 => 220,  342 => 165,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 142,  206 => 92,  244 => 112,  236 => 133,  232 => 106,  228 => 84,  216 => 96,  212 => 95,  200 => 82,  110 => 36,  90 => 34,  84 => 28,  53 => 15,  127 => 33,  97 => 62,  76 => 19,  58 => 11,  480 => 234,  474 => 198,  469 => 284,  461 => 196,  457 => 241,  453 => 206,  444 => 192,  440 => 246,  437 => 197,  435 => 189,  430 => 257,  427 => 211,  423 => 194,  413 => 226,  409 => 238,  407 => 192,  402 => 130,  398 => 174,  393 => 181,  387 => 215,  384 => 168,  381 => 164,  379 => 230,  374 => 227,  368 => 182,  365 => 189,  362 => 156,  360 => 159,  355 => 167,  341 => 156,  337 => 155,  322 => 143,  314 => 158,  312 => 136,  309 => 148,  305 => 136,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 195,  268 => 123,  264 => 122,  258 => 97,  252 => 117,  247 => 149,  241 => 129,  229 => 109,  220 => 113,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 28,  61 => 14,  273 => 140,  269 => 94,  254 => 135,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 93,  227 => 129,  224 => 126,  221 => 98,  219 => 88,  217 => 125,  208 => 96,  204 => 83,  179 => 99,  159 => 94,  143 => 37,  135 => 35,  119 => 31,  102 => 34,  71 => 24,  67 => 29,  63 => 22,  59 => 27,  201 => 89,  196 => 113,  183 => 100,  171 => 97,  166 => 32,  163 => 95,  158 => 30,  156 => 47,  151 => 92,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 61,  91 => 24,  62 => 27,  49 => 14,  87 => 28,  28 => 8,  94 => 35,  89 => 55,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 56,  88 => 29,  78 => 31,  46 => 23,  44 => 12,  27 => 7,  79 => 26,  72 => 25,  69 => 15,  47 => 24,  40 => 10,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 53,  139 => 36,  131 => 34,  123 => 32,  120 => 37,  115 => 30,  111 => 29,  108 => 34,  101 => 18,  98 => 36,  96 => 31,  83 => 27,  74 => 30,  66 => 43,  55 => 26,  52 => 12,  50 => 15,  43 => 23,  41 => 12,  35 => 8,  32 => 12,  29 => 9,  209 => 117,  203 => 94,  199 => 93,  193 => 90,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 56,  164 => 102,  162 => 31,  154 => 29,  149 => 69,  147 => 25,  144 => 67,  141 => 85,  133 => 44,  130 => 23,  125 => 93,  122 => 72,  116 => 36,  112 => 35,  109 => 68,  106 => 41,  103 => 27,  99 => 26,  95 => 25,  92 => 30,  86 => 33,  82 => 32,  80 => 20,  73 => 20,  64 => 32,  60 => 40,  57 => 16,  54 => 16,  51 => 25,  48 => 11,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
