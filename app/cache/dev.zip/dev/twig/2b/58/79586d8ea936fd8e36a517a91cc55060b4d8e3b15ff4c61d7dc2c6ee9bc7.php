<?php

/* MainRatetradeBundle:Default:mort-rates.html.twig */
class __TwigTemplate_2b5879586d8ea936fd8e36a517a91cc55060b4d8e3b15ff4c61d7dc2c6ee9bc7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title>Best Mortgage Rates in Canada</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"Best Mortgage Rates in Canada\">
        <meta name=\"description\" content=\"Best Mortgage Rates in Canada\"> 
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"Best Mortgage Rates in Canada\">
        <meta name=\"og:description\" content=\"Best Mortgage Rates in Canada\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"Best Mortgage Rates in Canada\">
        <meta name=\"twitter:title\" content=\"Best Mortgage Rates in Canada\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" /> 
      <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
     <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
        <script language=\"JavaScript\" 
                src=\"https://www.iplocationtools.com/iplocationtools.js?key=7b71786a7773756d6a207270\">
        </script>
    
       ";
        // line 41
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
    <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Best Mortgage Rates in Canada</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">Best Mortgage Rates in Canada</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->
       <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
 <div class=\"searcharea\">

                <div class=\"search-box\">


                    ";
        // line 79
        echo "                    <div class=\"form-group findhead\"><strong>Find Your Suitable Rate!</strong></div>
                    <div class=\"form-group\">
                        <label for=\"inputEmail3\" class=\"control-label\">Rate Type</label>
                        <select name=\"ratetype\" class=\"form-control\">
                           <option value=\"fixed\">Fixed</option>
                           <option value=\"variable\">Variable</option>
                        </select>
                    </div>

                    <div class=\"form-group\" style=\"display:none\">
                        <label for=\"inputYear\" class=\"control-label\">Select Year</label>
                        <select name=\"Year\" class=\"form-control\">
                            ";
        // line 91
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["terms"]) ? $context["terms"] : $this->getContext($context, "terms")));
        foreach ($context['_seq'] as $context["_key"] => $context["t"]) {
            // line 92
            echo "                                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : $this->getContext($context, "t")), "termUrl"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["t"]) ? $context["t"] : $this->getContext($context, "t")), "term"), "html", null, true);
            echo "</option>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 94
        echo "                        </select>
                    </div>

                    <div class=\"form-group\">
                        <label for=\"inputYear\" class=\"control-label\">Select Location</label>
                        <select name=\"locationList\" id=\"locationList\" class=\"form-control\" onClick=\"getSelected()\" >
                            ";
        // line 100
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 101
            echo "                                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "urlLink"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
            echo "</option>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "                        </select>
                    </div>

                    <div class=\"form-group smbb\">
                        <button type=\"button\" class=\"btn btn-danger btn-lg get-rates\">Get Rate Now</button>
                    </div>
                    ";
        // line 110
        echo "                </div>
            </div>
        
        <div class=\"clear\"></div>
      
                                    <p>
                                        At our website, you can search and compare the lowest interest rates being offered by the most competitive brokers, lenders and banks in Canada. Our Canadian comparison charts list current rates and are updated regularly throughout the day.
                                    </p>
                                    <!-- Div Box -->   
                                    <div class=\"best-rate-box\">
                                        <table align=\"left\" cellspacing=\"0\" cellpadding=\"0\" class=\"table-rates fixed\">
                                            <tbody>
                                                <tr>
                                                    <th scope=\"col\">Rate</th>
                                                    <th scope=\"col\" align=\"center\">Term</th>
                                                    <th scope=\"col\" align=\"center\">Type</th>
                                                    <th scope=\"col\" align=\"center\">&nbsp;</th>
                                                </tr>

                                                ";
        // line 129
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rates"]) ? $context["rates"] : $this->getContext($context, "rates")));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 130
            echo "                                                    <tr>
                                                        <td>
                                                            <span class=\"rt-rate\">
                                                                ";
            // line 133
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "<sup>%</sup>
                                                            </span>
                                                        </td>  
                                                        <td class=\"terms\">";
            // line 136
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "html", null, true);
            echo "</td>
                                                        <td class=\"type\">";
            // line 137
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"), "html", null, true);
            echo "</td>
                                                        <td><span class=\"get_this-rate\">
                                                                <a rt-popup=\"\" href=\"#\" data-toggle=\"modal\" data-target=\"#agentModal1\" class=\"rate-btn ";
            // line 139
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "\">
                                                                    <span class=\"wide\">
                                                                        <button class=\"btn btn-success rh-button\">
                                                                            Apply Now
                                                                        </button>
                                                                    </span>
                                                                </a>
                                                            </span>
                                                            <a rt-popup=\"\" href=\"";
            // line 147
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("compare_rates", array("rate" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "term" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "type" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"))), "html", null, true);
            echo "\">
                                                                Compare
                                                            </a>
                                                        </td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 153
        echo "                                            </tbody>
                                        </table>
                                    </div>

                                    <div class=\"fvdiv\">
                                        <strong>Fixed Mortgage Rates vs. Variable Mortgage Rates</strong>
                                        <p>While searching for mortgage, the first and foremost decision one needs to make is to select between fixed and variable rate mortgages.
                                            When you choose for fixed rate mortgage, then payment you make each month will stay constant for the term of your mortgage. With a variable rate mortgage, the mortgage rate will change with prime lending rate as set by your lender
                                            When you choose for fixed rate mortgage, you are \"locked in\" to a given rate and protected from rate fluctuations. These mortgages are preferable when borrowers are risk averse and/or they have purchased property at the high end of their affordability range. Variable mortgage rates change as per market conditions at anytime; however they have been proven less expensive over time. These are based on Bank of Canada prime rate less a discount.
                                            Your income, lifestyle and risk tolerance are important factors to be considered for determining which mortgage product suits you the best.</p>
                                    </div>





 <strong class=\"chrate chrate1\">Choose Mortgage Rates By Province</strong>
                                    <br/> <ul class=\"listfrate\">
                                    ";
        // line 171
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["province"]) ? $context["province"] : $this->getContext($context, "province")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 172
            echo "                                       
                                            <li><a href=\"";
            // line 173
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ncity_ratetypes", array("target" => $this->getAttribute((isset($context["p"]) ? $context["p"] : $this->getContext($context, "p")), "urlLink"))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["p"]) ? $context["p"] : $this->getContext($context, "p")), "province"), "html", null, true);
            echo " Mortgage Rates</a></li>
                                                   
                                                   

                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 177
        echo " </ul><div class=\"clear\"></div>
                                




                            </div></div></article>
                        </div>
                        <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children active\">
                                                <li><a href=\"";
        // line 197
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 198
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 199
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 200
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                                <li><a href=\"";
        // line 201
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 202
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 203
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 204
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 205
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 206
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                     </ul>
                                </li>
                                <li> 
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                    <ul class=\"children\">
                                        
                                                ";
        // line 214
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 215
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 216
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 218
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 219
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    <ul class=\"children\">
                                       ";
        // line 226
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 227
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 228
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 230
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 231
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    <ul class=\"children\">
                                      ";
        // line 237
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 238
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 239
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 241
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 242
        echo "                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
              
                                 </aside>
                    <!-- /SIDEBAR -->
                </div>
            </div>
        </section>
        ";
        // line 255
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact For Rate <span id=\"rate-r\"></span> %</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 298
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 299
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 300
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 302
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 304
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 305
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\">Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"modal-footer\">

                    </div>
                </div>
            </div>
        </div>
        
        <script>
                                                    \$(document).on(\"click\", \".rate-btn\", function (e) {
                                                        e.preventDefault();
                                                        \$(\"#rate-request\").val(\$(this).attr(\"class\").split(\" \")[1]);
                                                        \$(\"#rate-r\").html(\$(this).attr(\"class\").split(\" \")[1]);
                                                    });

                                                    \$(document).ready(function () {
                                                        if(ip2location_country_long() === 'Canada')
                                                        {
                                                        \$(\"#agentLocationName\").val(ip2location_city());
                                                        \$(\"#agentLocation\").find(\"option:contains('\" + ip2location_city() + \"')\").prop(\"selected\", true);
                                                        }
                                                        else
                                                        {
                                                        \$(\"#agentLocationName\").val(\"Brampton\");
                                                        \$(\"#agentLocation\").find(\"option:contains('Brampton')\").prop(\"selected\", true);
                                                        }
                                                    });

                                                    \$('.locations').on('click', function () {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function () {
                                                        \$('.level1 ul').toggle(500);

                                                    });
                                                    \$('.level2Btn').on('click', function () {
                                                        \$('.level2 ul').toggle(500);

                                                    });
                                                    \$('.level3Btn').on('click', function () {
                                                        \$('.level3 ul').toggle(500);

                                                    });

                                                    \$('#agentLocationName').click(function (e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function (e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function () {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }



                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"click\", \".subsc\", function (e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 419
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function (response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function (request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });




  \$(document).on(\"click\", \".get-rates\", function (e) {

                                var ratetype = \$(\"select[name=ratetype]\").find(\"option:selected\").val();
                                var locurl = \$(\"#locationList\").find(\"option:selected\").val();

                                if (ratetype == 'variable')
                                {
                                    if (\$(\"#locationName\").val() != '') {
                                        if (typeof locurl != 'undefined')
                                        {
                                           window.location.href = '/' + locurl + '/variable';
                                        }
                                        else
                                        {
                                            window.location.href = '";
        // line 452
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "variable"));
        echo "';
                                        }
                                    }
                                    else {
                                        window.location.href = '";
        // line 456
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "variable"));
        echo "';
                                    }
                                }
                                else
                                {
                                    if (\$(\"#locationName\").val() != '') {
                                        if (typeof locurl != 'undefined')
                                        {
                                           window.location.href = '/' + locurl + '/fixed';
                                        }
                                        else {
                                            window.location.href = '";
        // line 467
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "';
                                        }
                                    }
                                    else {
                                        window.location.href = '";
        // line 471
        echo $this->env->getExtension('routing')->getPath("mortgage_rates", array("ratetype" => "fixed"));
        echo "';
                                    }
                                }
                            });


                                                    \$(document).on(\"click\", \".subsc\", function (e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 493
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputName2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function (response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function (request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });

                                                    \$(document).on(\"change\", \".required\", function () {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function (e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 563
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function () {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function (response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                    window.location.href = '/thank-you';
                                                                },
                                                                error: function (request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:mort-rates.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 299,  478 => 255,  442 => 237,  417 => 227,  372 => 206,  336 => 197,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 255,  509 => 251,  482 => 240,  386 => 195,  357 => 182,  353 => 180,  344 => 199,  339 => 176,  335 => 175,  329 => 174,  321 => 171,  610 => 410,  462 => 280,  394 => 239,  370 => 186,  364 => 204,  349 => 212,  340 => 198,  325 => 172,  319 => 194,  304 => 185,  295 => 179,  289 => 176,  280 => 170,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 304,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 228,  531 => 226,  516 => 319,  476 => 204,  464 => 230,  421 => 183,  343 => 152,  324 => 135,  316 => 129,  313 => 128,  303 => 123,  292 => 115,  288 => 114,  510 => 235,  506 => 234,  502 => 233,  498 => 232,  425 => 197,  419 => 196,  411 => 194,  389 => 184,  378 => 181,  311 => 147,  708 => 448,  619 => 362,  580 => 326,  558 => 306,  552 => 305,  544 => 303,  537 => 301,  523 => 294,  512 => 252,  483 => 226,  452 => 227,  448 => 226,  436 => 223,  408 => 193,  404 => 219,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 658,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 182,  100 => 41,  277 => 141,  521 => 255,  513 => 253,  508 => 216,  499 => 248,  495 => 247,  489 => 229,  472 => 203,  396 => 202,  392 => 201,  377 => 188,  356 => 202,  352 => 201,  348 => 200,  192 => 118,  883 => 685,  699 => 504,  449 => 239,  432 => 222,  428 => 230,  414 => 253,  406 => 201,  403 => 244,  399 => 203,  390 => 216,  376 => 233,  373 => 191,  369 => 190,  265 => 161,  261 => 104,  253 => 161,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 263,  535 => 227,  527 => 313,  524 => 298,  520 => 254,  505 => 250,  497 => 301,  494 => 231,  479 => 239,  475 => 238,  467 => 288,  458 => 196,  454 => 208,  450 => 194,  446 => 238,  184 => 38,  180 => 106,  172 => 104,  160 => 91,  152 => 30,  937 => 621,  809 => 496,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 433,  729 => 432,  682 => 397,  678 => 396,  674 => 395,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 353,  603 => 352,  599 => 351,  553 => 323,  536 => 293,  530 => 292,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 295,  477 => 270,  471 => 289,  463 => 242,  460 => 229,  456 => 228,  445 => 257,  441 => 268,  433 => 203,  429 => 185,  424 => 254,  420 => 228,  416 => 252,  412 => 251,  385 => 233,  382 => 277,  118 => 38,  597 => 325,  593 => 324,  589 => 323,  585 => 340,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 297,  529 => 295,  525 => 256,  517 => 254,  511 => 304,  503 => 249,  500 => 284,  496 => 243,  487 => 207,  481 => 293,  473 => 274,  470 => 273,  466 => 228,  455 => 276,  451 => 224,  447 => 193,  443 => 192,  439 => 260,  434 => 231,  426 => 214,  422 => 264,  400 => 242,  395 => 185,  114 => 37,  260 => 189,  256 => 103,  248 => 186,  266 => 193,  262 => 147,  250 => 189,  242 => 136,  234 => 185,  226 => 183,  222 => 182,  218 => 105,  279 => 111,  275 => 194,  271 => 193,  267 => 137,  263 => 191,  259 => 158,  255 => 155,  239 => 185,  81 => 31,  65 => 27,  1085 => 1059,  210 => 137,  198 => 103,  194 => 133,  190 => 41,  186 => 131,  178 => 35,  150 => 58,  146 => 79,  134 => 24,  124 => 72,  104 => 67,  391 => 317,  383 => 214,  375 => 313,  371 => 159,  367 => 158,  363 => 157,  359 => 156,  351 => 179,  347 => 153,  188 => 36,  301 => 173,  293 => 151,  113 => 90,  174 => 34,  170 => 33,  148 => 29,  77 => 30,  231 => 130,  165 => 106,  161 => 105,  153 => 92,  195 => 96,  191 => 95,  34 => 8,  155 => 27,  310 => 188,  306 => 145,  302 => 237,  290 => 198,  286 => 197,  282 => 143,  274 => 153,  270 => 194,  251 => 139,  237 => 114,  233 => 138,  225 => 135,  213 => 152,  205 => 116,  175 => 94,  167 => 30,  137 => 96,  129 => 94,  23 => 3,  223 => 137,  215 => 151,  211 => 124,  207 => 58,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 29,  358 => 223,  354 => 222,  350 => 221,  346 => 220,  342 => 166,  338 => 165,  334 => 203,  330 => 163,  326 => 165,  318 => 277,  206 => 110,  244 => 174,  236 => 133,  232 => 209,  228 => 170,  216 => 167,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 25,  53 => 11,  127 => 20,  97 => 62,  76 => 23,  58 => 26,  480 => 162,  474 => 161,  469 => 284,  461 => 155,  457 => 241,  453 => 151,  444 => 225,  440 => 224,  437 => 204,  435 => 186,  430 => 257,  427 => 260,  423 => 142,  413 => 226,  409 => 132,  407 => 205,  402 => 130,  398 => 218,  393 => 197,  387 => 215,  384 => 235,  381 => 182,  379 => 230,  374 => 180,  368 => 205,  365 => 189,  362 => 288,  360 => 203,  355 => 215,  341 => 105,  337 => 103,  322 => 214,  314 => 177,  312 => 98,  309 => 207,  305 => 157,  298 => 172,  294 => 171,  285 => 89,  283 => 196,  278 => 195,  268 => 191,  264 => 190,  258 => 133,  252 => 187,  247 => 187,  241 => 159,  229 => 107,  220 => 168,  214 => 104,  177 => 83,  169 => 131,  140 => 27,  132 => 25,  128 => 85,  107 => 60,  61 => 12,  273 => 140,  269 => 94,  254 => 102,  243 => 186,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 152,  217 => 122,  208 => 165,  204 => 108,  179 => 33,  159 => 28,  143 => 54,  135 => 77,  119 => 75,  102 => 34,  71 => 12,  67 => 29,  63 => 22,  59 => 27,  201 => 115,  196 => 113,  183 => 100,  171 => 31,  166 => 32,  163 => 29,  158 => 30,  156 => 100,  151 => 26,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 67,  91 => 50,  62 => 27,  49 => 10,  87 => 16,  28 => 8,  94 => 35,  89 => 20,  85 => 14,  75 => 31,  68 => 21,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 56,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 32,  72 => 13,  69 => 40,  47 => 24,  40 => 11,  37 => 5,  22 => 2,  246 => 137,  157 => 98,  145 => 92,  139 => 78,  131 => 45,  123 => 59,  120 => 71,  115 => 44,  111 => 55,  108 => 68,  101 => 18,  98 => 36,  96 => 37,  83 => 33,  74 => 30,  66 => 28,  55 => 26,  52 => 17,  50 => 24,  43 => 23,  41 => 10,  35 => 12,  32 => 4,  29 => 3,  209 => 117,  203 => 148,  199 => 41,  193 => 44,  189 => 103,  187 => 101,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 92,  162 => 31,  154 => 29,  149 => 99,  147 => 25,  144 => 28,  141 => 91,  133 => 95,  130 => 23,  125 => 93,  122 => 39,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 20,  99 => 31,  95 => 28,  92 => 57,  86 => 33,  82 => 32,  80 => 24,  73 => 29,  64 => 20,  60 => 19,  57 => 93,  54 => 25,  51 => 25,  48 => 16,  45 => 10,  42 => 22,  39 => 10,  36 => 10,  33 => 4,  30 => 10,);
    }
}
