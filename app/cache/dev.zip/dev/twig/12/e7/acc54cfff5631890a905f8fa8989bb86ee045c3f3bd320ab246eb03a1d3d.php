<?php

/* MainRatetradeBundle:Default:ncity-rates.html.twig */
class __TwigTemplate_12e7acc54cfff5631890a905f8fa8989bb86ee045c3f3bd320ab246eb03a1d3d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <title>";
        // line 4
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <link rel=\"canonical\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\">  
        <meta name=\"geo.region\" content=\"CA\" />
        <meta name=\"title\" content=\"";
        // line 10
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta name=\"description\" content=\"";
        // line 11
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\"> 
        <meta property=\"og:type\" content=\"article\" />
        <meta name=\"og:title\" content=\"";
        // line 13
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta name=\"og:description\" content=\"";
        // line 14
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta property=\"og:site_name\" content=\"Rate Trade\" />
        <meta property=\"article:publisher\" content=\"https://www.facebook.com/ratetrade/\" />
        <meta name=\"twitter:card\" content=\"summary\" />
        <meta name=\"twitter:description\" content=\"";
        // line 18
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta name=\"twitter:title\" content=\"";
        // line 19
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\">
        <meta name=\"twitter:site\" content=\"@ratetrade\" />
        <meta name=\"twitter:creator\" content=\"@ratetrade\" />
        <meta name=\"keywords\" content=\"";
        // line 22
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "\" />
         <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>

         <script language=\"JavaScript\" 
                src=\"https://www.iplocationtools.com/iplocationtools.js?key=7b71786a7773756d6a207270\">
        </script>
   

    ";
        // line 44
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "

<!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">";
        // line 53
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">";
        // line 57
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "</li>
                </ul>
            </div>
        </section>

<!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
                                           <div class=\"best-rate-box\">
                                        <table align=\"left\" cellspacing=\"0\" cellpadding=\"0\" class=\"table-rates fixed\">
                                            <tbody>
                                                <tr>
                                                    <th scope=\"col\">Rate</th>
                                                    <th scope=\"col\" align=\"center\">Term</th>
                                                    <th scope=\"col\" align=\"center\">Type</th>
                                                    <th scope=\"col\" align=\"center\">&nbsp;</th>
                                                </tr>

                                                ";
        // line 86
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rates"]) ? $context["rates"] : $this->getContext($context, "rates")));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 87
            echo "                                                    <tr>
                                                        <td>
                                                            <span class=\"rt-rate\">
                                                                ";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "<sup>%</sup>
                                                            </span>
                                                        </td>  
                                                        <td class=\"terms\">";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "html", null, true);
            echo "</td>
                                                        <td class=\"type\">";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"), "html", null, true);
            echo "</td>
                                                        <td><span class=\"get_this-rate\">
                                                                <a rt-popup=\"\" href=\"#\" data-toggle=\"modal\" data-target=\"#agentModal1\" class=\"rate-btn ";
            // line 96
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "html", null, true);
            echo "\">
                                                                    <span class=\"wide\">
                                                                        <button class=\"btn btn-success rh-button\">
                                                                            Apply Now
                                                                        </button>
                                                                    </span>
                                                                </a>
                                                            </span>
                                                            <a rt-popup=\"\" href=\"";
            // line 104
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("compare_rates", array("rate" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rate"), "term" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "term"), "type" => $this->getAttribute((isset($context["r"]) ? $context["r"] : $this->getContext($context, "r")), "rateType"))), "html", null, true);
            echo "\">
                                                                Compare
                                                            </a>
                                                        </td>
                                                    </tr>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "                                            </tbody>
                                        </table>
                                    </div>
                                    <br/><br/>
                                    <div>
                                      
                                            <p>A Fixed Rate Mortgage is a mortgage of any fixed term such as (1 year, 3 years, 5 years, and 10 years) in which interest rate is fixed and is not changed during the mortgage term. If you have taken variable rate mortgage, most of the lenders will allow you lock-in your variable rate mortgage into a fixed rate mortgage.</p> 
                                            <strong>Advantages</strong>
<ul>
                                            <li>Your interest rate and mortgage payment will be same throughout the mortgage term.</li>
                                            <li>It gives borrowers security and comfort of knowing that their payment won’t change with any changes in the market or the economy.</li>
                                            <li>It brings stability and consistency as loan payment will remain same throughout the term.</li>
                                            <li>Fixed-rate mortgages are very easy to understand, and comprehend as they vary very little from lender to lender.</li>
</ul>
                                            <strong>Disadvantages</strong>
                                            <ul><li>A fixed rate mortgage also means you don’t have to pay less when interest rate declines. If the interest rates are trending downwards, you will keep on paying higher rate than those who have opted for variable rate mortgage.</li>
                                            <li>Fixed rates are better option for those who are borrowing for long term. However, if one wants to leave home after a few years, one will actually have to pay more than they need to pay for early payment in case of variable rate mortgage.</li>
                                            <li>These rates lacks individual customisations usually offered to variable rate mortgage holders as fixed rate mortgages are usually identical from lender to lender.</li></ul>
                                            <strong>Why Should I Compare Fixed Mortgage Rates in ";
        // line 128
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "?</strong>
                                            <p>With our easy to use platform for comparing fixed rate mortgages in ";
        // line 129
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo ", you will be able to search, compare and choose the fixed mortgage rates with best terms and lowest interest rates in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo ". You will not repent for bearing a loss due to choosing a wrong mortgage with higher interest rates and complex terms and conditions. We do all the legwork to make mortgage payment easy, fast and simple for you.
                                            
                                            <p>A variable-rate mortgage is also known as floating rate mortgage in which rate of interest payable changes periodically based on an index which shows the cost to the lender of borrowing on the credit markets.</p>
                                            <ul><li>Variable-rate mortgages have lower initial interest rates than fixed-rate mortgages and hence borrower has to bear lower monthly mortgage payments.</li>
                                            <li>As the payments for variable rate mortgage are affordable, it is easy to qualify for variable rate mortgage than fixed rate mortgages.</li>
                                            <li>These mortgages are more flexible than their fixed-rate counterparts, so that borrowers can choose for terms that provide lower initial payments ranging anywhere from one month to 10 years.
                                            <li>Variable-rate mortgagesis also ideal option for borrowers who don’t wish to live in a home for more than few years as well as those who don’t  expect to pay off their mortgages rapidly.</ul> 
                                                <strong>Cons</strong><ul>
                                            <li>One of the biggest disadvantages of variable rate mortgage is payment shock. A borrower may have to pay higher monthly mortgage payments if there is sudden rapid increase in the interest rate.</li>
                                            <li>Variable rate mortgages are generally more complex than their fixed-rate mortgages as they are available in a variety of loans. As interest vary from time to time, it is not easy to compare the cost of mortgage being offered by different lenders.</li>
                                            <li>The changing mortgage rate makes it difficult to predict future payments and it eventually makes difficult for borrowers to make monthly budgets.</li></ul>
                                            <strong>Why should I Compare Variable Mortgage Rates in ";
        // line 140
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo "?</strong>
                                            <p>With our easy to use platform for comparing variable rate mortgages in ";
        // line 141
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo ", you will be able to search, compare and choose the fixed mortgage rates with best terms and lowest interest rates in ";
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["target"]) ? $context["target"] : $this->getContext($context, "target"))), "html", null, true);
        echo ". You will not repent for bearing a loss due to choosing a wrong mortgage with higher interest rates and complex terms and conditions. We do all the legwork to make mortgage payment easy, fast and simple for you.</p>
                                       
                                    </div>
                                    
                                    ";
        // line 145
        if ((twig_length_filter($this->env, (isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities"))) > 0)) {
            // line 146
            echo "                                        <strong>Find Mortgage Rates By City</strong>
                                        <br/>
                                        <ul class=\"listfrate\">
                                            ";
            // line 149
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities")));
            foreach ($context['_seq'] as $context["key"] => $context["c"]) {
                // line 150
                echo "                                               <li>
                                                    <a href=\"";
                // line 151
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ncity_ratetypes", array("target" => $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "urlLink"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo " </a>
                                               </li>
                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['c'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 154
            echo "                                        </ul>
<div class=\"clear\"></div>
                                    ";
        }
        // line 157
        echo "                                </div>
                            </div>
                        </div>
                        <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>

<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-percent\"></i> &nbsp; Fixed Mortgage Rates</a>
                                    <ul class=\"children active\">
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 173
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/1-year/fixed\">1 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 174
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/2-year/fixed\">2 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 175
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/3-year/fixed\">3 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 176
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/4-year/fixed\">4 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 177
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/5-year/fixed\">5 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 178
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/6-year/fixed\">6 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 179
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/7-year/fixed\">7 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 180
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/8-year/fixed\">8 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 181
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/9-year/fixed\">9 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 182
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/10-year/fixed\">10 Year Fixed Rate</a></li>
                                                    </li>
                                                
                                          
                                             
                                     </ul>
                                </li>
<li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-percent\"></i> &nbsp; Variable Mortgage Rates</a>
                                    <ul class=\"children active\">
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 193
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/3-year/variable\">3 Year Fixed Rate</a></li>
<li><a href=\"https://www.ratetrade.ca/best-";
        // line 194
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, strtr((isset($context["target"]) ? $context["target"] : $this->getContext($context, "target")), " ", "-")), "html", null, true);
        echo "-mortgage-rates/5-year/variable\">5 Year Fixed Rate</a></li>

</ul></li>



                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-calculator\"></i> &nbsp; Calculators</a>
                                    <ul class=\"children\">
                                                <li><a href=\"";
        // line 204
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">Mortgage Payment</a></li>
                                                <li><a href=\"";
        // line 205
        echo $this->env->getExtension('routing')->getPath("payment_analyzer");
        echo "\">Payment Analyzer</a></li>
                                                <li><a href=\"";
        // line 206
        echo $this->env->getExtension('routing')->getPath("income_cal");
        echo "\">Income Calculator</a></li>
                                                <li><a href=\"";
        // line 207
        echo $this->env->getExtension('routing')->getPath("affordability_cal");
        echo "\">Mortgage Affordability</a></li>
                                                <li><a href=\"";
        // line 208
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\">Mortgage Insurance</a></li>
                                                <li><a href=\"";
        // line 209
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>
                                                <li><a href=\"";
        // line 210
        echo $this->env->getExtension('routing')->getPath("refinance-calculator");
        echo "\">Refinance Calculator</a></li>
                                                <li><a href=\"";
        // line 211
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                                                <li><a href=\"";
        // line 212
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                                                <li><a href=\"";
        // line 213
        echo $this->env->getExtension('routing')->getPath("debt-consolidation-calculator");
        echo "\">Debt Consolidation</a></li>
                                     </ul>
                                </li>
                                <li> 
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
                                    <ul class=\"children\">
                                        
                                                ";
        // line 221
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 222
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 223
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 225
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 226
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                                    <ul class=\"children\">
                                       ";
        // line 233
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 234
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 235
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 237
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 238
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    <ul class=\"children\">
                                      ";
        // line 244
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 245
            echo "                                                        ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 246
                echo "                                                            <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                echo "</a></li>
                                                            ";
            }
            // line 248
            echo "                                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 249
        echo "                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
              
                                 </aside>
                    <!-- /SIDEBAR -->
                </div>
            </div>
        </section>
        ";
        // line 262
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
        <div class=\"modal fade\" id=\"agentModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">
            <div class=\"modal-dialog modal-lg\" role=\"document\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        <h4 class=\"modal-title\" id=\"myModalLabel\">Contact For Rate <span id=\"rate-r\"></span> %</h4>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"row\">
                            <div class=\"col-xs-12 col-sm-12\">
                                <div class=\"form-class\">
                                    <form class=\"\">
                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"name\"><i class=\"fa fa-user\"></i> &nbsp;Name: *</label>
                                                <input type=\"text\" class=\"form-control required\" name=\"urName\" id=\"urName\" placeholder=\"Enter Name\">
                                            </div>
                                            <div class=\"form-group\">

                                                <label for=\"phoneNumber\"><i class=\"fa fa-mobile\"></i> &nbsp; Phone Number: *</label>
                                                <input type=\"text\"  class=\"form-control required\" name=\"phoneNumber\" id=\"phonenUmber\" placeholder=\"Enter Phone Number\">
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"besttime\"><i class=\"fa fa-clock-o\"></i> &nbsp;Best Time to Call: *</label>
                                                <select name=\"bestTime\" id=\"bestTime\"  class=\"form-control required\">
                                                    <option value=\"anytime\">Any Time</option>
                                                    <option value=\"morning\">Morning</option>
                                                    <option value=\"afternoon\">Afternoon</option>
                                                    <option value=\"evening\">Evening</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"forEmail\"><i class=\"fa fa-envelope\"></i> &nbsp;Email Address: *</label>
                                                <input type=\"text\"  class=\"form-control\" name=\"emailId\" id=\"EmailId\" placeholder=\"Enter Email Address\">
                                            </div>                                
                                        </div>

                                        <div class=\"col-xs-12 col-sm-6\">
                                            <div class=\"form-group\">
                                                <label for=\"agentLocation\"><i class=\"fa fa-map-marker\"></i> &nbsp;Location: *</label>
                                                <input type=\"text\" name=\"agentLocationName\" id=\"agentLocationName\" class=\"form-control\" value=\"\" placeholder=\"Seach City\">
                                                <select name=\"agentLocation\" id=\"agentLocation\" class=\"form-control required\" onClick=\"getPop()\" size=\"5\" style=\"display:none;\">
                                                    ";
        // line 305
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cities"]) ? $context["cities"] : $this->getContext($context, "cities")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 306
            echo "                                                        ";
            if (($this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl") == "brampton")) {
                echo "  
                                                            <option value=\"";
                // line 307
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\" selected>";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>
                                                        ";
            } else {
                // line 309
                echo "                                                            <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "</option>   
                                                        ";
            }
            // line 311
            echo "                                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 312
        echo "                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <label for=\"lookingfor\"><i class=\"fa fa-home\"></i> &nbsp;I am Looking For: *</label>
                                                <select name=\"lookingFor\" id=\"lookingFor\"  class=\"form-control required\">
                                                    <option value=\"\">Please Select</option>
                                                    <option value=\"buying\">Buying</option>
                                                    <option value=\"renew-mortgage\">Renew Mortgage</option>
                                                    <option value=\"debt-consolidation\">Debt Consolidation</option>
                                                    <option value=\"refinancing\">Refinancing</option>
                                                </select>
                                            </div>
                                            <div class=\"form-group\">
                                                <br>
                                                <input type=\"hidden\" id=\"rate-request\" value=\"\"/>
                                                <button type=\"button\" class=\"btn btn-primary lead-submit\" >Submit Now</button>
                                            </div>                                
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"modal-footer\">

                    </div>
                </div>
            </div>
        </div>
      
        <script>
                                                    \$(document).on(\"click\", \".rate-btn\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#rate-request\").val(\$(this).attr(\"class\").split(\" \")[1]);
                                                        \$(\"#rate-r\").html(\$(this).attr(\"class\").split(\" \")[1]);
                                                    });
                                                    
                                                     \$(document).ready(function () {
                                                        if(ip2location_country_long() === 'Canada')
                                                        {
                                                        \$(\"#agentLocationName\").val(ip2location_city());
                                                        \$(\"#agentLocation\").find(\"option:contains('\" + ip2location_city() + \"')\").prop(\"selected\", true);
                                                        }
                                                        else
                                                        {
                                                        \$(\"#agentLocationName\").val(\"Brampton\");
                                                        \$(\"#agentLocation\").find(\"option:contains('Brampton')\").prop(\"selected\", true);
                                                        }
                                                    });

                                                    \$('.locations').on('click', function() {

                                                        \$('.location-name-box').toggle(500);
                                                    });
                                                    \$('.level1Btn').on('click', function() {
                                                        \$('.level1 ul').toggle(500);

                                                    });
                                                    \$('.level2Btn').on('click', function() {
                                                        \$('.level2 ul').toggle(500);

                                                    });
                                                    \$('.level3Btn').on('click', function() {
                                                        \$('.level3 ul').toggle(500);

                                                    });

                                                    \$('#agentLocationName').click(function(e) {
                                                        \$('#agentLocation').show(100);
                                                    });
                                                    \$('#agentLocation').blur(function(e) {
                                                        \$(this).hide(100);
                                                    });

                                                    function capitalizeFirstLetter(string) {
                                                        return string.charAt(0).toUpperCase() + string.slice(1);
                                                    }

                                                    \$('#agentLocationName').on('input', function() {
                                                        // Getiing option based on input value and setting it as selected
                                                        \$('#agentLocation option:contains(' + capitalizeFirstLetter(this.value) + ')').eq(0).prop('selected', true);
                                                    });

                                                    function getPop() {

                                                        //document.getElementById('locationName').value = document.getElementById('locationList').text;
                                                        \$('#agentLocationName').val(\$('option:selected', \$('#agentLocation')).text());
                                                        \$('#agentLocation').hide(100);
                                                    }



                                                    function validateEmail(email) {
                                                        var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                                                        return re.test(email);
                                                    }

                                                    \$(document).on(\"click\", \".subsc\", function(e) {
                                                        e.preventDefault();
                                                        \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                                                        if (\$(\"#exampleInputEmail2\") == '')
                                                        {
                                                            \$(\"#exampleInputEmail2\").focus();
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                                                        {
                                                            \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                                                            \$(\"#exampleInputEmail2\").focus();
                                                        }
                                                        else {
                                                            \$.ajax({
                                                                url: '";
        // line 426
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                                                                type: \"post\",
                                                                async: true,
                                                                data: {'email': \$(\"#exampleInputEmail2\").val(),
                                                                    'name': \"testname\"},
                                                                success: function(response) {
                                                                    \$(\"#exampleInputEmail2\").val('');
                                                                    alert(response);
                                                                },
                                                                error: function(request, error) {
                                                                    // alert('No data found');
                                                                }
                                                            });
                                                        }
                                                    });


                                                    \$(document).on(\"change\", \".required\", function() {
                                                        \$(this).css('border', '1px solid green');

                                                        if (\$(this).val() == '')
                                                        {
                                                            \$(this).focus();
                                                            \$(this).css('border', '1px solid red');
                                                        }

                                                        var id = \$(this).attr('id');
                                                        if (id == 'EmailId' && !validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                    });

                                                    \$(document).on(\"click\", \".lead-submit\", function(e) {

                                                        if (\$(\"#urName\").val() == '')
                                                        {
                                                            \$(\"#urName\").focus();
                                                            \$(\"#urName\").css('border', '1px solid red');
                                                        }
                                                        else if (\$(\"#EmailId\").val() == '')
                                                        {
                                                            \$(\"#EmailId\").focus();
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                        }
                                                        else if (!validateEmail(\$(\"#EmailId\").val()))
                                                        {
                                                            \$(\"#EmailId\").css('border', '1px solid red');
                                                            \$(\"#EmailId\").focus();
                                                        }
                                                        else if (\$(\"#phonenUmber\").val() == '')
                                                        {
                                                            \$(\"#phonenUmber\").focus();
                                                            \$(\"#phonenUmber\").css('border', '1px solid red');
                                                        }
                                                        else {
                                                            var currentRequest = null;
                                                            \$(\".lead-submit\").text(\"Please Wait..\");
                                                            var formData = {
                                                                fname: \$(\"#urName\").val(),
                                                                email: \$(\"#EmailId\").val(),
                                                                phone: \$(\"#phonenUmber\").val(),
                                                                message: \$(\"#rate-request\").val(),
                                                                location: \$(\"#agentLocationName\").val(),
                                                                besttime: \$(\"#bestTime\").find(\"option:selected\").text(),
                                                                purpose: \$(\"#lookingFor\").find(\"option:selected\").text()
                                                            };
                                                            currentRequest = \$.ajax({
                                                                type: \"post\",
                                                                async: true,
                                                                url: \"";
        // line 497
        echo $this->env->getExtension('routing')->getPath("lead_update");
        echo "\",
                                                                data: formData,
                                                                beforeSend: function() {
                                                                    if (currentRequest != null) {
                                                                        currentRequest.abort();
                                                                    }
                                                                },
                                                                success: function(response) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    \$(\"#agentModal1\").modal('hide');
                                                                    alert(\"Query Successful\");
                                                                    window.location.href = '/thank-you';
                                                                },
                                                                error: function(request, error) {
                                                                    \$(\".lead-submit\").text(\"Submit\");
                                                                    \$(\".required\").removeAttr('style');
                                                                    alert(\"Query Failed\");
                                                                }
                                                            });
                                                        }
                                                    });
        </script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:ncity-rates.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  807 => 497,  617 => 312,  611 => 311,  596 => 307,  591 => 306,  491 => 237,  431 => 212,  415 => 208,  291 => 149,  284 => 145,  736 => 454,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 305,  582 => 328,  578 => 327,  317 => 189,  565 => 320,  468 => 256,  281 => 177,  465 => 216,  361 => 157,  332 => 173,  328 => 147,  320 => 143,  276 => 166,  272 => 126,  245 => 113,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 231,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 281,  492 => 252,  484 => 201,  410 => 173,  397 => 165,  388 => 221,  380 => 219,  366 => 224,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 249,  442 => 237,  417 => 178,  372 => 159,  336 => 174,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 249,  509 => 245,  482 => 240,  386 => 194,  357 => 212,  353 => 180,  344 => 176,  339 => 151,  335 => 175,  329 => 192,  321 => 190,  610 => 410,  462 => 192,  394 => 222,  370 => 226,  364 => 181,  349 => 212,  340 => 175,  325 => 191,  319 => 194,  304 => 185,  295 => 150,  289 => 176,  280 => 167,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 297,  531 => 226,  516 => 319,  476 => 233,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 188,  303 => 123,  292 => 127,  288 => 114,  510 => 280,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 209,  411 => 207,  389 => 184,  378 => 181,  311 => 137,  708 => 448,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 246,  483 => 235,  452 => 241,  448 => 240,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 41,  277 => 176,  521 => 214,  513 => 271,  508 => 216,  499 => 248,  495 => 247,  489 => 261,  472 => 257,  396 => 234,  392 => 171,  377 => 218,  356 => 179,  352 => 178,  348 => 177,  192 => 112,  883 => 685,  699 => 504,  449 => 250,  432 => 222,  428 => 180,  414 => 177,  406 => 227,  403 => 205,  399 => 204,  390 => 216,  376 => 164,  373 => 217,  369 => 215,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 262,  535 => 296,  527 => 313,  524 => 298,  520 => 248,  505 => 244,  497 => 238,  494 => 231,  479 => 239,  475 => 248,  467 => 226,  458 => 253,  454 => 208,  450 => 222,  446 => 221,  184 => 86,  180 => 106,  172 => 104,  160 => 101,  152 => 57,  937 => 621,  809 => 524,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 334,  603 => 309,  599 => 351,  553 => 323,  536 => 218,  530 => 294,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 251,  477 => 270,  471 => 247,  463 => 242,  460 => 191,  456 => 228,  445 => 249,  441 => 268,  433 => 203,  429 => 234,  424 => 254,  420 => 228,  416 => 252,  412 => 229,  385 => 230,  382 => 193,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 284,  529 => 295,  525 => 215,  517 => 272,  511 => 304,  503 => 206,  500 => 205,  496 => 243,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 242,  451 => 224,  447 => 185,  443 => 237,  439 => 260,  434 => 245,  426 => 233,  422 => 232,  400 => 235,  395 => 172,  114 => 37,  260 => 189,  256 => 103,  248 => 114,  266 => 193,  262 => 121,  250 => 189,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 111,  275 => 141,  271 => 140,  267 => 137,  263 => 191,  259 => 158,  255 => 129,  239 => 185,  81 => 22,  65 => 18,  1085 => 1059,  210 => 121,  198 => 103,  194 => 133,  190 => 104,  186 => 103,  178 => 35,  150 => 41,  146 => 79,  134 => 24,  124 => 72,  104 => 67,  391 => 231,  383 => 214,  375 => 313,  371 => 159,  367 => 158,  363 => 214,  359 => 156,  351 => 220,  347 => 219,  188 => 87,  301 => 185,  293 => 151,  113 => 90,  174 => 34,  170 => 78,  148 => 29,  77 => 21,  231 => 110,  165 => 106,  161 => 105,  153 => 92,  195 => 106,  191 => 95,  34 => 8,  155 => 93,  310 => 197,  306 => 196,  302 => 195,  290 => 126,  286 => 146,  282 => 143,  274 => 153,  270 => 194,  251 => 128,  237 => 111,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 98,  167 => 96,  137 => 84,  129 => 94,  23 => 3,  223 => 119,  215 => 151,  211 => 124,  207 => 58,  202 => 118,  197 => 114,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 211,  350 => 210,  346 => 220,  342 => 152,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 199,  206 => 99,  244 => 174,  236 => 133,  232 => 85,  228 => 84,  216 => 115,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 49,  53 => 15,  127 => 33,  97 => 62,  76 => 19,  58 => 26,  480 => 234,  474 => 198,  469 => 284,  461 => 225,  457 => 241,  453 => 223,  444 => 184,  440 => 246,  437 => 236,  435 => 213,  430 => 257,  427 => 211,  423 => 210,  413 => 226,  409 => 238,  407 => 206,  402 => 130,  398 => 173,  393 => 197,  387 => 215,  384 => 168,  381 => 182,  379 => 230,  374 => 227,  368 => 182,  365 => 189,  362 => 156,  360 => 180,  355 => 215,  341 => 105,  337 => 103,  322 => 200,  314 => 157,  312 => 136,  309 => 154,  305 => 186,  298 => 151,  294 => 133,  285 => 89,  283 => 130,  278 => 195,  268 => 124,  264 => 122,  258 => 97,  252 => 187,  247 => 149,  241 => 159,  229 => 109,  220 => 81,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 33,  61 => 17,  273 => 140,  269 => 94,  254 => 115,  243 => 148,  240 => 173,  238 => 186,  235 => 184,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 104,  217 => 125,  208 => 96,  204 => 109,  179 => 99,  159 => 94,  143 => 37,  135 => 35,  119 => 36,  102 => 34,  71 => 24,  67 => 29,  63 => 22,  59 => 27,  201 => 77,  196 => 113,  183 => 100,  171 => 97,  166 => 77,  163 => 95,  158 => 30,  156 => 100,  151 => 92,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 61,  91 => 29,  62 => 27,  49 => 14,  87 => 28,  28 => 8,  94 => 35,  89 => 27,  85 => 14,  75 => 25,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 50,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 26,  72 => 13,  69 => 19,  47 => 24,  40 => 11,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 53,  139 => 65,  131 => 34,  123 => 37,  120 => 71,  115 => 35,  111 => 34,  108 => 40,  101 => 60,  98 => 36,  96 => 37,  83 => 27,  74 => 30,  66 => 22,  55 => 26,  52 => 12,  50 => 24,  43 => 23,  41 => 12,  35 => 8,  32 => 12,  29 => 9,  209 => 117,  203 => 94,  199 => 93,  193 => 90,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 102,  162 => 50,  154 => 71,  149 => 69,  147 => 25,  144 => 67,  141 => 85,  133 => 44,  130 => 23,  125 => 93,  122 => 72,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 32,  99 => 31,  95 => 30,  92 => 57,  86 => 33,  82 => 32,  80 => 20,  73 => 20,  64 => 32,  60 => 19,  57 => 16,  54 => 25,  51 => 25,  48 => 11,  45 => 13,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
