<?php

/* MainRatetradeBundle:Default:mortgage-renewals-city.html.twig */
class __TwigTemplate_6972e8c72d9252c4fb12338007ce95639d730e42f54e0506ecda27abbde2964e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"widht=content-width, initial-scale=1\">
        <meta name=\"robots\" content=\"index, follow\">
        <meta name=\"geo.region\" content=\"CA\" />
        <title>Mortgage Renewal Process in ";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</title>
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">
    <link rel=\"apple-touch-icon-precomposed\" sizes=\"144x144\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.png"), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/ico/favicon.ico"), "html", null, true);
        echo "\">
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/bootstrap-select/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/fontawesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/prettyphoto/css/prettyPhoto.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.carousel.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/owl-carousel2/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/animate/animate.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/swiper/css/swiper.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/css/theme-red-1.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" id=\"theme-config-link\">
    <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/assets/plugins/modernizr.custom.js"), "html", null, true);
        echo "\"></script>
    <link rel=\"alternate\" hrefLang=\"x-default\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request"), "uri"), "html", null, true);
        echo "\"/>
        <script src=\"https://code.jquery.com/jquery-1.12.1.min.js\" type=\"text/javascript\"></script>
    

          ";
        // line 27
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Header"));
        echo "
    <!-- /HEADER -->
  <!-- CONTENT AREA -->
    <div class=\"content-area\">

        <!-- BREADCRUMBS -->
        <section class=\"page-section breadcrumbs text-right\">
            <div class=\"container\">
                <div class=\"page-header\">
                             <h1 class=\"entrytitle\">Mortgage Renewal Process in ";
        // line 36
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</h1>
</div>
                <ul class=\"breadcrumb\"> 
                                <li>Home</li>
                                <li class=\"active\">Mortgage Renewal Process in ";
        // line 40
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</li>
                </ul>
            </div>
        </section>
<!-- /BREADCRUMBS -->


          <!-- PAGE WITH SIDEBAR -->
        <section class=\"page-section with-sidebar\">
            <div class=\"container\">
                <div class=\"row\">
                    
                    <!-- CONTENT -->
                    <div class=\"col-md-9 content\" id=\"content\">

                        <!-- Blog posts -->
                        <article class=\"post-wrap\">
                            <div class=\"post-media\">


                            <div class=\"content-boxes\">
                                <p><strong>Key Steps in Mortgage Renewal Process for ";
        // line 61
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>As your mortgage term comes to end and there is still an outstanding balance of your mortgage, you will need to renew mortgage for another term. Switching mortgage providers is a bit more long procedure than moving on with the same lender but it will give you access to better mortgage rates and may be terms and conditions as well. Here are the key steps in mortgage renewal process:</p>
                                <p><strong>Get going early</strong></p>
                                <p>Most lenders will allow you to renew your mortgage four months before the date of maturity without having to pay a prepayment penalty (for breaking your term early). You must start researching online to compare what other lenders are offering in terms of mortgage rates, prepayment options and other terms and conditions.</p>
                                <p><strong>Analyze your financial goals</strong></p>
                                <p>Your financial goals at the beginning of your current mortgage term would probably have changed to a certain extent. For instance, if current mortgage term is a 5-year fixed, then your renewal slip may likely to be for another five years fixed. If you think, you will be staying in your home for long (at least more than five years), than it might be good to renew the term with current lender (consider the rates offered by other lenders). If there are chance you’ll downsize, or you may move to another city in next few years, you may be more interested in mortgage with two to three year term. You also need to consider other alternatives such as whether it is wise to refinance your mortgage or get a HELOC to access equity.</p>
                                <p><strong>Be prepared to renew mortgage </strong></p>
                                <p>As per law, your current lender has to send you a mortgage renewal statement at least 21 days before your term is over. Most lenders prefer to send renewal state only two or three weeks before the date of maturity, so you should not have much time to shop around for mortgage. They usually mail you a renewal offer for their lowest rate that is good for the 30 days before maturity. If you will accept the offer, you will safeguard yourself from any rate increase during that period. However, you should have done enough research by now to know whether or not it’s actually the best mortgage rate on the market. If it is not, which is usual case, you should try to negotiate with your current lenders. You should ideally make an appointment with a mortgage broker, to discuss what other lenders can offer you. As per the survey by the Bank of Canada it has been found that brokers usually helps in getting a lower rates than banks as they are able to get multiple quotes from various institutions.</p>
                                <p><strong>Choosing the lenders in ";
        // line 69
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>One you shop around, it is time to consider your financial goals, mortgage needs and the mortgage renewal offer from current lender to make a decision. In order to make a better decision you should consider the following facts:</p>
                                <ul>
                                    <li>Are interest rates expected to rise or fall in the future?</li>
                                    <li>Are you happy with the terms and conditions laid down by the current mortgage holder?</li>
                                    <li>What are the costs and fees associated with switching mortgage lenders?</li>
                                </ul>
                                <p><strong>Moving on with current lender in ";
        // line 76
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>You need to consider all above things for making a decision. If you wish to go with current lender, you can either choose to sign the mortgage renewal offer and return the mortgage renewal offer they sent in the mail, or you can try to negotiate a better offer with your current lender.</p>
                                <p><strong>Switching the lender in ";
        // line 78
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <p>If you think it is more profitable to switch the lenders, you should be prepared to submit a slew of documents while switching mortgage providers as the conditions of new lender might be different from your current lender.</p>
                                <p>There are usually different kinds of fees involved in switching lenders for renewing mortgages such as</p>
                                <ul>
                                    <li>Appraisal fee</li>
                                    <li>Discharge fee</li>
                                    <li>An assignment fee</li>
                                    <li>Legal fees</li>
                                </ul>
                                <p>You should be prepared to bear above mentioned fee, while switching the lenders for renewal of mortgage, however, some mortgage brokers and lenders may pay some of the fees when you bring your mortgage to them.</p>
                                <p><strong>Tips for Mortgage Renewal in ";
        // line 88
        echo twig_escape_filter($this->env, (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city")), "html", null, true);
        echo "</strong></p>
                                <ul>
                                    <li>You must shop for mortgage as early as possible to find and grab the best mortgage offers. Most of the time, current lenders allow borrower to renew mortgage 120 days before the terms come to end without penalty.</li>
                                    <li>You can always ask your current lender for a better rate. Banks usually offer 0.25% off on mortgage renewal offer to their existing clients.</li>
                                    <li>It is advisable to schedule an appointment with your lender to negotiate a better mortgage rate. However, new lenders will usually offer better rates than current lenders.</li>
                                    <li>It is convenient to stay with your current lender, but it is costly as well. Mortgage renewal with same lender may come with a higher interest rate, and terms and conditions that may no longer suit your needs.</li>
                                    <li>If you have found a reasonable mortgage rate to go with, then you should ask the lender for a rate hold. Most lenders allow you to rate hold for 90-120 days. It means they will commit you to offer the same rate even if the rate goes up as long as you come back within stipulated period.</li>
                                    <li>If you are planning to switch providers during your mortgage renewal process, it is essential to know that it will take time as the criteria of your new lender might be completely different from the current lender. You will be required to submit application along with a slew of other documents. As all the formalities may take more than a week, it is advisable to start the process at the earliest</li>
                                    <li>Most of the time, you will have to bear a couple of fees associated with switching the lenders during mortgage renewal process. You must also ask your lender to cover costs associated with new mortgage before agreeing to pay it all by yourself.</li>
                                    <li>If you are planning to refinance mortgage, renewal is the best time to do so. Generally, you have to pay mortgage penalty for refinancing before the end of the renewal term. If you will refinance during their mortgage renewal, you won’t be breaking your mortgage term and therefore, you won’t need to pay a prepayment penalty.</li>
                                </ul>
                            
                       
                        ";
        // line 101
        if ((twig_length_filter($this->env, (isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities"))) > 0)) {
            echo "<div class=\"reproc\">
                            <h3>Mortgage Renewal Process in your City</h3>
                           
                                
                                    ";
            // line 105
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["target_cities"]) ? $context["target_cities"] : $this->getContext($context, "target_cities")));
            foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
                // line 106
                echo "                                        <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_renewals", array("city" => $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cityUrl"))), "html", null, true);
                echo "\">
                                            ";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "city"), "html", null, true);
                echo "
                                        </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 110
            echo "                                
                            </div></div>
                        ";
        }
        // line 113
        echo "                    </div> </div>
                   <!-- SIDEBAR -->
                    <aside class=\"col-md-3 sidebar\" id=\"sidebar\">
                    
                    <!-- widget car categories -->
                    <div class=\"widget shadow car-categories\">
                        <h4 class=\"widget-title\">Mortgage Categories</h4>
                        <div class=\"widget-content\">
                            <ul>
                               
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Home Buying Process</a>
  ";
        // line 126
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "6")) {
            // line 127
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 129
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 131
        echo "                                    
                                        
                                                         
                                                            ";
        // line 134
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 135
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "6")) {
                // line 136
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 137
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 139
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 141
                echo "                                                                    ";
            }
            // line 142
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 143
        echo "                                                       
                                </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Renewing Mortgage</a>
                             ";
        // line 149
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "18")) {
            // line 150
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 152
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 154
        echo "                                    
                                        
                                        ";
        // line 156
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 157
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "18")) {
                // line 158
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 159
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 161
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 163
                echo "                                                                    ";
            }
            // line 164
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 165
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Refinancing Guide</a>
                                    ";
        // line 170
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "1")) {
            // line 171
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 173
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 175
        echo "                                    
                                        
                                       ";
        // line 177
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 178
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "1")) {
                // line 179
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 180
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 182
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 184
                echo "                                                                    ";
            }
            // line 185
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 186
        echo "                                    </ul>
                                </li>
                                <li>
                                    <span class=\"arrow\"><i class=\"fa fa-angle-down\"></i></span>
                                    <a href=\"#\"><i class=\"fa fa-book\"></i> &nbsp; Mortgage Information</a>
                             ";
        // line 191
        if (($this->getAttribute((isset($context["parentcat"]) ? $context["parentcat"] : $this->getContext($context, "parentcat")), "id") == "47")) {
            // line 192
            echo "                                                        <ul class=\"children active\">
                                                        ";
        } else {
            // line 194
            echo "                                                           <ul class=\"children\"> 
                                                            ";
        }
        // line 196
        echo "                                    
                                        
                                       ";
        // line 198
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["educationall"]) ? $context["educationall"] : $this->getContext($context, "educationall")));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 199
            echo "                                                                ";
            if (($this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "parentCategory") == "47")) {
                // line 200
                echo "                                                                    ";
                if (($this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "id") == $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "id"))) {
                    // line 201
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\" class=\"edu-cat\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                } else {
                    // line 203
                    echo "                                                                        <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "pageUrl"))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["a"]) ? $context["a"] : $this->getContext($context, "a")), "category"), "html", null, true);
                    echo "</a></li>
                                                                        ";
                }
                // line 205
                echo "                                                                    ";
            }
            // line 206
            echo "                                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 207
        echo "                                    </ul>
                                </li>


                            </ul>
                        </div>
                    </div>
                    <!-- /widget car categories -->
                                                     </aside>
                    <!-- /SIDEBAR -->
</div></div></section>
                     <!-- FOOTER -->
      ";
        // line 219
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("MainRatetradeBundle:Default:Footer"));
        echo "
<!-- /WRAPPER -->

        <script>

            function validateEmail(email) {
                var re = /^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+\$/;
                return re.test(email);
            }

            \$(document).on(\"click\", \".subsc\", function(e) {
                e.preventDefault();
                \$(\"#exampleInputEmail2\").css('border', '1px solid green');

                if (\$(\"#exampleInputEmail2\") == '')
                {
                    \$(\"#exampleInputEmail2\").focus();
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                }
                else if (!validateEmail(\$(\"#exampleInputEmail2\").val()))
                {
                    \$(\"#exampleInputEmail2\").css('border', '1px solid red');
                    \$(\"#exampleInputEmail2\").focus();
                }
                else {
                    \$.ajax({
                        url: '";
        // line 245
        echo $this->env->getExtension('routing')->getPath("email_subscribe");
        echo "',
                        type: \"post\",
                        async: true,
                        data: {'email': \$(\"#exampleInputEmail2\").val(),
                            'name': \"testname\"},
                        success: function(response) {
                            \$(\"#exampleInputEmail2\").val('');
                            alert(response);
                        },
                        error: function(request, error) {
                            // alert('No data found');
                        }
                    });
                }
            });

            \$('.locations').on('click', function() {

                \$('.location-name-box').toggle(500);
            });
            \$('.level1Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level1 ul').toggle(500);
            });
            \$('.level2Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level2 ul').toggle(500);
            });
            \$('.level3Btn').on('click', function(e) {
                e.preventDefault();
                \$('.level3 ul').toggle(500);
            });
        </script>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:mortgage-renewals-city.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  405 => 191,  333 => 163,  307 => 156,  299 => 152,  257 => 136,  807 => 497,  617 => 312,  611 => 311,  596 => 307,  591 => 306,  491 => 237,  431 => 212,  415 => 196,  291 => 149,  284 => 145,  736 => 454,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 305,  582 => 328,  578 => 327,  317 => 159,  565 => 320,  468 => 219,  281 => 177,  465 => 216,  361 => 157,  332 => 173,  328 => 147,  320 => 143,  276 => 141,  272 => 126,  245 => 131,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 231,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 281,  492 => 252,  484 => 201,  410 => 173,  397 => 165,  388 => 221,  380 => 219,  366 => 224,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 249,  442 => 237,  417 => 178,  372 => 159,  336 => 164,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 249,  509 => 245,  482 => 240,  386 => 194,  357 => 212,  353 => 180,  344 => 176,  339 => 151,  335 => 175,  329 => 192,  321 => 190,  610 => 410,  462 => 192,  394 => 222,  370 => 179,  364 => 181,  349 => 170,  340 => 175,  325 => 161,  319 => 194,  304 => 185,  295 => 150,  289 => 176,  280 => 167,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 297,  531 => 226,  516 => 319,  476 => 233,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 188,  303 => 154,  292 => 127,  288 => 114,  510 => 280,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 198,  411 => 194,  389 => 184,  378 => 181,  311 => 157,  708 => 448,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 246,  483 => 235,  452 => 241,  448 => 206,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 41,  277 => 176,  521 => 214,  513 => 271,  508 => 216,  499 => 248,  495 => 247,  489 => 261,  472 => 257,  396 => 234,  392 => 185,  377 => 218,  356 => 179,  352 => 178,  348 => 177,  192 => 112,  883 => 685,  699 => 504,  449 => 250,  432 => 222,  428 => 180,  414 => 177,  406 => 227,  403 => 205,  399 => 204,  390 => 216,  376 => 164,  373 => 180,  369 => 215,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 262,  535 => 296,  527 => 313,  524 => 298,  520 => 248,  505 => 244,  497 => 245,  494 => 231,  479 => 239,  475 => 248,  467 => 226,  458 => 253,  454 => 207,  450 => 222,  446 => 221,  184 => 86,  180 => 106,  172 => 104,  160 => 101,  152 => 57,  937 => 621,  809 => 524,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 334,  603 => 309,  599 => 351,  553 => 323,  536 => 218,  530 => 294,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 251,  477 => 270,  471 => 247,  463 => 242,  460 => 191,  456 => 228,  445 => 205,  441 => 268,  433 => 203,  429 => 201,  424 => 254,  420 => 228,  416 => 252,  412 => 229,  385 => 230,  382 => 193,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 284,  529 => 295,  525 => 215,  517 => 272,  511 => 304,  503 => 206,  500 => 205,  496 => 243,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 242,  451 => 224,  447 => 185,  443 => 237,  439 => 260,  434 => 245,  426 => 200,  422 => 232,  400 => 235,  395 => 172,  114 => 37,  260 => 137,  256 => 103,  248 => 114,  266 => 193,  262 => 121,  250 => 134,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 142,  275 => 141,  271 => 140,  267 => 137,  263 => 191,  259 => 158,  255 => 129,  239 => 185,  81 => 22,  65 => 18,  1085 => 1059,  210 => 121,  198 => 103,  194 => 133,  190 => 101,  186 => 103,  178 => 35,  150 => 41,  146 => 69,  134 => 24,  124 => 72,  104 => 36,  391 => 231,  383 => 214,  375 => 313,  371 => 159,  367 => 178,  363 => 177,  359 => 175,  351 => 171,  347 => 219,  188 => 87,  301 => 185,  293 => 149,  113 => 90,  174 => 88,  170 => 78,  148 => 29,  77 => 21,  231 => 110,  165 => 106,  161 => 78,  153 => 92,  195 => 106,  191 => 95,  34 => 8,  155 => 93,  310 => 197,  306 => 196,  302 => 195,  290 => 126,  286 => 146,  282 => 143,  274 => 153,  270 => 194,  251 => 128,  237 => 127,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 98,  167 => 96,  137 => 84,  129 => 94,  23 => 3,  223 => 119,  215 => 110,  211 => 124,  207 => 58,  202 => 118,  197 => 105,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 211,  350 => 210,  346 => 220,  342 => 165,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 199,  206 => 107,  244 => 174,  236 => 133,  232 => 85,  228 => 84,  216 => 115,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 49,  53 => 15,  127 => 33,  97 => 62,  76 => 19,  58 => 26,  480 => 234,  474 => 198,  469 => 284,  461 => 225,  457 => 241,  453 => 223,  444 => 184,  440 => 246,  437 => 203,  435 => 213,  430 => 257,  427 => 211,  423 => 199,  413 => 226,  409 => 238,  407 => 192,  402 => 130,  398 => 186,  393 => 197,  387 => 215,  384 => 168,  381 => 182,  379 => 230,  374 => 227,  368 => 182,  365 => 189,  362 => 156,  360 => 180,  355 => 173,  341 => 105,  337 => 103,  322 => 200,  314 => 158,  312 => 136,  309 => 154,  305 => 186,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 195,  268 => 139,  264 => 122,  258 => 97,  252 => 187,  247 => 149,  241 => 129,  229 => 109,  220 => 113,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 33,  61 => 17,  273 => 140,  269 => 94,  254 => 135,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 104,  217 => 125,  208 => 96,  204 => 109,  179 => 99,  159 => 94,  143 => 37,  135 => 61,  119 => 36,  102 => 34,  71 => 24,  67 => 29,  63 => 22,  59 => 27,  201 => 106,  196 => 113,  183 => 100,  171 => 97,  166 => 77,  163 => 95,  158 => 30,  156 => 76,  151 => 92,  142 => 26,  138 => 25,  136 => 26,  121 => 92,  117 => 91,  105 => 61,  91 => 29,  62 => 27,  49 => 14,  87 => 28,  28 => 8,  94 => 35,  89 => 27,  85 => 23,  75 => 25,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 50,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 26,  72 => 13,  69 => 19,  47 => 24,  40 => 11,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 53,  139 => 65,  131 => 34,  123 => 37,  120 => 71,  115 => 35,  111 => 40,  108 => 40,  101 => 60,  98 => 36,  96 => 37,  83 => 27,  74 => 30,  66 => 22,  55 => 26,  52 => 12,  50 => 24,  43 => 23,  41 => 12,  35 => 8,  32 => 12,  29 => 9,  209 => 117,  203 => 94,  199 => 93,  193 => 90,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 102,  162 => 50,  154 => 71,  149 => 69,  147 => 25,  144 => 67,  141 => 85,  133 => 44,  130 => 23,  125 => 93,  122 => 72,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 32,  99 => 31,  95 => 30,  92 => 27,  86 => 33,  82 => 32,  80 => 20,  73 => 20,  64 => 32,  60 => 19,  57 => 16,  54 => 25,  51 => 25,  48 => 11,  45 => 13,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
