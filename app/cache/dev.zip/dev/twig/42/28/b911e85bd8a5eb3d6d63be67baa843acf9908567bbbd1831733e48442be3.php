<?php

/* AcmeDemoBundle:Demo:home.html.twig */
class __TwigTemplate_4228b911e85bd8a5eb3d6d63be67baa843acf9908567bbbd1831733e48442be3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <title>RateTrade.ca | Get Best Mortgage Rates </title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
        <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/bootstrap.min.css"), "html", null, true);
        echo "\"/>
        <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/style_bag.css"), "html", null, true);
        echo "\"/>
        <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/custom.css"), "html", null, true);
        echo "\"/>
        <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/jquery.bxslider.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <div>
        ";
        // line 11
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AcmeDemoBundle:Mortgage:header"));
        echo "
        <div class=\"container rateTradelogo\">
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <form role=\"form\" class=\"maxsavingForm\">
                        <div class=\"col-md-1\">

                        </div>

                        <div class=\"col-md-2\">
                            <div>
                                <label for=\"ex1\">I am</label>
                                <select class=\"form-control form-control-lg\" id=\"ex1\">
                                    <option value=\"Buying\">Buying a home</option>
                                    <option value=\"Renewing\">Renewing</option>
                                    <option value=\"Refinancing\">Refinancing</option>
                                </select>
                            </div>\t\t\t\t
                        </div>


                        <div class=\"col-md-2\">
                            <div>
                                <label for=\"ex3\">Location</label>
                                <select class=\"form-control form-control-lg\">
                                    <option value=\"Buying\">Vancouver, Bc</option>
                                    <option value=\"Renewing\">Brampton</option>
                                    <option value=\"Refinancing\">Maltron</option>
                                </select>
                            </div>\t\t\t\t
                        </div>


                        <div class=\"col-md-2\">
                            <div>
                                <label for=\"ex3\">&nbsp;</label>
                                <button class=\"btn btn-primary btn-block\">Submit</button>
                            </div>\t\t\t\t
                        </div>
                        <div class=\"col-md-1\">

                        </div>

                    </form>
                </div>
            </div>
        </div>
         <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-12\">
         <ul class=\"bxslider\">
                <li><img src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/rsz_renewal.jpg"), "html", null, true);
        echo "\" /></li>
                <li><img src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/rsz_renewal.jpg"), "html", null, true);
        echo "\" /></li>
                <li><img src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/rsz_renewal.jpg"), "html", null, true);
        echo "\" /></li>
                <li><img src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/images/rsz_renewal.jpg"), "html", null, true);
        echo "\" /></li>
            </ul>
                </div></div></div>
            <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <h1 style=\"text-align: center;\">Best Mortgage Rates in Canada</h1>
                </div></div></div>
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-4\">
                    <div class=\"panel panel-primary text-center\">
                        <div class=\"panel-heading\">
                            <h3 class=\"panel-title\">First Time Home buyers</h3>
                        </div>
                        <div class=\"panel-body\">
                            Before buying a home it's important to get an idea of how much a lender will essentially be willing to give you to purchase your first home So check our mortgage options.
                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"panel panel-primary text-center\">
                        <div class=\"panel-heading\">
                            <h3 class=\"panel-title\">Mortgage Calculator</h3>
                        </div>
                        <div class=\"panel-body\">
                            With the help of Mortgage Calculator you will check how much you can afford to borrow so mortgage calculator can help you to find the right mortgage for you. 
                        </div>
                    </div>
                </div>
                <div class=\"col-md-4\">
                    <div class=\"panel panel-primary text-center\">
                        <div class=\"panel-heading\">
                            <h3 class=\"panel-title\">Frequent Questions</h3>
                        </div>
                        <div class=\"panel-body\">
                            We know that everyone worries about mortgage process so we will help you in every step. You can check our Mortgage rate and if you have any question or enquiry feel free to contact us.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        ";
        // line 107
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AcmeDemoBundle:Mortgage:footer"));
        echo "
    </div>
    <script src=\"";
        // line 109
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/js/jquery_bag.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/js/jquery.bxslider.js"), "html", null, true);
        echo "\"></script>
    <script>
        \$('.bxslider').bxSlider({
            adaptiveHeight: true,
            mode: 'fade'
           // auto: true,
            //pause: 3000
        });
    </script>
</head>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 8,  155 => 93,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 105,  167 => 111,  137 => 94,  129 => 92,  23 => 3,  223 => 134,  215 => 132,  211 => 131,  207 => 130,  202 => 128,  197 => 105,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 32,  84 => 29,  53 => 10,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 97,  305 => 95,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 60,  140 => 55,  132 => 51,  128 => 49,  107 => 36,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 154,  219 => 133,  217 => 153,  208 => 165,  204 => 164,  179 => 69,  159 => 109,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 14,  201 => 149,  196 => 90,  183 => 82,  171 => 97,  166 => 71,  163 => 110,  158 => 79,  156 => 66,  151 => 92,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 64,  91 => 38,  62 => 24,  49 => 9,  87 => 34,  28 => 5,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 6,  19 => 1,  93 => 28,  88 => 31,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 8,  37 => 5,  22 => 2,  246 => 90,  157 => 56,  145 => 96,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 31,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 15,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 6,  29 => 3,  209 => 151,  203 => 78,  199 => 67,  193 => 104,  189 => 103,  187 => 84,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 107,  149 => 97,  147 => 58,  144 => 49,  141 => 95,  133 => 93,  130 => 41,  125 => 44,  122 => 48,  116 => 41,  112 => 42,  109 => 65,  106 => 45,  103 => 32,  99 => 31,  95 => 28,  92 => 36,  86 => 28,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 10,  36 => 7,  33 => 4,  30 => 7,);
    }
}
