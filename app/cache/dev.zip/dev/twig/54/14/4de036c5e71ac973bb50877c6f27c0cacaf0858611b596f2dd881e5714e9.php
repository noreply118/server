<?php

/* MainRatetradeBundle:Default:footer.html_1.twig */
class __TwigTemplate_54144de036c5e71ac973bb50877c6f27c0cacaf0858611b596f2dd881e5714e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"newsl\"><div class=\"container\">
        <div class=\"row\">
            <div class=\"listl\">
                <form class=\"form-inline\">
                    <div class=\"form-group\">
                        <label for=\"exampleInputName1\">Name</label>
                        <input type=\"text\" class=\"form-control\" id=\"exampleInputName1\" placeholder=\"Jane Doe\">
                    </div>
                    <div class=\"form-group\">
                        <label for=\"exampleInputEmail2\" class=\"pd-left\">Email</label>
                        <input type=\"email\" class=\"form-control\" id=\"exampleInputEmail2\" placeholder=\"jane.doe@example.com\">
                    </div>
                    <button type=\"submit\" class=\"btn btn-success btn-lg subsc\">Subscribe Us</button>
                </form>
            </div>

            <div class=\"slinl\"><span>Follow Us :</span> <a href=\"https://www.facebook.com/RateTradeBestMortgageRate/\" target=\"_blank\">
                    <i class=\"fa fa-facebook-square\"></i>
                </a> 
                <a href=\"https://twitter.com/RatetradeCanada\" target=\"_blank\">
                    <i class=\"fa fa-twitter-square\"></i>
                </a> 
                <a href=\"https://www.linkedin.com/in/ratetrade-canada-47a075120\" target=\"_blank\">
                    <i class=\"fa fa-linkedin-square\"></i>
                </a>
                <a href=\"https://in.pinterest.com/ratetrade/\" target=\"_blank\">
                    <i class=\"fa fa-pinterest-square\"></i>
                </a>
                <a href=\"https://plus.google.com/u/0/113824083193294175526/posts\" target=\"_blank\">
                    <i class=\"fa fa-google-plus-square\"></i>
                </a></div>
        </div>
    </div></div>
<footer>
    <div class=\"container\">

        <div class=\"row\">
            <div class=\"col-xs-12 footer-top\">
                <div class=\"col-xs-12 col-sm-6\">
                    <img src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/mainratetrade/images/ratetrade-300x48.png"), "html", null, true);
        echo "\" class=\"img-responsive\">
                </div>
                <div class=\"col-xs-12 col-sm-6\">
                    <h4>";
        // line 43
        echo "&nbsp;</h4>
                </div>

            </div>
            <div class=\"col-md-4 col-sm-6 col-xs-12\">

                <div class=\"abouts\">
                    <h3>Mortgage</h3>
                    <ul>
                        <li><a href=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "fixed")), "html", null, true);
        echo "\">Fixed Mortgage Rates</a></li>
                        <li><a href=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("mortgage_rates", array("target" => "best", "ratetype" => "variable")), "html", null, true);
        echo "\">Variable Mortgage Rates</a></li>
                        <li><a href=\"";
        // line 54
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "buying-home-canada"));
        echo "\">Buying Home in Canada</a></li>
                        <li><a href=\"";
        // line 55
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "renewing-guide"));
        echo "\">Renewing Your Mortgage</a></li>
                        <li><a href=\"";
        // line 56
        echo $this->env->getExtension('routing')->getPath("dynmaicurl", array("urlparam" => "mortgage-refinancing-guide"));
        echo "\">Mortgage Refinancing Guide</a></li>
                    </ul>
                </div>

            </div>
            <div class=\"col-md-5 col-sm-6 col-xs-12\">

                <div class=\"contact-us\">
                    <h3>Contact Us</h3>
                    <address>
                        <strong>Email:</strong> <a href=\"mailto:contact@ratetrade.ca\">contact@ratetrade.ca</a><br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"mailto:contact@ratetrade.ca\">info@ratetrade.ca</a>
                    </address>
                </div>

            </div>
            <div class=\"col-md-3 col-sm-6 col-xs-12\">

                <div class=\"ft-social\"><!-- social -->
                    <h3>Follow Us on Social</h3> 
                    <a href=\"https://www.facebook.com/RateTradeBestMortgageRate/\" target=\"_blank\">
                        <i class=\"fa fa-facebook-square\"></i>
                    </a> 
                    <a href=\"https://twitter.com/RatetradeCanada\" target=\"_blank\">
                        <i class=\"fa fa-twitter-square\"></i>
                    </a> 
                    <a href=\"https://www.linkedin.com/in/ratetrade-canada-47a075120\" target=\"_blank\">
                        <i class=\"fa fa-linkedin-square\"></i>
                    </a>
                    <a href=\"https://in.pinterest.com/ratetrade/\" target=\"_blank\">
                        <i class=\"fa fa-pinterest-square\"></i>
                    </a>
                    <a href=\"https://plus.google.com/u/0/113824083193294175526/posts\" target=\"_blank\">
                        <i class=\"fa fa-google-plus-square\"></i>
                    </a>
                </div>

            </div>
        </div>

    </div>
    <div class=\"footer-bottom\">
        <small>Copyright &copy; ";
        // line 98
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " <a href=\"";
        echo $this->env->getExtension('routing')->getPath("ratetrade_homepage");
        echo "\">RateTrade.ca</a></small>
    </div>
</footer>";
    }

    public function getTemplateName()
    {
        return "MainRatetradeBundle:Default:footer.html_1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  405 => 191,  333 => 163,  307 => 156,  299 => 152,  257 => 136,  807 => 497,  617 => 312,  611 => 311,  596 => 307,  591 => 306,  491 => 237,  431 => 212,  415 => 196,  291 => 149,  284 => 145,  736 => 454,  645 => 366,  641 => 365,  602 => 333,  594 => 331,  587 => 305,  582 => 328,  578 => 327,  317 => 159,  565 => 320,  468 => 219,  281 => 177,  465 => 216,  361 => 157,  332 => 173,  328 => 147,  320 => 143,  276 => 141,  272 => 126,  245 => 131,  724 => 346,  668 => 297,  660 => 295,  653 => 293,  648 => 292,  574 => 233,  566 => 231,  563 => 230,  559 => 229,  550 => 223,  547 => 222,  542 => 219,  514 => 281,  492 => 252,  484 => 201,  410 => 173,  397 => 165,  388 => 221,  380 => 219,  366 => 224,  331 => 141,  323 => 139,  315 => 137,  300 => 131,  296 => 129,  832 => 563,  734 => 471,  727 => 467,  706 => 452,  554 => 305,  548 => 304,  533 => 300,  528 => 216,  478 => 249,  442 => 237,  417 => 178,  372 => 159,  336 => 164,  924 => 587,  851 => 517,  826 => 495,  819 => 491,  805 => 480,  798 => 476,  762 => 443,  646 => 329,  632 => 326,  625 => 324,  620 => 323,  616 => 322,  555 => 266,  538 => 262,  534 => 261,  526 => 249,  509 => 245,  482 => 240,  386 => 194,  357 => 212,  353 => 180,  344 => 176,  339 => 151,  335 => 175,  329 => 192,  321 => 190,  610 => 410,  462 => 192,  394 => 222,  370 => 179,  364 => 181,  349 => 170,  340 => 175,  325 => 161,  319 => 194,  304 => 185,  295 => 150,  289 => 176,  280 => 167,  126 => 79,  845 => 491,  772 => 421,  685 => 337,  680 => 335,  676 => 334,  644 => 291,  638 => 303,  630 => 301,  618 => 298,  614 => 297,  539 => 297,  531 => 226,  516 => 319,  476 => 233,  464 => 230,  421 => 183,  343 => 152,  324 => 145,  316 => 129,  313 => 188,  303 => 154,  292 => 127,  288 => 114,  510 => 280,  506 => 234,  502 => 233,  498 => 232,  425 => 179,  419 => 198,  411 => 194,  389 => 184,  378 => 181,  311 => 157,  708 => 448,  619 => 362,  580 => 234,  558 => 306,  552 => 224,  544 => 303,  537 => 301,  523 => 294,  512 => 246,  483 => 235,  452 => 241,  448 => 206,  436 => 182,  408 => 193,  404 => 170,  1225 => 949,  1152 => 879,  1032 => 761,  1026 => 760,  1018 => 758,  1011 => 756,  1006 => 755,  1002 => 754,  956 => 711,  928 => 685,  922 => 684,  914 => 682,  911 => 681,  907 => 680,  899 => 674,  893 => 673,  885 => 671,  882 => 670,  878 => 669,  869 => 662,  863 => 661,  855 => 659,  852 => 471,  848 => 657,  837 => 649,  833 => 648,  829 => 647,  821 => 645,  816 => 643,  812 => 642,  808 => 641,  804 => 640,  780 => 619,  418 => 177,  100 => 41,  277 => 176,  521 => 214,  513 => 271,  508 => 216,  499 => 248,  495 => 247,  489 => 261,  472 => 257,  396 => 234,  392 => 185,  377 => 218,  356 => 179,  352 => 178,  348 => 177,  192 => 112,  883 => 685,  699 => 504,  449 => 250,  432 => 222,  428 => 180,  414 => 177,  406 => 227,  403 => 205,  399 => 204,  390 => 216,  376 => 164,  373 => 180,  369 => 215,  265 => 161,  261 => 104,  253 => 146,  898 => 592,  825 => 646,  725 => 431,  721 => 430,  717 => 429,  713 => 456,  709 => 427,  704 => 425,  700 => 424,  696 => 423,  661 => 390,  655 => 389,  647 => 387,  640 => 328,  635 => 384,  631 => 383,  570 => 279,  564 => 326,  556 => 324,  549 => 265,  541 => 262,  535 => 296,  527 => 313,  524 => 298,  520 => 248,  505 => 244,  497 => 245,  494 => 231,  479 => 239,  475 => 248,  467 => 226,  458 => 253,  454 => 207,  450 => 222,  446 => 221,  184 => 86,  180 => 106,  172 => 104,  160 => 101,  152 => 57,  937 => 621,  809 => 524,  759 => 493,  753 => 447,  745 => 445,  738 => 443,  733 => 426,  729 => 432,  682 => 397,  678 => 396,  674 => 298,  670 => 419,  666 => 393,  629 => 358,  623 => 299,  615 => 355,  608 => 334,  603 => 309,  599 => 351,  553 => 323,  536 => 218,  530 => 294,  522 => 219,  519 => 289,  515 => 292,  507 => 282,  501 => 214,  493 => 208,  490 => 242,  486 => 251,  477 => 270,  471 => 247,  463 => 242,  460 => 191,  456 => 228,  445 => 205,  441 => 268,  433 => 203,  429 => 201,  424 => 254,  420 => 228,  416 => 252,  412 => 229,  385 => 230,  382 => 193,  118 => 38,  597 => 247,  593 => 324,  589 => 323,  585 => 237,  581 => 321,  576 => 319,  572 => 318,  568 => 254,  561 => 313,  546 => 300,  540 => 302,  532 => 284,  529 => 295,  525 => 215,  517 => 272,  511 => 304,  503 => 206,  500 => 205,  496 => 243,  487 => 207,  481 => 200,  473 => 274,  470 => 196,  466 => 194,  455 => 242,  451 => 224,  447 => 185,  443 => 237,  439 => 260,  434 => 245,  426 => 200,  422 => 232,  400 => 235,  395 => 172,  114 => 37,  260 => 137,  256 => 103,  248 => 114,  266 => 193,  262 => 121,  250 => 134,  242 => 136,  234 => 185,  226 => 108,  222 => 182,  218 => 105,  279 => 142,  275 => 141,  271 => 140,  267 => 137,  263 => 191,  259 => 158,  255 => 129,  239 => 185,  81 => 53,  65 => 18,  1085 => 1059,  210 => 121,  198 => 103,  194 => 133,  190 => 101,  186 => 103,  178 => 35,  150 => 41,  146 => 69,  134 => 24,  124 => 72,  104 => 36,  391 => 231,  383 => 214,  375 => 313,  371 => 159,  367 => 178,  363 => 177,  359 => 175,  351 => 171,  347 => 219,  188 => 87,  301 => 185,  293 => 149,  113 => 90,  174 => 88,  170 => 78,  148 => 29,  77 => 52,  231 => 110,  165 => 106,  161 => 78,  153 => 92,  195 => 106,  191 => 95,  34 => 8,  155 => 93,  310 => 197,  306 => 196,  302 => 195,  290 => 126,  286 => 146,  282 => 143,  274 => 153,  270 => 194,  251 => 128,  237 => 127,  233 => 138,  225 => 135,  213 => 152,  205 => 78,  175 => 98,  167 => 96,  137 => 84,  129 => 94,  23 => 3,  223 => 119,  215 => 110,  211 => 124,  207 => 58,  202 => 118,  197 => 105,  185 => 114,  181 => 101,  70 => 29,  358 => 156,  354 => 211,  350 => 210,  346 => 220,  342 => 165,  338 => 165,  334 => 142,  330 => 163,  326 => 201,  318 => 199,  206 => 107,  244 => 174,  236 => 133,  232 => 85,  228 => 84,  216 => 115,  212 => 166,  200 => 114,  110 => 36,  90 => 34,  84 => 49,  53 => 15,  127 => 33,  97 => 62,  76 => 19,  58 => 26,  480 => 234,  474 => 198,  469 => 284,  461 => 225,  457 => 241,  453 => 223,  444 => 184,  440 => 246,  437 => 203,  435 => 213,  430 => 257,  427 => 211,  423 => 199,  413 => 226,  409 => 238,  407 => 192,  402 => 130,  398 => 186,  393 => 197,  387 => 215,  384 => 168,  381 => 182,  379 => 230,  374 => 227,  368 => 182,  365 => 189,  362 => 156,  360 => 180,  355 => 173,  341 => 105,  337 => 103,  322 => 200,  314 => 158,  312 => 136,  309 => 154,  305 => 186,  298 => 151,  294 => 133,  285 => 143,  283 => 130,  278 => 195,  268 => 139,  264 => 122,  258 => 97,  252 => 187,  247 => 149,  241 => 129,  229 => 109,  220 => 113,  214 => 103,  177 => 83,  169 => 54,  140 => 27,  132 => 61,  128 => 85,  107 => 33,  61 => 17,  273 => 140,  269 => 94,  254 => 135,  243 => 148,  240 => 173,  238 => 186,  235 => 126,  230 => 184,  227 => 129,  224 => 126,  221 => 154,  219 => 104,  217 => 125,  208 => 96,  204 => 109,  179 => 99,  159 => 94,  143 => 37,  135 => 61,  119 => 36,  102 => 34,  71 => 24,  67 => 29,  63 => 22,  59 => 27,  201 => 106,  196 => 113,  183 => 100,  171 => 97,  166 => 77,  163 => 95,  158 => 30,  156 => 76,  151 => 92,  142 => 26,  138 => 98,  136 => 26,  121 => 92,  117 => 91,  105 => 61,  91 => 29,  62 => 27,  49 => 14,  87 => 28,  28 => 8,  94 => 35,  89 => 55,  85 => 54,  75 => 25,  68 => 39,  56 => 18,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 56,  88 => 50,  78 => 31,  46 => 23,  44 => 15,  27 => 7,  79 => 26,  72 => 13,  69 => 19,  47 => 24,  40 => 11,  37 => 11,  22 => 2,  246 => 137,  157 => 98,  145 => 53,  139 => 65,  131 => 34,  123 => 37,  120 => 71,  115 => 35,  111 => 40,  108 => 40,  101 => 60,  98 => 36,  96 => 37,  83 => 27,  74 => 30,  66 => 43,  55 => 26,  52 => 12,  50 => 24,  43 => 23,  41 => 12,  35 => 8,  32 => 12,  29 => 9,  209 => 117,  203 => 94,  199 => 93,  193 => 90,  189 => 103,  187 => 110,  182 => 36,  176 => 105,  173 => 65,  168 => 103,  164 => 102,  162 => 50,  154 => 71,  149 => 69,  147 => 25,  144 => 67,  141 => 85,  133 => 44,  130 => 23,  125 => 93,  122 => 72,  116 => 21,  112 => 69,  109 => 68,  106 => 41,  103 => 32,  99 => 31,  95 => 30,  92 => 27,  86 => 33,  82 => 32,  80 => 20,  73 => 20,  64 => 32,  60 => 40,  57 => 16,  54 => 25,  51 => 25,  48 => 11,  45 => 13,  42 => 22,  39 => 10,  36 => 10,  33 => 10,  30 => 10,);
    }
}
