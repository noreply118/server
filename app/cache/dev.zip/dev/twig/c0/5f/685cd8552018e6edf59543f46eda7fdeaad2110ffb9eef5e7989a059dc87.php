<?php

/* AcmeDemoBundle:Demo:header.html.twig */
class __TwigTemplate_c05f685cd8552018e6edf59543f46eda7fdeaad2110ffb9eef5e7989a059dc87 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("home");
        echo "\">RateTrade</a>
        </div>
        <div class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav navbar-right\">
                <li><a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("login");
        echo "\">Login</a></li>
            </ul>
            <ul class=\"nav navbar-nav\">
                <li>
                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">MORTGAGE<b class=\"caret\"></b></a>
                    <ul class=\"dropdown-menu multi-level\">
                        <li class=\"dropdown-submenu\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Mortgage Rates</a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"#\">Fixed Rate Mortgage</a></li>
                                <li><a href=\"#\">Variable Rate Mortgage</a></li>
                                <li><a href=\"#\">Home Equity Line Of Credit</a></li>
                                <li><a href=\"#\">Open Mortgage Rates</a></li>
                                <li><a href=\"#\">Fixed Rate Mortgage</a></li>
                                <li><a href=\"#\">Bank Mortgage Rates</a></li>
                            </ul>
                        </li>
                        <li><a href=\"#\">Mortgage Terms</a></li>
                        <li class=\"dropdown-submenu\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Mortgage Brokers</a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"#\">List of Banks & Brokers</a></li>
                            </ul>
                        </li>
                        <li class=\"dropdown-submenu\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Mortgage Education Center</a>
                            <ul class=\"dropdown-menu\">
                                <li class=\"dropdown-submenu\">
                                    <a href=\"#\"class=\"dropdown-toggle\" data-toggle=\"dropdown\">Home Buying Guide</a>
                                    <ul class=\"dropdown-menu\">
                                        <li class=\"dropdown-submenu\">
                                            <a href=\"#\">How Much I Can Afford</a>
                                            <ul class=\"dropdown-menu\">
                                                <li><a href=\"#\">Maximum Affordability In Canada</a></li>
                                                <li><a href=\"#\">TDS/GDS</a></li>
                                                <li><a href=\"#\">Down Payment</a></li>
                                                <li><a href=\"#\">CMHC Insurance</a></li>
                                                <li><a href=\"#\">Credit Score</a></li>
                                            </ul>
                                        </li>
                                        <li class=\"dropdown-submenu\">
                                            <a href=\"#\">Mortgage & Purchase Process</a>
                                            <ul class=\"dropdown-menu\">
                                                <li><a href=\"#\">Pre-approval</a></li>
                                                <li><a href=\"#\">Home Inspection</a></li>
                                                <li><a href=\"#\">Deposit</a></li>
                                                <li><a href=\"#\">Mortgage Approval Process</a></li>
                                                <li><a href=\"#\">Choosing a mortgage provider</a></li>
                                            </ul>
                                        </li>
                                        <li class=\"dropdown-submenu\">
                                            <a href=\"#\">Closing a Mortgage Rate</a>
                                            <ul class=\"dropdown-menu\">
                                                <li><a href=\"#\">Mortgage Term</a></li>
                                                <li><a href=\"#\">Variable v/s fixed</a></li>
                                                <li><a href=\"#\">Terms &amp; Condition</a></li>
                                                <li><a href=\"#\">Prepayment Options</a></li>
                                                <li><a href=\"#\">Porting &amp; Assuming your Mortgage</a></li>
                                                <li><a href=\"#\">Prepayment Options</a></li>
                                                <li><a href=\"#\">Cash Back Mortgage</a></li>
                                                <li><a href=\"#\">Collateral Mortgages</a></li>
                                            </ul>
                                        </li>
                                        <li class=\"dropdown-submenu\">
                                            <a href=\"#\">Mortgage Payment</a>
                                            <ul class=\"dropdown-menu\">
                                                <li><a href=\"#\">Payment Frequency</a></li>
                                                <li><a href=\"#\">Amortization</a></li>
                                                <li><a href=\"#\">Determine Your Payment</a></li>
                                                <li><a href=\"#\">Additional Monthly Cost</a></li>
                                            </ul>
                                        </li>
                                        <li class=\"dropdown-submenu\">
                                            <a href=\"#\">First Time Home Buyer</a>
                                            <ul class=\"dropdown-menu\">
                                                <li><a href=\"#\">First Time Home Buyer Tax Credit</a></li>
                                                <li><a href=\"#\">RRSP Home Buyer</a></li>
                                                <li><a href=\"#\">Land Transfer Tax Rebate</a></li>
                                            </ul>
                                        </li>
                                        <li class=\"dropdown-submenu\">
                                            <a href=\"#\">Closing Cost</a>
                                            <ul class=\"dropdown-menu\">
                                                <li><a href=\"#\">Closing Costs Overview</a></li>
                                                <li><a href=\"#\">Real Estate Lawyer</a></li>
                                                <li><a href=\"#\">Interest Adjustment</a></li>
                                                <li><a href=\"#\">GST-HST</a></li>
                                                <li><a href=\"#\">PST ON CMHC Insurance</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"dropdown-submenu\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Mortgage Renewal</a>
                                    <ul class=\"dropdown-menu\">
                                        <li><a href=\"#\">Mortgage Renewal Process</a></li>
                                        <li><a href=\"#\">Mortgage Renewal Tips</a></li>
                                        <li><a href=\"#\">Early Mortgage Renewal</a></li>
                                        <li><a href=\"#\">Mortgage Renewal Denied Situation</a></li>
                                        <li><a href=\"#\">Switching providers</a></li>
                                    </ul>
                                </li>
                                <li><a href=\"#\">Refinancing Guide</a></li>
                                <li><a href=\"#\">Special Mortgage</a></li>
                                <li><a href=\"#\">Mortgage Report</a></li>
                            </ul>
                        </li>

                    </ul>
                </li>
                <li>
                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">CALCULATOR<b class=\"caret\"></b></a>
                    <ul class=\"dropdown-menu multi-level\">
                        <li><a href=\"";
        // line 127
        echo $this->env->getExtension('routing')->getPath("mortgage_payment");
        echo "\">EMI Calculator</a></li>
                        <li><a href=\"";
        // line 128
        echo $this->env->getExtension('routing')->getPath("chmc_insurance");
        echo "\" class=\"selected\">CHMC Calculator</a></li> 
                        <li><a href=\"";
        // line 129
        echo $this->env->getExtension('routing')->getPath("land_transfer_tax");
        echo "\">Land Transfer Tax</a></li>                
                        <li><a href=\"";
        // line 130
        echo $this->env->getExtension('routing')->getPath("equity_refinance");
        echo "\">Refinance Equity</a></li>
                        <li><a href=\"";
        // line 131
        echo $this->env->getExtension('routing')->getPath("refinance_penalty");
        echo "\">Refinance Penalty</a></li>
                    </ul>
                </li>
                <li><a href=\"";
        // line 134
        echo $this->env->getExtension('routing')->getPath("about");
        echo "\">ABOUT</a></li>
                <li><a href=\"";
        // line 135
        echo $this->env->getExtension('routing')->getPath("contact");
        echo "\">CONTACT</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 130,  161 => 129,  153 => 127,  195 => 134,  191 => 133,  34 => 8,  155 => 93,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 150,  175 => 134,  167 => 127,  137 => 94,  129 => 92,  23 => 3,  223 => 134,  215 => 139,  211 => 138,  207 => 137,  202 => 128,  197 => 105,  185 => 102,  181 => 101,  70 => 26,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 97,  305 => 95,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 131,  140 => 55,  132 => 51,  128 => 49,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 169,  221 => 154,  219 => 133,  217 => 153,  208 => 165,  204 => 164,  179 => 135,  159 => 109,  143 => 56,  135 => 62,  119 => 42,  102 => 17,  71 => 17,  67 => 15,  63 => 19,  59 => 13,  201 => 149,  196 => 90,  183 => 131,  171 => 128,  166 => 71,  163 => 126,  158 => 79,  156 => 66,  151 => 92,  142 => 59,  138 => 54,  136 => 56,  121 => 46,  117 => 19,  105 => 64,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 3,  94 => 34,  89 => 20,  85 => 32,  75 => 17,  68 => 14,  56 => 11,  38 => 9,  24 => 2,  25 => 35,  21 => 2,  31 => 8,  26 => 6,  19 => 1,  93 => 28,  88 => 31,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 18,  72 => 16,  69 => 25,  47 => 12,  40 => 6,  37 => 14,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 25,  55 => 15,  52 => 14,  50 => 21,  43 => 11,  41 => 10,  35 => 9,  32 => 4,  29 => 3,  209 => 151,  203 => 136,  199 => 135,  193 => 104,  189 => 103,  187 => 132,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 57,  154 => 107,  149 => 97,  147 => 58,  144 => 49,  141 => 95,  133 => 93,  130 => 41,  125 => 44,  122 => 48,  116 => 41,  112 => 42,  109 => 65,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 36,  86 => 51,  82 => 50,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 7,  39 => 10,  36 => 5,  33 => 4,  30 => 10,);
    }
}
