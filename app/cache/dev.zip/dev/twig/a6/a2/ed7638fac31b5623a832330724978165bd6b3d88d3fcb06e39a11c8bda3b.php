<?php

/* AcmeDemoBundle:Demo:mortgage.html.twig */
class __TwigTemplate_a6a2ed7638fac31b5623a832330724978165bd6b3d88d3fcb06e39a11c8bda3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <title>RateTrade.ca | About</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
        <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/bootstrap.min.css"), "html", null, true);
        echo "\"/>
        <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/style_bag.css"), "html", null, true);
        echo "\"/>
        <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/css/custom.css"), "html", null, true);
        echo "\"/>
    </head>
    <body>
        <div>
            ";
        // line 13
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AcmeDemoBundle:Mortgage:header"));
        echo "
            <div class=\"container rateTradelogo\">
                <div class=\"row\">
                    <div class=\"col-lg-12\">
                        <h1 class=\"page-header\">About Company</h1>
                    </div>
                </div>
            </div>
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-8\">
                        <div>
                            <p>The best financial and mortgage firm is one which can provide lowest mortgage rates, and suitable payment-option based plans to clients, befitting their financial management.</p>
                            <p>At Golden Financial, we are proud to state that we have been at the forefront in providing the best in terms of both these factors to our clients, with unsurpassed and professional excellence.</p>
                        </div>
                        <div>
                            <h4>Our Profile</h4>
                            <p>A renowned and revered name in the nation and industry, we provide quality, expert and dedicated service to clients. We have built our service structure through continual evolution and knowledge enhancement and keep ourselves updated with market and financial conditions throughout. </p>
                        </div>
                        <div>
                            <h4>Our Team</h4>
                            <p>We have employed some of the best minds in the industry, who not only possess great financial market knowledge, analytical skills, industry experience and proficiency in service deliverance, but are also friendly and understand the importance of saving money and maximizing the investment returns. The mortgage specialists listen to the clients fully, understanding their requirement and provide viable advice and solution, searching the market for best possible and lowest rate mortgage plans.</p>
                        </div>
                        <div>
                            <h4>Our Business Principles – Outstanding Financing Solutions</h4>
                            <p>We work through a large network of lenders, comprising numerous financial products. This enables us to provide our clients with lowest rate mortgage, befitting their requirements.</p>
                        </div>
                        <div>
                            <h4>Our Mission</h4>
                            <p>Clients come to us hoping to find a financial product which will help in reducing their stress and increase their savings. Our dedication and passion is derived by our will to be like a friend to clients, helping them make the most of the mortgage plans, and save their hard-earned money.</p>
                            <p>With our extraordinary & integrated financing process, we strive to bring stress-free mortgage solution to our clients, providing them with simple, reasonable and time-consuming methodology. We aim to develop professional and trustworthy relation with our customers as well as our lender network.<p>
                        </div>

                    </div>
                    <div class=\"col-md-4\">
                        <h3>Main Menu</h3>
                        <div class=\"list-group\">
                            <a class=\"list-group-item\" href=\"";
        // line 50
        echo $this->env->getExtension('routing')->getPath("home");
        echo "\">Home</a>
                            <a class=\"list-group-item\" href=\"";
        // line 51
        echo $this->env->getExtension('routing')->getPath("home");
        echo "\">Mortgage</a>
                            <a class=\"list-group-item\" href=\"";
        // line 52
        echo $this->env->getExtension('routing')->getPath("home");
        echo "\">Calculator</a>
                        </div>
                    </div>
                </div>
            </div>
            ";
        // line 57
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AcmeDemoBundle:Mortgage:footer"));
        echo "
        </div>
        <script src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/js/jquery_bag.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("./bundles/acmedemo/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Demo:mortgage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  391 => 317,  383 => 315,  375 => 313,  371 => 312,  367 => 311,  363 => 310,  359 => 309,  351 => 307,  347 => 306,  188 => 111,  301 => 305,  293 => 299,  113 => 70,  174 => 98,  170 => 97,  148 => 90,  77 => 39,  231 => 155,  165 => 130,  161 => 129,  153 => 92,  195 => 146,  191 => 145,  34 => 8,  155 => 110,  310 => 239,  306 => 238,  302 => 237,  290 => 234,  286 => 233,  282 => 232,  274 => 230,  270 => 229,  251 => 222,  237 => 158,  233 => 157,  225 => 155,  213 => 152,  205 => 116,  175 => 107,  167 => 105,  137 => 94,  129 => 92,  23 => 3,  223 => 153,  215 => 151,  211 => 150,  207 => 149,  202 => 128,  197 => 114,  185 => 102,  181 => 101,  70 => 37,  358 => 287,  354 => 286,  350 => 285,  346 => 284,  342 => 283,  338 => 282,  334 => 281,  330 => 280,  326 => 279,  318 => 277,  206 => 183,  244 => 174,  236 => 172,  232 => 171,  228 => 170,  216 => 167,  212 => 166,  200 => 163,  110 => 22,  90 => 52,  84 => 29,  53 => 11,  127 => 28,  97 => 62,  76 => 17,  58 => 23,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 316,  384 => 121,  381 => 120,  379 => 314,  374 => 116,  368 => 112,  365 => 111,  362 => 288,  360 => 109,  355 => 308,  341 => 105,  337 => 103,  322 => 278,  314 => 240,  312 => 98,  309 => 307,  305 => 306,  298 => 236,  294 => 235,  285 => 89,  283 => 88,  278 => 231,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 221,  241 => 159,  229 => 156,  220 => 168,  214 => 69,  177 => 121,  169 => 131,  140 => 88,  132 => 86,  128 => 85,  107 => 60,  61 => 12,  273 => 96,  269 => 94,  254 => 92,  243 => 220,  240 => 173,  238 => 85,  235 => 74,  230 => 82,  227 => 154,  224 => 169,  221 => 154,  219 => 152,  217 => 153,  208 => 165,  204 => 164,  179 => 108,  159 => 111,  143 => 79,  135 => 77,  119 => 42,  102 => 17,  71 => 27,  67 => 26,  63 => 25,  59 => 13,  201 => 115,  196 => 90,  183 => 109,  171 => 106,  166 => 96,  163 => 104,  158 => 94,  156 => 66,  151 => 81,  142 => 59,  138 => 54,  136 => 87,  121 => 72,  117 => 71,  105 => 68,  91 => 38,  62 => 24,  49 => 10,  87 => 34,  28 => 5,  94 => 34,  89 => 20,  85 => 32,  75 => 28,  68 => 14,  56 => 11,  38 => 9,  24 => 4,  25 => 35,  21 => 2,  31 => 8,  26 => 9,  19 => 1,  93 => 45,  88 => 43,  78 => 28,  46 => 8,  44 => 9,  27 => 7,  79 => 29,  72 => 38,  69 => 25,  47 => 15,  40 => 8,  37 => 5,  22 => 2,  246 => 90,  157 => 128,  145 => 96,  139 => 78,  131 => 61,  123 => 59,  120 => 20,  115 => 44,  111 => 43,  108 => 52,  101 => 63,  98 => 57,  96 => 37,  83 => 33,  74 => 27,  66 => 24,  55 => 20,  52 => 14,  50 => 21,  43 => 12,  41 => 10,  35 => 9,  32 => 6,  29 => 3,  209 => 117,  203 => 148,  199 => 147,  193 => 113,  189 => 103,  187 => 144,  182 => 66,  176 => 99,  173 => 65,  168 => 72,  164 => 59,  162 => 95,  154 => 107,  149 => 97,  147 => 80,  144 => 89,  141 => 95,  133 => 93,  130 => 75,  125 => 73,  122 => 48,  116 => 41,  112 => 42,  109 => 53,  106 => 45,  103 => 59,  99 => 31,  95 => 28,  92 => 39,  86 => 51,  82 => 50,  80 => 30,  73 => 16,  64 => 13,  60 => 6,  57 => 11,  54 => 22,  51 => 14,  48 => 10,  45 => 8,  42 => 13,  39 => 10,  36 => 7,  33 => 4,  30 => 10,);
    }
}
